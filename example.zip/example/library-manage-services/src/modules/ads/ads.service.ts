import { Injectable } from '@nestjs/common'
import { FindOptionsWhere, Like, Repository } from 'typeorm'
import { Ads } from './entity/ads.entity'
import { InjectRepository } from '@nestjs/typeorm'
import { Pagination } from 'src/common/tool/pagination'
import { userDataBaseName } from 'src/config'
import { ApiErrorResponse, ApiResponse, ApiSuccessResponse } from 'src/common/constant/response.api'
import { ResponseCode } from 'src/common/constant/response.code'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'

@Injectable()
export class AdsService {
    constructor(
        @InjectRepository(Ads, userDataBaseName)
        private readonly adsRepository: Repository<Ads>,
        @InjectRepository(LotteryTypes, userDataBaseName)
        private readonly lotteryTypesRepository: Repository<LotteryTypes>,
    ) {}

    async getList(lotteryType: string, title: string, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize

        const where: FindOptionsWhere<Ads> = {}
        where.ad_lottery_type = lotteryType
        if (title) {
            where.ad_title = Like(`${title}%`)
        }
        //query.cache = true;
        query.order = {
            id: 'DESC',
        }
        query.where = where
        const [list, count] = await this.adsRepository.findAndCount(query)
        return new Pagination({
            data: list,
            count,
            pageIndex: pageIndex,
            pageSize: pageSize,
        })
    }

    async create(iconUrl: string, title: string, link: string, lotteryType: string, status: number): Promise<ApiResponse<Ads>> {
        const exist = await this.lotteryTypesRepository.findOne({
            select: ['type_key'],
            where: { type_key: lotteryType },
        })
        if (!exist) {
            return new ApiErrorResponse('提交的彩票类型不存在!', ResponseCode.FAIL)
        }

        const adsInfo = new Ads()
        adsInfo.ad_icon_url = iconUrl
        adsInfo.ad_title = title
        adsInfo.ad_link = link
        adsInfo.ad_lottery_type = lotteryType
        const createDate = new Date()
        adsInfo.ad_created_at = createDate
        adsInfo.ad_update_at = createDate
        adsInfo.ad_status = status == 1 ? 1 : 0

        const result = await this.adsRepository.insert(adsInfo)
        if (result.raw.insertId > 0) {
            return new ApiSuccessResponse(adsInfo)
        } else {
            return new ApiErrorResponse('广告创建失败!', ResponseCode.FAIL)
        }
    }

    async update(id: number, iconUrl: string, title: string, link: string, lotteryType: string, status: number): Promise<ApiResponse<number>> {
        const exist = await this.lotteryTypesRepository.findOne({
            select: ['type_key'],
            where: { type_key: lotteryType },
        })
        if (!exist) {
            return new ApiErrorResponse('提交的彩票类型不存在!', ResponseCode.FAIL)
        }
        const adsInfo = await this.adsRepository.findOne({ where: { id: id } })
        if (!adsInfo) {
            return new ApiErrorResponse(`广告ID为${id}的信息不存在`, ResponseCode.FAIL)
        }
        const result = await this.adsRepository.update(
            { id: id },
            {
                ad_icon_url: iconUrl,
                ad_title: title,
                ad_link: link,
                ad_lottery_type: lotteryType,
                ad_status: status == 1 ? 1 : 0,
                ad_update_at: new Date(),
            },
        )
        if (result.affected <= 0) {
            return new ApiErrorResponse('广告更新失败!', ResponseCode.FAIL)
        }
        return new ApiSuccessResponse(result.affected)
    }
}
