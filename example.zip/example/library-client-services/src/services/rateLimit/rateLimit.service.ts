import { Injectable, NestMiddleware } from '@nestjs/common'
import { Request, Response, NextFunction } from 'express'
import * as RateLimiter from 'rate-limiter-flexible'

@Injectable()
export class RateLimitMiddleware implements NestMiddleware {
    private readonly limiter = new RateLimiter.RateLimiterMemory({
        points: 500, // 15 分钟内允许的最大请求数
        duration: 60 * 15, // 限制周期（秒）
    })

    use(req: Request, res: Response, next: NextFunction) {
        this.limiter
            .consume(req.ip)
            .then(() => next())
            .catch(() => res.status(429).send('请求过多,请15分钟后再操作'))
    }
}
