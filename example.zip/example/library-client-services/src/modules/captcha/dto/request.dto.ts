import { Type } from 'class-transformer'
import { IsNotEmpty, MinLength, IsString } from 'class-validator'

export class GenerateCaptchaDto {
    @Type(() => String)
    @IsNotEmpty({ message: '帐号不能为空' })
    @MinLength(11)
    @IsString()
    readonly account: string
}
