import { Injectable } from '@nestjs/common'
import { EntityManager, SelectQueryBuilder } from 'typeorm'
import { InjectEntityManager } from '@nestjs/typeorm'
import { Collect } from './entity/collect.entity'
import { LhcDrawing } from '../lhcDrawing/entity/lhcDrawing.entity'
import { userDataBaseName } from 'src/config'
import { User } from '../user/entity/user.entity'

@Injectable()
export class CollectService {
    constructor(
        @InjectEntityManager(userDataBaseName)
        private readonly entityManager: EntityManager,
    ) {}

    async getList(userId: number, pageSize: number, pageIndex: number) {
        const queryBuilder: SelectQueryBuilder<any> = this.entityManager.createQueryBuilder(Collect, 'uc')

        queryBuilder
            .leftJoinAndSelect(LhcDrawing, 'draw', 'draw.id = uc.drawing_id ')
            .leftJoinAndSelect(User, 'u', 'uc.user_id = u.id')
            .select(`u.nick_name,uc.id,uc.user_id,uc.drawing_id,uc.created_at,draw.name,draw.picture_url`)
            .orderBy({ 'uc.id': 'ASC', 'uc.created_at': 'DESC' })
            .where('1 = 1')

        if (userId > 0) {
            queryBuilder.andWhere('uc.user_id = :userId', { userId: userId })
        }

        return await queryBuilder
            .limit(pageSize)
            .offset(pageSize * (pageIndex - 1))
            .getRawMany()
    }
}
