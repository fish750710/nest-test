import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

// 管理员日志表
@Entity('admin_logs')
export class AdminLogs {
    @PrimaryGeneratedColumn()
    id: number

    // 日志内容
    @Column()
    content: string

    // 日志操作IP
    @Column()
    ip: string

    // 创建时间
    @Column({ type: 'datetime', nullable: true })
    created_at: Date
}
