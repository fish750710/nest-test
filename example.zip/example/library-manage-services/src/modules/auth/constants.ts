export const jwtConstants = {
    secret: 'i8761286317826ABCDEF',
    expiresIn: '3d',
}
