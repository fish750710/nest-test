import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm'
import { EntityManager, Repository, SelectQueryBuilder } from 'typeorm'
import { Injectable } from '@nestjs/common'
import { Comment } from './entity/comment.entity'
import { address } from 'ip'
import { ResponseCode } from 'src/common/constant/response.code'
import { Queue } from 'bull'
import { InjectQueue } from '@nestjs/bull'
import { LhcDrawing } from '../lhcDrawing/entity/lhcDrawing.entity'
import { User } from '../user/entity/user.entity'

@Injectable()
export class CommentService {
    constructor(
        @InjectEntityManager() private readonly entityManager: EntityManager,
        @InjectQueue('comment_queue') private readonly commentQueue: Queue,
        @InjectRepository(Comment)
        private readonly commentRepository: Repository<Comment>,
    ) {}

    async getByDrawingIdList(drawingId: number, parentId: number, maxId: number, pageIndex: number): Promise<Comment[]> {
        const queryBuilder: SelectQueryBuilder<any> = this.entityManager.createQueryBuilder(Comment, 'uc').leftJoinAndSelect(User, 'u', 'uc.user_id = u.id')
        if (parentId > 0) {
            queryBuilder
                .leftJoinAndSelect(User, 'u1', 'uc.to_user_id = u1.id')
                .select(
                    `uc.id,uc.drawing_id,uc.user_id,uc.content,uc.created_at,uc.likes_qty,uc.level,uc.comment_count,uc.is_recommend,uc.is_hot,uc.to_user_id,u.nick_name,u1.nick_name AS to_nick_name`,
                )
        } else {
            queryBuilder.select(
                `uc.id,uc.drawing_id,uc.user_id,uc.content,uc.created_at,uc.likes_qty,uc.level,uc.comment_count,uc.is_recommend,uc.is_hot,u.nick_name`,
            )
        }
        queryBuilder.where(`uc.drawing_id = :drawing_id and uc.status = :status`, {
            drawing_id: drawingId,
            status: 0,
        })

        if (maxId > 0) {
            queryBuilder.andWhere('uc.id > :id', { id: maxId })
        }

        if (parentId > 0) {
            queryBuilder.andWhere('uc.parent_id = :parent_id and uc.level = :level', {
                parent_id: parentId,
                level: 2,
            })
        } else {
            queryBuilder.andWhere('uc.level = :level', { level: 1 })
        }
        return await queryBuilder
            .orderBy({ 'uc.id': 'ASC', 'uc.created_at': 'DESC' })
            .limit(10)
            .offset(10 * (pageIndex - 1))
            .cache(true)
            .getRawMany()
    }

    async getCommentByUserId(userId: number, maxId: number, pageIndex: number, lotteryType: string) {
        const queryBuilder: SelectQueryBuilder<any> = this.entityManager.createQueryBuilder(Comment, 'c')

        queryBuilder
            .leftJoinAndSelect(LhcDrawing, 'draw', 'draw.id = c.drawing_id ')
            .select(`c.id,c.drawing_id,c.user_id,c.content,c.created_at,c.likes_qty,c.level,c.comment_count,c.is_recommend,c.is_hot,draw.name,draw.picture_url`)
            .orderBy({ 'c.id': 'ASC', 'c.created_at': 'DESC' })
            .where('c.user_id = :userId', { userId: userId })

        if (maxId > 0) {
            queryBuilder.andWhere('c.id > :id', { id: maxId })
        }
        if (lotteryType) {
            queryBuilder.andWhere('draw.lottery_type > :lotteryType', { lotteryType: lotteryType })
        }

        return await queryBuilder
            .limit(10)
            .offset(10 * (pageIndex - 1))
            .getRawMany()
    }

    async addComment(drawingId: number, userId: number, parentId: number, content: string) {
        let level = 1,
            toUserId = 0
        const userCommentInfo = new Comment()
        let parentInfo: Comment = null

        if (parentId > 0) {
            parentInfo = await this.commentRepository.findOne({
                select: ['id', 'level', 'comment_count'],
                where: [{ id: parentId }],
            })
            if (parentInfo != null) {
                level = parentInfo.level + 1
                parentId = parentInfo.parent_id === 0 ? parentId : parentInfo.parent_id
                toUserId = parentInfo.user_id
            }
        }
        userCommentInfo.content = content
        userCommentInfo.user_id = userId
        userCommentInfo.drawing_id = drawingId
        userCommentInfo.comment_ip = address()
        userCommentInfo.created_at = new Date()
        userCommentInfo.parent_id = parentId || 0
        userCommentInfo.to_user_id = toUserId
        userCommentInfo.comment_count = 0
        userCommentInfo.level = level
        userCommentInfo.status = 0
        userCommentInfo.likes_qty = 0
        userCommentInfo.is_hot = 0
        userCommentInfo.is_recommend = 0
        userCommentInfo.to_sort = 0

        const result = await this.commentRepository.insert(userCommentInfo)
        if (result.raw.insertId <= 0) {
            return {
                code: ResponseCode.ERROR,
                message: '评论失败，请重试!',
                data: 0,
            }
        }

        // 添加任务到队列，设置attempts为3，表示任务最多重试3次。backoff为5000，表示上述在每次重试之间的延迟时间为5000毫秒。
        await this.commentQueue.add(
            {
                parentId,
                drawingId,
                commentCount: parentInfo != null ? parentInfo.comment_count + 1 : null,
            },
            { attempts: 3, backoff: 5000 },
        )

        return result.raw.insertId
    }
}
