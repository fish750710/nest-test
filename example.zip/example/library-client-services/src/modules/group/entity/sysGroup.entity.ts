import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm'

@Entity('sys_group')
export class SysGroup {
    @PrimaryGeneratedColumn('uuid')
    id: string

    @Column()
    name: string

    @Column()
    notice: string

    @Column({ type: 'double', default: new Date().valueOf() })
    created_time: number
}
