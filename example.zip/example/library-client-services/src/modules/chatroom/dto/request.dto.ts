// 进入聊天室
interface JoinChatRoomSocketDto {
    readonly group_id: string
}

// 发送聊天室消息
interface ChatRoomMessageDto {
    readonly user_id: number
    readonly group_id: string
    content: string
    readonly imageData: ArrayBuffer
    readonly width?: number
    readonly height?: number
    readonly format?: string
    readonly message_type: string
    readonly token: string
}

// 获取聊天室消息
interface GetChatRoomDataDto {
    readonly group_id: string
    readonly user_id?: number
    readonly token?: string
}
