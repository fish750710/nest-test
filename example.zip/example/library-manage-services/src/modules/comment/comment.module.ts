import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { User } from '../user/entity/user.entity'
import { LhcDrawing } from '../lhcDrawing/entity/lhcDrawing.entity'
import { CommentController } from './comment.controller'
import { Comment } from './entity/comment.entity'
import { CommentService } from './comment.service'
import { userDataBaseName } from 'src/config'

@Module({
    imports: [TypeOrmModule.forFeature([Comment, User, LhcDrawing], userDataBaseName)],
    controllers: [CommentController],
    providers: [CommentService],
})
export class CommentModule {}
