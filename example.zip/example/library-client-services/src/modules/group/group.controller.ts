import { Controller, Post, Get, Body, Query, Headers, HttpCode, UsePipes, UseInterceptors } from '@nestjs/common'
import { GroupService } from './group.service'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { GetGroupMessagesDto, GetGroupUserDto, GetGroupsByNameDto, GetGroupsDto, GetSysGroupMessagesDto } from './dto/request.dto'
import { SysGroupService } from './sysGroup.service'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { TokenRequired } from '../../services/redisService/redisToken.decorator'
import { CacheInterceptor } from '@nestjs/cache-manager'

@Controller('group')
export class GroupController {
    constructor(
        private readonly redisCache: RedisCacheService,
        private readonly groupService: GroupService,
        private readonly sysGroupService: SysGroupService,
    ) {}

    /**
     * 获取系统聊天室
     */
    @HttpCode(200)
    @UseInterceptors(CacheInterceptor)
    @Get('getSysGroups')
    async getSysGroups() {
        return this.sysGroupService.getAllSysGroups()
    }

    /**
     * 获取系统指定聊天室消息
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Get('/getSysGroupMessages')
    getSysGroupMessages(@Query() query: GetSysGroupMessagesDto) {
        const { groupId, pageIndex } = query
        return this.sysGroupService.getSysGroupMessages(groupId, pageIndex || 1)
    }

    /**
     * 获取用户群组
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Get('getGroups')
    async getGroups(@Body() body: GetGroupsDto) {
        const { groupIds } = body
        return this.groupService.getGroups(groupIds)
    }

    /**
     * 获取用户所在群组
     * @returns
     */
    @TokenRequired()
    @HttpCode(200)
    @Get('/userGroup')
    async getUserGroups(@Headers('Authorization') token: string) {
        const userInfo = await this.redisCache.getUserBySession(token)

        return this.groupService.getUserGroups(userInfo.id)
    }

    /**
     * 获取群所有用户
     * @returns
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Get('/groupUser')
    getGroupUsers(@Query() query: GetGroupUserDto) {
        const { groupId } = query
        return this.groupService.getGroupUsers(groupId)
    }

    /**
     * 获取群消息
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Get('/groupMessages')
    getGroupMessages(@Query() query: GetGroupMessagesDto) {
        const { groupId, pageIndex } = query
        return this.groupService.getGroupMessages(groupId, pageIndex)
    }

    /**
     * 群名称查询
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Get('/findByName')
    getGroupsByName(@Query() query: GetGroupsByNameDto) {
        const { groupName } = query
        return this.groupService.getGroupsByName(groupName)
    }
}
