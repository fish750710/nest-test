import { Type } from 'class-transformer'
import { IsNotEmpty, IsInt, IsOptional, IsNumber, Min, Max } from 'class-validator'

export class GetFriendMessagesDto {
    @IsNotEmpty({ message: '请提供friendId' })
    @Type(() => Number)
    @IsInt()
    readonly friendId: number

    @Type(() => Number)
    @IsOptional()
    @IsInt()
    @Min(1)
    @Max(50)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly pageIndex?: number | null
}
