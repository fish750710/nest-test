export enum LhcTypeEnum {
    xglhc = 'xglhc',
    twlhc = 'twlhc',
    xjplhc = 'xjplhc',
    xamlhc = 'xamlhc',
    amlhc = 'amlhc',
}
