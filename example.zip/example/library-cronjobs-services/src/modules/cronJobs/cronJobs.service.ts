import { Injectable } from '@nestjs/common'
import { HttpService } from '@nestjs/axios'
import { Cron, SchedulerRegistry } from '@nestjs/schedule'
import { InjectContext } from 'nest-puppeteer'
import { BrowserContext } from 'puppeteer'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import * as _ from 'lodash'
import { RedisCacheService } from '../redisService/redisCache.service'
import { AmlhcRecord } from './entity/amlhc.entity'
import { TwlhcRecord } from './entity/twlhc.entity'
import { XamlhcRecord } from './entity/xamlhc.entity'
import { XglhcRecord } from './entity/xglhc.entity'
import { XjplhcRecord } from './entity/xjplhc.entity'
import { redisKeys } from '../redisService/redis.keys'
import { catchError, firstValueFrom } from 'rxjs'
import { AxiosError } from 'axios'
import { LhcTypeEnum } from './enum/lotteryType.enum'
import { isTuesdayOrThursday, parseTime } from 'src/common/tool'

@Injectable()
export class CronjobsService {
    constructor(
        private schedulerRegistry: SchedulerRegistry,
        @InjectContext() private readonly browserContext: BrowserContext,
        private readonly httpService: HttpService,
        private readonly redisCache: RedisCacheService,
        @InjectRepository(AmlhcRecord)
        private readonly amlhcRecordRepository: Repository<AmlhcRecord>,
        @InjectRepository(TwlhcRecord)
        private readonly twlhcRecordRepository: Repository<TwlhcRecord>,
        @InjectRepository(XamlhcRecord)
        private readonly xamlhcRecordRepository: Repository<XamlhcRecord>,
        @InjectRepository(XglhcRecord)
        private readonly xglhcRecordRepository: Repository<XglhcRecord>,
        @InjectRepository(XjplhcRecord)
        private readonly xjplhcRecordRepository: Repository<XjplhcRecord>,
    ) {}

    // @Cron('0 * * * * *')
    // openForBusiness() {
    //     console.log("Delicious cakes is open for business...")
    //     const takingOrdersJob = this.schedulerRegistry.getCronJob('takingOrders')
    //     takingOrdersJob.start()
    // }

    // @Cron(CronExpression.EVERY_5_SECONDS, { name: "takingOrders" })
    // takingOrders() {
    //     console.log("Delicious cakes is still taking orders")
    // }

    // @Cron('40,45 * * * * *')
    // closingSoon() {
    //     console.log("Delicious cakes will be closing soon")
    // }

    // @Cron('50 * * * * *')
    // closed() {
    //     const takingOrdersJob = this.schedulerRegistry.getCronJob('takingOrders')
    //     takingOrdersJob.stop()
    //     console.log("Delicious cakes is closed for the day")
    //     console.log("")
    // }

    // 获取台湾六合彩开奖记录
    //@Cron('0 52 20 * * 2-5') // 周二和周五 20:50
    @Cron('0-4 51-55 20 * * 2,5', { name: 'takingGetTwLhc' }) // 周二和周五 20:50 18:52 至 18:55 之间的每分钟执行一次
    async takingTwLhcLotteryResult() {
        const lockAcquired = await this.redisCache.acquireLock(redisKeys.getCronJobsTWLhcKey, 5000) // 获取锁，过期时间为5秒
        if (!lockAcquired) return
        try {
            console.log(`开始获取台湾六合彩开奖 ${new Date().getTime()} ms`)
            const { data } = await firstValueFrom(
                this.httpService.get(`https://kclm.site/api/trial/drawResult?code=twdlt&format=json&rows=2`).pipe(
                    catchError((error: AxiosError) => {
                        throw new Error(`抓取台湾大乐透开奖结果出错啦! error：${error.response.data}`)
                    }),
                ),
            )
            const result = data.code === 0 ? data.data : []
            if (_.isArray(result) && result.length > 0) {
                const list = new Array<TwlhcRecord>()
                result.forEach((element: any) => {
                    const elementYear = element.drawTime.substring(0, 4)
                    const elementPeriod = element.issue.substring(6)
                    const info = new TwlhcRecord()
                    info.open_number = element.drawResult.replace('+', ' ').split(' ').join(',')
                    info.open_time = element.drawTime
                    info.year = elementYear
                    info.period = elementPeriod
                    info.draw_time = new Date(element.drawTime)
                    info.update_at = new Date()
                    list.push(info)
                })

                const maxInfo = list.reduce((prevInfo, curInfo) => {
                    return prevInfo.period > curInfo.period ? prevInfo : curInfo
                })
                const nextOpenTime = isTuesdayOrThursday(new Date(maxInfo.draw_time))
                const nextPeriodInfo = new TwlhcRecord()
                nextPeriodInfo.open_number = ''
                nextPeriodInfo.draw_time = nextOpenTime
                nextPeriodInfo.open_time = parseTime(nextOpenTime)
                nextPeriodInfo.year = nextOpenTime.getFullYear()
                nextPeriodInfo.update_at = new Date()
                // 本年
                if (nextOpenTime.getFullYear() === maxInfo.year - 0) {
                    nextPeriodInfo.period = (Number(`${maxInfo.year}${maxInfo.period}`) + 1).toString().substring(4)
                } else {
                    // 来年
                    nextPeriodInfo.period = '001'
                }

                list.push(nextPeriodInfo)

                // 同步数据至数据库
                await this.twlhcRecordRepository.upsert(list, ['period', 'year'])
            }

            console.log(`结束获取台湾六合彩开奖 ${new Date().getTime()} ms`)
        } finally {
            await this.redisCache.releaseLock(redisKeys.getCronJobsTWLhcKey) // 释放锁
        }
    }

    // 获取新加坡六合彩开奖记录
    @Cron('0-3 40-44 18 * * 1,4,5', { name: 'takingGetXjpLhc' }) // 周一、周四、周五 18:40 至 18:44 之间的每分钟执行一次
    async takingXjpLhcLotteryResult() {
        const lockAcquired = await this.redisCache.acquireLock(redisKeys.getCronJobsXJPLhcKey, 5000) // 获取锁，过期时间为5秒
        if (!lockAcquired) return
        try {
            console.log(`开始获取新加坡六合彩开奖 ${new Date().getTime()} ms`)
            const page = await this.browserContext.newPage()
            const response = await page
                .goto('http://www.singaporepools.com.sg/en/product/Pages/toto_results.aspx', {
                    waitUntil: 'networkidle0',
                    timeout: 10000 * 60,
                })
                .catch(async (error: Error) => {
                    console.error('[ERROR]: Problem loading Toto page \n', error)
                })
            if (!response) {
                await page.close()
            }
            const results = await page
                .evaluate(() => {
                    const openInfo = { nextIssue: '', nextDate: 0, currIssue: '', currDate: 0, currNumArr: '' }

                    const nextDate = document.querySelector('.toto-draw-date').textContent.trim()
                    const arr = nextDate.split(',')
                    openInfo.nextDate = Date.parse(`${arr[0]} ${arr[1]} 18:30:00 GMT+0800`)

                    const items = [...document.querySelectorAll('.tables-wrap')]
                    items.forEach((item, index) => {
                        if (index > 0) return false
                        openInfo.currIssue = item.querySelector('.drawNumber').textContent.trim().split(' ')[2]
                        openInfo.nextIssue = String(Number(item.querySelector('.drawNumber').textContent.trim().split(' ')[2]) + 1)
                        const rawDrawDate = item.querySelector('.drawDate').textContent.trim()
                        openInfo.currDate = Date.parse(`${rawDrawDate} 18:30:00 GMT+0800`)

                        openInfo.currNumArr = [
                            Number(item.querySelector('.win1').textContent.trim()),
                            Number(item.querySelector('.win2').textContent.trim()),
                            Number(item.querySelector('.win3').textContent.trim()),
                            Number(item.querySelector('.win4').textContent.trim()),
                            Number(item.querySelector('.win5').textContent.trim()),
                            Number(item.querySelector('.win6').textContent.trim()),
                            Number(item.querySelector('.additional').textContent.trim()),
                        ].join()
                    })

                    return openInfo
                })
                .catch((error: Error) => {
                    console.error(error)
                })
            await page.close()
            if (results) {
                const list = new Array<XjplhcRecord>()
                const info = new XjplhcRecord()
                info.open_number = results.currNumArr
                info.draw_time = new Date(results.currDate)
                info.open_time = parseTime(results.currDate)
                info.year = info.draw_time.getFullYear()
                info.period = results.currIssue
                info.update_at = new Date()
                list.push(info)

                const info1 = new XjplhcRecord()
                info1.open_number = ''
                info1.open_time = parseTime(results.nextDate)
                info1.draw_time = new Date(results.nextDate)
                info1.year = info1.draw_time.getFullYear()
                info1.period = results.nextIssue
                info1.update_at = new Date()
                list.push(info1)

                // 同步数据至数据库
                await this.xjplhcRecordRepository.upsert(list, ['period', 'year'])
            }

            console.log(`结束获取新加坡六合彩开奖 ${new Date().getTime()} ms`)
        } finally {
            await this.redisCache.releaseLock(redisKeys.getCronJobsXJPLhcKey) // 释放锁
        }
    }

    // 获取香港六合彩开奖记录
    @Cron('0-3 33-37 21 * * 2,4,6,0', { name: 'takingGetXgLhc' }) // 周二、周四、周六 周天 21:33 至 21:37 之间的每分钟执行一次
    async takingXgLhcLotteryResult() {
        const lockAcquired = await this.redisCache.acquireLock(redisKeys.getCronJobsXGLhcKey, 5000) // 获取锁，过期时间为5秒
        if (!lockAcquired) return
        try {
            console.log(`开始获取香港六合彩开奖 ${new Date().getTime()} ms`)
            const page = await this.browserContext.newPage()
            const response = await page
                .goto('https://bet.hkjc.com/marksix/index.aspx?lang=ch', {
                    waitUntil: 'networkidle0',
                    timeout: 10000 * 60,
                })
                .catch(async (error: Error) => {
                    console.error('[ERROR]: Problem loading Mark six page \n', error)
                })
            if (!response) {
                await page.close()
            }

            const results = await page
                .evaluate(() => {
                    const el = document.querySelector('#oddsTable')
                    const openInfo = { nextIssue: '', nextDate: 0, currIssue: '', currDate: 0, currNumArr: '' }

                    // 获取 下一期期号与开奖时间
                    const trItems = el.querySelectorAll('td[width="50%"]>table>tbody>tr')

                    trItems.forEach((item, index) => {
                        if (index > 1) return
                        if (index === 0) {
                            const periodData = item.querySelector('td:nth-child(2)').textContent.trim()
                            openInfo.nextIssue = periodData.split('/')[1]
                        }
                        if (index === 1) {
                            const nextTimeArr = item.querySelector('td:nth-child(2)').textContent.trim().split('/')
                            openInfo.nextDate = Date.parse(`${nextTimeArr[2].substring(0, 4)}-${nextTimeArr[1]}-${nextTimeArr[0]} 21:33:00 GMT+0800`)
                        }
                    })

                    // 获取上一期，开奖时间、期号、号码
                    const oepnNumberItmes = [...el.querySelectorAll('img[width="37"]')]

                    const numArr = oepnNumberItmes.map((item) => {
                        const imgSrc = item.getAttribute('src')
                        return imgSrc.substring(imgSrc.indexOf('_') + 1, imgSrc.indexOf('.'))
                    })
                    openInfo.currNumArr = numArr.join()
                    const prePeriodEL = el.querySelector('td[width="70%"]>table>tbody>tr:nth-child(1)')
                    openInfo.currIssue = prePeriodEL.querySelector('td:nth-child(1)').textContent.trim().split('/')[1]
                    const currTimeArr = prePeriodEL.querySelector('td:nth-child(2)').textContent.trim().split(': ')[1].split('/')
                    openInfo.currDate = Date.parse(`${currTimeArr[2].substring(0, 4)}-${currTimeArr[1]}-${currTimeArr[0]} 21:33:00 GMT+0800`)

                    return openInfo
                })
                .catch((error: Error) => {
                    console.error(error)
                })
            await page.close()
            if (results) {
                const list = new Array<XglhcRecord>()
                const info = new XglhcRecord()
                info.open_number = results.currNumArr
                info.draw_time = new Date(results.currDate)
                info.open_time = parseTime(results.currDate)
                info.year = info.draw_time.getFullYear()
                info.period = results.currIssue
                info.update_at = new Date()
                list.push(info)

                const info1 = new XglhcRecord()
                info1.open_number = ''
                info1.draw_time = new Date(results.nextDate)
                info1.open_time = parseTime(results.nextDate)
                info1.year = new Date(results.nextDate).getFullYear()
                info1.period = results.nextIssue
                info1.update_at = new Date()
                list.push(info1)

                await this.xglhcRecordRepository.upsert(list, ['period', 'year'])
            }

            console.log(`结束获取香港六合彩开奖 ${new Date().getTime()} ms`)
        } finally {
            await this.redisCache.releaseLock(redisKeys.getCronJobsXGLhcKey) // 释放锁
        }
    }

    // 获取澳门六合彩开奖记录
    @Cron('0-3 32-36 21 * * *', { name: 'takingGetAmLhc' }) //每天的 21:32 至 21:36 之间的每分钟执行一次
    async takingAmLhcLotteryResult() {
        const lockAcquired = await this.redisCache.acquireLock(redisKeys.getCronJobsAMLhcKey, 5000) // 获取锁，过期时间为5秒
        if (!lockAcquired) return
        try {
            console.log(`开始获取澳门六合彩开奖 ${new Date().getTime()} ms`)
            this.amlhcLotteryAsync(`https://macaujc.com/api/live?time=${new Date().getTime()}`, LhcTypeEnum.amlhc)
            console.log(`结束获取澳门六合彩开奖 ${new Date().getTime()} ms`)
        } finally {
            await this.redisCache.releaseLock(redisKeys.getCronJobsAMLhcKey) // 释放锁
        }
    }

    // 获取新澳门六合彩开奖记录
    @Cron('0-3 32-36 21 * * *', { name: 'takingGetXamLhc' }) //每天的 21:32 至 21:36 之间的每分钟执行一次
    async takingXamLhcLotteryResult() {
        const lockAcquired = await this.redisCache.acquireLock(redisKeys.getCronJobsXAMLhcKey, 5000) // 获取锁，过期时间为5秒
        if (!lockAcquired) return
        try {
            console.log(`开始获取新澳门六合彩开奖 ${new Date().getTime()} ms`)
            this.amlhcLotteryAsync(`https://macaujc.com/api/live2?time=${new Date().getTime()}`, LhcTypeEnum.xamlhc)
            console.log(`结束获取新澳门六合彩开奖 ${new Date().getTime()} ms`)
        } finally {
            await this.redisCache.releaseLock(redisKeys.getCronJobsXAMLhcKey) // 释放锁
        }
    }

    // 抓取澳门六合彩
    async amlhcLotteryAsync(url: string, lotteryType: LhcTypeEnum) {
        const { data } = await firstValueFrom(
            this.httpService.get(url).pipe(
                catchError((error: AxiosError) => {
                    throw new Error(`抓取${url}开奖结果出错啦! error：${error.response.data}`)
                }),
            ),
        )
        if (_.isArray(data) && data && data.length > 0) {
            const list = lotteryType == LhcTypeEnum.xamlhc ? new Array<XamlhcRecord>() : new Array<AmlhcRecord>()
            data.forEach((element) => {
                const elementYear = element.expect.substring(0, 4)
                const elementPeriod = element.expect.substring(4)
                const info = lotteryType == LhcTypeEnum.xamlhc ? new XamlhcRecord() : new AmlhcRecord()
                info.open_number = element.openCode
                info.open_time = element.openTime
                info.year = elementYear
                info.period = elementPeriod
                info.draw_time = new Date(element.openTime)
                info.update_at = new Date()
                list.push(info)
            })
            const maxInfo = list.reduce((prevInfo, curInfo) => {
                return prevInfo.period > curInfo.period ? prevInfo : curInfo
            })
            const perTime = new Date(maxInfo.draw_time)
            const nextOpenTime = new Date(perTime.setDate(perTime.getDate() + 1))
            const nextPeriodInfo = lotteryType == LhcTypeEnum.xamlhc ? new XamlhcRecord() : new AmlhcRecord()
            nextPeriodInfo.open_number = ''
            nextPeriodInfo.draw_time = nextOpenTime
            nextPeriodInfo.open_time = parseTime(nextOpenTime)
            nextPeriodInfo.year = nextOpenTime.getFullYear()
            nextPeriodInfo.update_at = new Date()
            // 本年
            if (nextOpenTime.getFullYear() === maxInfo.year - 0) {
                nextPeriodInfo.period = (Number(`${maxInfo.year}${maxInfo.period}`) + 1).toString().substring(4)
            } else {
                // 来年
                nextPeriodInfo.period = '001'
            }

            list.push(nextPeriodInfo)

            if (lotteryType == LhcTypeEnum.xamlhc) {
                await this.xamlhcRecordRepository.upsert(list, ['period', 'year'])
            } else if (lotteryType == LhcTypeEnum.amlhc) {
                await this.amlhcRecordRepository.upsert(list, ['period', 'year'])
            }
        }
    }
}
