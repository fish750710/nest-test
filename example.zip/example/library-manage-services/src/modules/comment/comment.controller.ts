import { Controller, Get, HttpCode, Query, UseGuards, Post, Body, UsePipes } from '@nestjs/common'
import { CommentService } from './comment.service'
import { JwtAuthGuard } from '../auth/jwt.guard'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { GetCommentListDto, RemoveByIdDto } from './dto/request.dto'

@Controller('comment')
export class CommentController {
    constructor(private readonly commentService: CommentService) {}

    // 获取列表
    @Get('getList')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async getList(@Query() query: GetCommentListDto) {
        const { drawingId, parentId, pageSize, pageIndex } = query

        return this.commentService.getList(drawingId || 0, parentId || 0, pageSize || 20, pageIndex || 1)
    }

    // 删除用户评论
    @Post('removeById')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async deleteUserComment(@Body() body: RemoveByIdDto) {
        const { commentId } = body

        return this.commentService.deleteComment(commentId)
    }
}
