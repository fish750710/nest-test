import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { userDataBaseName } from 'src/config'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'
import { LhcDrawing } from './entity/lhcDrawing.entity'
import { lhcDrawingController } from './lhcDrawing.controller'
import { LhcDrawingService } from './lhcDrawing.service'

@Module({
    imports: [TypeOrmModule.forFeature([LhcDrawing, LotteryTypes], userDataBaseName)],
    controllers: [lhcDrawingController],
    providers: [LhcDrawingService],
})
export class LhcDrawingModule {}
