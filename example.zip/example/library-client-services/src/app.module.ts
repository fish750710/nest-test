import { MiddlewareConsumer, Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { RedisModule } from 'nestjs-redis'
import { libraryDataBase } from './config/mysql.config'
import { LhcForecastModule } from './modules/lhcForecast/lhcForecast.module'
import { LotteryVideoModule } from './modules/lotteryVideo/lotteryVideo.module'
import { LhcRecordModule } from './modules/lhcRecord/lhcRecord.module'
import { AdsModule } from './modules/ads/ads.module'
import { LhcDrawingModule } from './modules/lhcDrawing/lhcDrawing.module'
import { redisConfig } from './config'
import { UserModule } from './modules/user/user.module'
import { CollectModule } from './modules/collect/collect.module'
import { ToPushModule } from './modules/toPush/toPush.module'
import { CommentModule } from './modules/comment/comment.module'
import { GroupModule } from './modules/group/group.module'
import { FriendModule } from './modules/friend/friend.module'
import { ChatModule } from './modules/chat/chat.module'
import { ChatRoomModule } from './modules/chatroom/chatroom.module'
import { CaptchaModule } from './modules/captcha/captcha.module'
import { jseSsionIdConfig } from './config/jsessionId.config'
import * as cookieParser from 'cookie-parser'
import * as session from 'express-session'

@Module({
    imports: [
        RedisModule.register(redisConfig), // redis配置
        TypeOrmModule.forRoot(libraryDataBase), // 数据库配置
        LhcForecastModule,
        LotteryVideoModule,
        LhcRecordModule,
        AdsModule,
        LhcDrawingModule,
        UserModule,
        CommentModule,
        CollectModule,
        ToPushModule,
        GroupModule,
        FriendModule,
        ChatModule,
        ChatRoomModule,
        CaptchaModule,
    ],
})
export class AppModule {
    configure(consumer: MiddlewareConsumer) {
        consumer
            .apply(
                cookieParser(),
                session({
                    secret: jseSsionIdConfig.secretKey,
                    resave: jseSsionIdConfig.resave,
                    saveUninitialized: jseSsionIdConfig.saveUninitialized,
                    genid: jseSsionIdConfig.genid,
                    cookie: jseSsionIdConfig.cookie,
                }),
            )
            .forRoutes('*')
    }
}
