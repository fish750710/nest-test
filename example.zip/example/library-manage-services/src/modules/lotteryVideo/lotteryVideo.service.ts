import { Injectable } from '@nestjs/common'
import { FindOptionsWhere, Like, Repository } from 'typeorm'
import { LotteryVideo } from './entity/lotteryVideo.entity'
import { InjectRepository } from '@nestjs/typeorm'
import { userDataBaseName } from 'src/config'
import { Pagination } from 'src/common/tool/pagination'
import { ApiErrorResponse, ApiResponse, ApiSuccessResponse } from 'src/common/constant/response.api'
import { ResponseCode } from 'src/common/constant/response.code'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'

@Injectable()
export class LotteryVideoService {
    constructor(
        @InjectRepository(LotteryVideo, userDataBaseName)
        private readonly lotteryVideoRepository: Repository<LotteryVideo>,
        @InjectRepository(LotteryTypes, userDataBaseName)
        private readonly lotteryTypesRepository: Repository<LotteryTypes>,
    ) {}

    async getList(lotteryType: string, year: number, period: string, title: string, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize
        const where: FindOptionsWhere<LotteryVideo> = {}
        if (lotteryType) {
            where.lottery_type = lotteryType
        }
        if (title) {
            where.video_title = Like(`${title}%`)
        }
        if (period) {
            where.period = period
        }
        if (year) {
            where.year = year
        }
        query.where = where
        query.order = {
            period: 'DESC',
            id: 'DESC',
        }
        const [list, count] = await this.lotteryVideoRepository.findAndCount(query)
        return new Pagination({ data: list, count, pageIndex: pageIndex, pageSize: pageSize })
    }

    async create(videoPictureUrl: string, videoUrl: string, lotteryType: string, videoTitle: string, period: string, year: number) {
        const exist = await this.lotteryTypesRepository.findOne({ select: ['type_key'], where: { type_key: lotteryType } })
        if (!exist) {
            return new ApiErrorResponse('提交的彩票类型不存在!', ResponseCode.FAIL)
        }
        const info = new LotteryVideo()
        info.video_picture_url = videoPictureUrl || ''
        info.video_url = videoUrl
        info.lottery_type = lotteryType
        info.video_title = videoTitle
        info.period = period
        info.year = year
        const createDate = new Date()
        info.created_at = createDate
        info.update_at = createDate

        const result = await this.lotteryVideoRepository.insert(info)
        if (result.raw.insertId > 0) {
            return new ApiSuccessResponse(info)
        } else {
            return new ApiErrorResponse('创建失败!', ResponseCode.FAIL)
        }
    }

    async update(
        id: number,
        videoPictureUrl: string,
        videoUrl: string,
        lotteryType: string,
        videoTitle: string,
        period: string,
        year: number,
    ): Promise<ApiResponse<number>> {
        const exist = await this.lotteryTypesRepository.findOne({ select: ['type_key'], where: { type_key: lotteryType } })
        if (!exist) {
            return new ApiErrorResponse('提交的彩票类型不存在!', ResponseCode.FAIL)
        }

        const adsInfo = await this.lotteryVideoRepository.findOne({ where: { id: id } })
        if (!adsInfo) {
            return new ApiErrorResponse(`视频ID为${id}的信息不存在!`, ResponseCode.FAIL)
        }
        const result = await this.lotteryVideoRepository.update(
            { id: id },
            {
                video_picture_url: videoPictureUrl || '',
                video_url: videoUrl,
                lottery_type: lotteryType,
                video_title: videoTitle,
                period: period,
                year: year,
                update_at: new Date(),
            },
        )
        if (result.affected <= 0) {
            return new ApiErrorResponse('更新失败!', ResponseCode.FAIL)
        }
        return new ApiSuccessResponse(result.affected)
    }
}
