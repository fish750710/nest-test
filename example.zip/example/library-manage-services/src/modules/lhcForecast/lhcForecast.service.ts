import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { FindOptionsWhere, Repository } from 'typeorm'
import { LhcForecast } from './entity/lhcForecast.entity'
import { Pagination } from 'src/common/tool/pagination'
import { ApiResponse, ApiErrorResponse, ApiSuccessResponse } from 'src/common/constant/response.api'
import { ResponseCode } from 'src/common/constant/response.code'
import { userDataBaseName } from 'src/config'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'

@Injectable()
export class LhcForecastService {
    constructor(
        @InjectRepository(LhcForecast, userDataBaseName)
        private readonly lhcForecastRepository: Repository<LhcForecast>,
        @InjectRepository(LotteryTypes, userDataBaseName)
        private readonly lotteryTypesRepository: Repository<LotteryTypes>,
    ) {}

    async getList(lotteryType: string, period: string, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize
        const where: FindOptionsWhere<LhcForecast> = {}

        where.lottery_type = lotteryType
        if (period) {
            where.period = period
        }
        query.where = where

        query.order = {
            period: 'DESC',
            id: 'DESC',
        }

        const [list, count] = await this.lhcForecastRepository.findAndCount(query)
        return new Pagination({ data: list, count, pageIndex: pageIndex, pageSize: pageSize })
    }

    async create(
        period: string,
        jxYima: string,
        jxWuma: string,
        jxShima: string,
        tjYixiao: string,
        tjSanxiao: string,
        tjLiuxiao: string,
        tjJiuxiao: string,
        teXiao: string,
        teMa: string,
        lotteryType: string,
    ): Promise<ApiResponse<LhcForecast>> {
        const exist = await this.lotteryTypesRepository.findOne({ select: ['type_key'], where: { type_key: lotteryType } })
        if (!exist) {
            return new ApiErrorResponse('提交的彩票类型不存在!', ResponseCode.FAIL)
        }

        const info = new LhcForecast()
        info.jx_yima = jxYima
        info.jx_wuma = jxWuma
        info.jx_shima = jxShima
        info.tj_yixiao = tjYixiao
        info.tj_sanxiao = tjSanxiao
        info.tj_liuxiao = tjLiuxiao
        info.tj_jiuxiao = tjJiuxiao
        info.te_xiao = teXiao
        info.te_ma = teMa
        info.period = period
        info.lottery_type = lotteryType
        const createDate = new Date()
        info.created_at = createDate
        info.update_at = createDate

        const result = await this.lhcForecastRepository.insert(info)
        if (result.raw.insertId > 0) {
            return new ApiSuccessResponse(info)
        } else {
            return new ApiErrorResponse('创建失败!', ResponseCode.FAIL)
        }
    }

    async update(
        id: number,
        period: string,
        jxYima: string,
        jxWuma: string,
        jxShima: string,
        tjYixiao: string,
        tjSanxiao: string,
        tjLiuxiao: string,
        tjJiuxiao: string,
        teXiao: string,
        teMa: string,
        lotteryType: string,
    ): Promise<ApiResponse<number>> {
        const adsInfo = await this.lhcForecastRepository.findOne({ where: { id: id } })
        if (!adsInfo) {
            return new ApiErrorResponse(`预测六合ID为${id}的信息不存!`, ResponseCode.FAIL)
        }
        const result = await this.lhcForecastRepository.update(
            { id: id },
            {
                jx_yima: jxYima,
                period: period,
                jx_wuma: jxWuma,
                jx_shima: jxShima,
                tj_yixiao: tjYixiao,
                tj_sanxiao: tjSanxiao,
                tj_liuxiao: tjLiuxiao,
                tj_jiuxiao: tjJiuxiao,
                te_xiao: teXiao,
                te_ma: teMa,
                lottery_type: lotteryType,
                update_at: new Date(),
            },
        )
        if (result.affected <= 0) {
            return new ApiErrorResponse('更新失败!', ResponseCode.FAIL)
        }
        return new ApiSuccessResponse(result.affected)
    }
}
