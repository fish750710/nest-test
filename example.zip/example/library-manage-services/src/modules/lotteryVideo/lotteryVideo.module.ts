import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { userDataBaseName } from 'src/config'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'
import { LotteryVideo } from './entity/lotteryVideo.entity'
import { LotteryVideoService } from './lotteryVideo.service'
import { LotteryVideoController } from './lotteryVideo.controller'

@Module({
    imports: [TypeOrmModule.forFeature([LotteryVideo, LotteryTypes], userDataBaseName)],
    controllers: [LotteryVideoController],
    providers: [LotteryVideoService],
})
export class LotteryVideoModule {}
