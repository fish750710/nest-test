import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { AdminUser } from '../admin/entity/adminUser.entity'
import { AdminUserController } from './admin.controller'
import { AdminUserService } from './admin.service'
import { adminDataBaseName } from 'src/config'

@Module({
    imports: [TypeOrmModule.forFeature([AdminUser], adminDataBaseName)],
    controllers: [AdminUserController],
    providers: [AdminUserService],
})
export class AdminModule {}
