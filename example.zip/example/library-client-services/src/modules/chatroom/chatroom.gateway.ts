import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm'
import { ConnectedSocket, MessageBody, OnGatewayConnection, OnGatewayDisconnect, SubscribeMessage, WebSocketGateway, WebSocketServer } from '@nestjs/websockets'
import { EntityManager, Repository } from 'typeorm'
import { Server, Socket } from 'socket.io'
import { SysGroup } from '../group/entity/sysGroup.entity'
import { SysGroupMessage } from '../group/entity/sysGroupMessage.entity'
import { RedisCacheService } from 'src/services/redisService/redisCache.service'
import { ResponseCode } from 'src/common/constant/response.code'
import * as _ from 'lodash'
import { createWriteStream } from 'fs'
import * as fse from 'fs-extra'
import { join } from 'path'
import { User } from '../user/entity/user.entity'
import { decodeArrayBuffer, encodeArrayBuffer, getTimeDirectoryString } from 'src/common/tool'

@WebSocketGateway({ path: '/wsChatRoom', cors: true })
//@WebSocketGateway(3005, { cors: true, allowEIO4: true, })
//@WebSocketGateway(3005, { path: '/socket', allowEIO3: true, allowEIO4: true, cors: { origin: /.*/, credentials: true } })
export class ChatRoomGateway implements OnGatewayConnection, OnGatewayDisconnect {
    constructor(
        private readonly redisCache: RedisCacheService,
        @InjectEntityManager() private readonly entityManager: EntityManager,
        @InjectRepository(SysGroup)
        private readonly sysGroupRepository: Repository<SysGroup>,
        @InjectRepository(SysGroupMessage)
        private readonly sysGroupMessageRepository: Repository<SysGroupMessage>,
    ) {}

    @WebSocketServer()
    server: Server

    // socket连接钩子
    async handleConnection(_client: Socket): Promise<string> {
        //const userRoom = _client.handshake.query.userId
        //console.log(userRoom, 'userId')
        console.log(_client.id, '_client_id')
        //_client.send(`连接成功`)
        return '连接成功'
    }

    // socket断连钩子
    async handleDisconnect(_client: Socket): Promise<any> {
        console.log(_client.id, '断开连接')
        //this.getActiveGroupUser();
    }

    // @SubscribeMessage('testMessage')
    // async testWs(@ConnectedSocket() client: Socket, @MessageBody() data: ArrayBuffer): Promise<any> {
    //     const textDecoder = new TextDecoder('utf-8')
    //     // // 将 ArrayBuffer 解码为字符串
    //     const decodedMessage = textDecoder.decode(data)
    //     // console.log(data.byteLength, 'Decoded message:', JSON.parse(decodedMessage))
    //     this.server.to(client.id).emit('testMessage', encodeArrayBuffer({ code: ResponseCode.OK, message: 'success', data: JSON.parse(decodedMessage) }))
    // }

    // 进入聊天室
    @SubscribeMessage('joinChatRoomSocket')
    async enterChatRoomSocket(@ConnectedSocket() client: Socket, @MessageBody() data: ArrayBuffer): Promise<any> {
        const group = decodeArrayBuffer<JoinChatRoomSocketDto>(data)
        if (group == null || !_.isString(group.group_id)) {
            return
        }
        const groupInfo = await this.sysGroupRepository.findOne({ where: { id: group.group_id }, cache: 30000 })
        if (!groupInfo) {
            this.server.to(client.id).emit('joinChatRoomSocket', encodeArrayBuffer({ code: ResponseCode.FAIL, message: '进入聊天室失败', data: '' }))
            return
        }
        // 聊天室独有消息房间 根据聊天室ID
        client.join(groupInfo.id)
        this.server.to(client.id).emit('joinChatRoomSocket', encodeArrayBuffer({ code: ResponseCode.OK, message: `进入聊天室成功`, data: groupInfo.id }))
    }

    // 发送聊天室消息
    @SubscribeMessage('chatRoomMessage')
    async sendChatRoomMessage(@ConnectedSocket() client: Socket, @MessageBody() message: ArrayBuffer): Promise<any> {
        const data = decodeArrayBuffer<ChatRoomMessageDto>(message)
        const resultNoLoginInfo = encodeArrayBuffer({ code: ResponseCode.FAIL, message: '请登录后再发消息' })

        // 判断token信息
        if (data == null || !_.isString(data.token)) {
            this.server.to(client.id).emit('chatRoomMessage', resultNoLoginInfo)
            return
        }
        const userInfo = await this.redisCache.getUserBySession(data.token)
        if (userInfo == null || userInfo.id !== data.user_id) {
            this.server.to(client.id).emit('chatRoomMessage', resultNoLoginInfo)
            return
        }
        const sysGroupInfo = await this.sysGroupRepository.findOne({ where: { id: data.group_id } })
        if (!sysGroupInfo) {
            this.server.to(client.id).emit('chatRoomMessage', encodeArrayBuffer({ code: ResponseCode.FAIL, message: '聊天室消息发送错误', data: '' }))
            return
        }
        const sysGroupMessage = new SysGroupMessage()
        sysGroupMessage.user_id = userInfo.id
        sysGroupMessage.sys_group_id = sysGroupInfo.id
        sysGroupMessage.time = new Date().valueOf()
        sysGroupMessage.message_type = 'text'
        sysGroupMessage.content = data.content

        await this.sysGroupMessageRepository.save(sysGroupMessage)
        const resultUser = {
            nick_name: !_.isString(userInfo.nick_name) ? `${client.id.substring(0, 2)}****${client.id.slice(-2)}` : userInfo.nick_name,
            avatar_icon: userInfo.avatar_icon,
            vip_level: userInfo.vip_level,
        }
        this.server
            .to(sysGroupInfo.id)
            .emit('chatRoomMessage', encodeArrayBuffer({ code: ResponseCode.OK, message: 'success', data: Object.assign(sysGroupMessage, resultUser) }))
    }

    // 发送聊天室图片消息
    @SubscribeMessage('chatRoomImageData')
    async sendChatRoomImagesData(@ConnectedSocket() client: Socket, @MessageBody() data: ChatRoomMessageDto): Promise<any> {
        const resultNoLoginInfo = encodeArrayBuffer({ code: ResponseCode.FAIL, message: '请登录后再发消息' })

        // 判断token信息
        if (data == null || !_.isString(data.token)) {
            this.server.to(client.id).emit('chatRoomMessage', resultNoLoginInfo)
            return
        }
        // 检查图片大小
        if (data.message_type === 'image' && data.imageData.byteLength > 0) {
            const maxImageSize = 1024 * 200 // 限制大小为204800 = 204kb
            const allowedImageFormats = ['image/jpeg', 'image/png', 'image/jpg', 'image/bmp', 'image/gif'] // 允许的图像格式
            // 获取客户端上传图像的 MIME 类型
            if (!allowedImageFormats.includes(data.format)) {
                this.server
                    .to(client.id)
                    .emit('chatRoomMessage', encodeArrayBuffer({ code: ResponseCode.FAIL, message: '文件格式只允许：.jpeg、.jpg、.bmp、.png、.gif' }))
                return
            }
            if (data.imageData.byteLength > maxImageSize) {
                this.server.to(client.id).emit('chatRoomMessage', encodeArrayBuffer({ code: ResponseCode.FAIL, message: '图片大小不能超过204KB' }))
                return
            }
        }
        const userInfo = await this.redisCache.getUserBySession(data.token)
        if (userInfo == null || userInfo.id !== data.user_id) {
            this.server.to(client.id).emit('chatRoomMessage', resultNoLoginInfo)
            return
        }
        const sysGroupInfo = await this.sysGroupRepository.findOne({ where: { id: data.group_id } })
        if (!sysGroupInfo) {
            this.server.to(client.id).emit('chatRoomMessage', encodeArrayBuffer({ code: ResponseCode.FAIL, message: '聊天室消息发送错误', data: '' }))
            return
        }
        const sysGroupMessage = new SysGroupMessage()
        sysGroupMessage.user_id = userInfo.id
        sysGroupMessage.sys_group_id = sysGroupInfo.id
        sysGroupMessage.time = new Date().valueOf()
        sysGroupMessage.message_type = data.message_type

        if (data.message_type === 'image') {
            const directory = getTimeDirectoryString()
            // 目标文件夹路径
            const targetFolderPath = join(`public/static/`, directory)
            await fse.ensureDir(targetFolderPath)

            const fileName = `${Date.now()}$${data.user_id}$${data.width}$${data.height}.${data.format.split('/').pop()}`
            const stream = createWriteStream(join(targetFolderPath, fileName))
            stream.write(data.imageData)
            sysGroupMessage.content = `/static/${directory}/${fileName}`

            await this.sysGroupMessageRepository.save(sysGroupMessage)
            const resultUser = {
                nick_name: !_.isString(userInfo.nick_name) ? `${client.id.substring(0, 2)}****${client.id.slice(-2)}` : userInfo.nick_name,
                avatar_icon: userInfo.avatar_icon,
                vip_level: userInfo.vip_level,
            }
            this.server
                .to(sysGroupInfo.id)
                .emit('chatRoomMessage', encodeArrayBuffer({ code: ResponseCode.OK, message: 'success', data: Object.assign(sysGroupMessage, resultUser) }))
        }
    }

    // 获取聊天室消息
    @SubscribeMessage('chatRoomData')
    async getChatRoomData(@ConnectedSocket() client: Socket, @MessageBody() message: ArrayBuffer): Promise<any> {
        const resultFail = encodeArrayBuffer({ code: ResponseCode.FAIL, message: '聊天室消息获取失败', data: '' })

        const data = decodeArrayBuffer<GetChatRoomDataDto>(message)
        if (data == null) {
            this.server.to(client.id).emit('chatRoomData', resultFail)
            return
        }
        const sysGroupInfo = await this.sysGroupRepository.findOne({ where: { id: data.group_id } })
        if (!sysGroupInfo) {
            this.server.to(client.id).emit('chatRoomData', resultFail)
            return
        }
        const messages = await this.entityManager
            .createQueryBuilder(SysGroupMessage, 'sgm')
            .leftJoinAndSelect(User, 'u', 'sgm.user_id = u.id')
            .where('sgm.sys_group_id = :sysGroupId', { sysGroupId: data.group_id })
            .select('sgm.*,u.nick_name,u.avatar_icon,u.vip_level')
            .orderBy('sgm.time', 'DESC')
            .limit(30)
            .offset(0)
            .getRawMany()

        this.server.to(client.id).emit('chatRoomData', encodeArrayBuffer({ code: ResponseCode.OK, message: 'success', data: messages }))
    }
}
