import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { CacheModule } from '@nestjs/cache-manager'
import { APP_GUARD } from '@nestjs/core'
import { RedisTokenGuard } from '../../services/redisService/redisToken.decorator'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { CollectController } from './collect.controller'
import { CollectService } from './collect.service'
import { User } from '../user/entity/user.entity'
import { LhcDrawing } from '../lhcDrawing/entity/lhcDrawing.entity'
import { Collect } from './entity/collect.entity'

@Module({
    imports: [TypeOrmModule.forFeature([Collect, User, LhcDrawing]), CacheModule.register()],
    controllers: [CollectController],
    providers: [
        RedisCacheService,
        {
            provide: APP_GUARD,
            useClass: RedisTokenGuard,
        },
        CollectService,
    ],
})
export class CollectModule {}
