import { Injectable } from '@nestjs/common'
import { EntityManager, Repository, SelectQueryBuilder } from 'typeorm'
import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm'
import { UserMap } from './entity/friend.entity'
import { FriendMessage } from './entity/friendMessage.entity'

@Injectable()
export class FriendService {
    constructor(
        @InjectEntityManager() private readonly entityManager: EntityManager,
        @InjectRepository(UserMap)
        private readonly friendRepository: Repository<UserMap>,
    ) {}

    async getFriends(userId: number) {
        return await this.friendRepository.find({ where: { user_id: userId } })
    }

    async getFriendMessages(userId: number, friendId: number, pageIndex: number, pageSize: number) {
        const queryBuilder: SelectQueryBuilder<any> = this.entityManager.createQueryBuilder(FriendMessage, 'fm')
        queryBuilder.where(`fm.user_id = :userId and fm.friend_id = :friendId`, {
            userId: userId,
            friendId: friendId,
        })
        queryBuilder.orWhere('fm.user_id = :friendId AND fm.friend_id = :userId', { userId: userId, friendId: friendId })

        const result = await queryBuilder.skip(pageIndex).take(pageSize).getMany()

        return result.reverse()
    }
}
