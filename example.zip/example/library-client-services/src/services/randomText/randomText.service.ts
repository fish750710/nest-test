import { Injectable } from '@nestjs/common'
import { faker } from '@faker-js/faker'

@Injectable()
export class RandomTextService {
    generateRandomChinese(): string {
        return faker.lorem.word() // 随机生成一个汉字
    }

    generateRandomEnglish(): string {
        return faker.string.alpha() // 随机生成一个英文字母
    }
}
