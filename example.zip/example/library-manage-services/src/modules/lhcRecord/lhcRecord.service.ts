import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { FindOptionsWhere, Repository } from 'typeorm'
import { XjplhcRecord } from './entity/xjplhc.entity'
import { XglhcRecord } from './entity/xglhc.entity'
import { XamlhcRecord } from './entity/xamlhc.entity'
import { TwlhcRecord } from './entity/twlhc.entity'
import { AmlhcRecord } from './entity/amlhc.entity'
import { LhcTypeEnum } from './enum/index.enum'
import { Pagination } from 'src/common/tool/pagination'
import { userDataBaseName } from 'src/config'
import { LhcRecordBaseEntity } from './entity/base.entity'
import { ApiResponse, ApiSuccessResponse, ApiErrorResponse } from 'src/common/constant/response.api'
import { ResponseCode } from 'src/common/constant/response.code'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'

@Injectable()
export class LhcRecordService {
    constructor(
        @InjectRepository(AmlhcRecord, userDataBaseName)
        private readonly amlhcRecordRepository: Repository<AmlhcRecord>,
        @InjectRepository(TwlhcRecord, userDataBaseName)
        private readonly twlhcRecordRepository: Repository<TwlhcRecord>,
        @InjectRepository(XamlhcRecord, userDataBaseName)
        private readonly xamlhcRecordRepository: Repository<XamlhcRecord>,
        @InjectRepository(XglhcRecord, userDataBaseName)
        private readonly xglhcRecordRepository: Repository<XglhcRecord>,
        @InjectRepository(XjplhcRecord, userDataBaseName)
        private readonly xjplhcRecordRepository: Repository<XjplhcRecord>,
        @InjectRepository(LotteryTypes, userDataBaseName)
        private readonly lotteryTypesRepository: Repository<LotteryTypes>,
    ) {}

    async getList(year: number, period: string, lotteryType: string, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize
        const where: FindOptionsWhere<any> = {}
        if (period) {
            where.period = period
        }
        if (year) {
            where.year = year
        }
        query.where = where
        query.order = {
            draw_time: 'DESC',
            period: 'DESC',
        }
        let list: any, count: number
        if (LhcTypeEnum.xglhc == lotteryType) {
            ;[list, count] = await this.xglhcRecordRepository.findAndCount(query)
        } else if (LhcTypeEnum.amlhc == lotteryType) {
            ;[list, count] = await this.amlhcRecordRepository.findAndCount(query)
        } else if (LhcTypeEnum.xamlhc == lotteryType) {
            ;[list, count] = await this.xamlhcRecordRepository.findAndCount(query)
        } else if (LhcTypeEnum.twlhc == lotteryType) {
            ;[list, count] = await this.twlhcRecordRepository.findAndCount(query)
        } else {
            ;[list, count] = await this.xjplhcRecordRepository.findAndCount(query)
        }
        return new Pagination({ data: list, count, pageIndex: pageIndex, pageSize: pageSize })
    }

    async create(
        openTime: string,
        year: number,
        period: string,
        lotteryType: string,
        openNumber: string,
    ): Promise<ApiResponse<AmlhcRecord | TwlhcRecord | XamlhcRecord | XglhcRecord | XjplhcRecord>> {
        const exist = await this.lotteryTypesRepository.findOne({ select: ['id'], where: { type_key: lotteryType } })
        if (!exist) {
            return new ApiErrorResponse('提交的彩票类型不存在!', ResponseCode.FAIL)
        }

        const info = new LhcRecordBaseEntity()
        info.open_number = openNumber || ''
        info.open_time = openTime
        info.period = period
        info.year = year
        info.draw_time = new Date(openTime)
        info.created_at = new Date(openTime)

        let result: any
        if (LhcTypeEnum.xglhc == lotteryType) {
            result = await this.xglhcRecordRepository.insert(info)
        } else if (LhcTypeEnum.amlhc == lotteryType) {
            result = await this.amlhcRecordRepository.insert(info)
        } else if (LhcTypeEnum.xamlhc == lotteryType) {
            result = await this.xamlhcRecordRepository.insert(info)
        } else if (LhcTypeEnum.twlhc == lotteryType) {
            result = await this.twlhcRecordRepository.insert(info)
        } else {
            result = await this.xjplhcRecordRepository.insert(info)
        }

        if (result.raw.insertId > 0) {
            return new ApiSuccessResponse(info)
        } else {
            return new ApiErrorResponse('创建失败!', ResponseCode.FAIL)
        }
    }

    async update(id: number, openTime: string, year: number, period: string, lotteryType: string, openNumber: string): Promise<ApiResponse<string>> {
        const exist = await this.lotteryTypesRepository.findOne({ select: ['id'], where: { type_key: lotteryType } })
        if (!exist) {
            return new ApiErrorResponse('提交的彩票类型不存在!', ResponseCode.FAIL)
        }

        let Info: any = null
        if (LhcTypeEnum.xglhc == lotteryType) {
            Info = this.xglhcRecordRepository.findOne({ where: { id: id } })
        } else if (LhcTypeEnum.amlhc == lotteryType) {
            Info = this.amlhcRecordRepository.findOne({ where: { id: id } })
        } else if (LhcTypeEnum.xamlhc == lotteryType) {
            Info = this.xamlhcRecordRepository.findOne({ where: { id: id } })
        } else if (LhcTypeEnum.twlhc == lotteryType) {
            Info = this.twlhcRecordRepository.findOne({ where: { id: id } })
        } else {
            Info = this.xjplhcRecordRepository.findOne({ where: { id: id } })
        }

        if (!Info) {
            return new ApiErrorResponse(`彩票开奖记录ID为${id}的信息不存!`, ResponseCode.FAIL)
        }
        const updateInfo = {
                open_number: openNumber || '',
                open_time: openTime,
                draw_time: new Date(openTime),
                update_at: new Date(),
                year: year,
                period: period,
            },
            updateId = { id: id }
        let result: any
        if (LhcTypeEnum.xglhc == lotteryType) {
            result = await this.xglhcRecordRepository.update(updateId, updateInfo)
        } else if (LhcTypeEnum.amlhc == lotteryType) {
            result = await this.amlhcRecordRepository.update(updateId, updateInfo)
        } else if (LhcTypeEnum.xamlhc == lotteryType) {
            result = await this.xamlhcRecordRepository.update(updateId, updateInfo)
        } else if (LhcTypeEnum.twlhc == lotteryType) {
            result = await this.twlhcRecordRepository.update(updateId, updateInfo)
        } else {
            result = await this.xjplhcRecordRepository.update(updateId, updateInfo)
        }
        if (result.affected <= 0) {
            return new ApiErrorResponse('更新失败!', ResponseCode.FAIL)
        }
        return new ApiSuccessResponse(result.affected)
    }
}
