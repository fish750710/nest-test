export enum DrawingCategoryEnum {
    coloring = 1, // 彩图
    blackWhite = 2, // 黑白
}
