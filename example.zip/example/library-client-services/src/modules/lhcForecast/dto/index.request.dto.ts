import { Type } from 'class-transformer'
import { IsNotEmpty, IsNumber, IsOptional, Max, Min } from 'class-validator'

export class GetListDto {
    @IsNotEmpty({ message: '请提供彩种类型' })
    readonly lotteryType: string

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    @Min(1)
    @Max(50)
    readonly pageSize?: number | null
}
