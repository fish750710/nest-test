import { Type } from 'class-transformer'
import { IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, Max, Min } from 'class-validator'

export class GetAdsListDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString({ message: 'lotteryType必须为字符串' })
    readonly lotteryType: string

    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly title?: string | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    @Min(1)
    @Max(100)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly pageIndex?: number | null
}

export class AdsCreateDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供iconUrl' })
    @IsString()
    readonly iconUrl: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString()
    readonly lotteryType: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供link' })
    @IsString()
    readonly link: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供title' })
    @IsString()
    readonly title: string

    @IsNotEmpty({ message: '请提供status' })
    @Type(() => Number)
    @Min(0)
    @Max(1)
    @IsInt({ message: 'status只能为0或1' })
    readonly status: number
}

export class AdsUpdateDto {
    @IsNotEmpty({ message: '请提供id' })
    @Type(() => Number)
    @IsInt()
    readonly id: number

    @Type(() => String)
    @IsNotEmpty({ message: '请提供iconUrl' })
    @IsString()
    readonly iconUrl: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString()
    readonly lotteryType: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供link' })
    @IsString()
    readonly link: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供title' })
    @IsString()
    readonly title: string

    @IsNotEmpty({ message: '请提供status' })
    @Type(() => Number)
    @Min(0)
    @Max(1)
    @IsInt({ message: 'status只能为0或1' })
    readonly status: number
}
