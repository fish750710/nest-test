import { Type } from 'class-transformer'
import { IsNotEmpty, IsInt, IsOptional, MaxLength, IsString } from 'class-validator'

export class AddCommentDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供评论图纸ID' })
    @IsInt()
    readonly drawingId: number

    @IsOptional()
    @Type(() => Number)
    @IsInt()
    readonly parentId?: number

    @Type(() => String)
    @IsNotEmpty({ message: '评论内容信息不能为空' })
    @MaxLength(1000)
    @IsString()
    readonly content: string
}

export class GetUserCommentDto {
    @IsOptional()
    @Type(() => Number)
    @IsInt()
    readonly pageIndex?: number | null

    @IsOptional()
    @Type(() => String)
    @IsNotEmpty({ message: '请提供彩种类型' })
    @IsString()
    readonly lotteryType?: string

    @IsOptional()
    @Type(() => Number)
    @IsInt()
    readonly maxId?: number | null
}

export class GetDrawingCommentDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供评论图纸ID' })
    @IsInt()
    readonly drawingId: number

    @IsOptional()
    @Type(() => Number)
    @IsInt()
    readonly maxId?: number | null

    @IsOptional()
    @Type(() => Number)
    @IsInt()
    readonly parentId?: number | null

    @IsOptional()
    @Type(() => Number)
    @IsInt()
    readonly pageIndex?: number | null
}
