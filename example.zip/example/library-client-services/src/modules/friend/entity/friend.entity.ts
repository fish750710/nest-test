import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

@Entity('users_map')
export class UserMap {
    @PrimaryGeneratedColumn()
    id: number

    @Column()
    friend_id: number

    @Column()
    user_id: number
}
