import { Type } from 'class-transformer'
import { IsNotEmpty, IsString, Min, IsInt, MinLength, MaxLength, Max, IsOptional, IsNumber } from 'class-validator'

export class LhcDrawingGetListDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString({ message: 'lotteryType必须为字符串' })
    readonly lotteryType: string

    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly title?: string | null

    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly period?: string | null

    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly name?: string | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    @Min(1)
    @Max(100)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly pageIndex?: number | null
}

export class LhcDrawingCreateDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供pictureUrl' })
    @IsString()
    readonly pictureUrl: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供pictureBigUrl' })
    @IsString()
    readonly pictureBigUrl: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供period' })
    @IsString()
    readonly period: string

    @IsNotEmpty({ message: '请提供year' })
    @Type(() => Number)
    @Min(1980)
    @Max(2100)
    @IsInt()
    readonly year: number

    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString()
    readonly lotteryType: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供title' })
    @IsString()
    readonly title: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供title' })
    @IsString()
    readonly name: string

    @IsNotEmpty({ message: '请提供category' })
    @Type(() => Number)
    @Min(1)
    @Max(2)
    @IsInt({ message: '1：彩图 2：黑白' })
    readonly category: number
}

export class LhcDrawingUpdateDto {
    @IsNotEmpty({ message: '请提供id' })
    @Type(() => Number)
    @IsInt()
    readonly id: number

    @Type(() => String)
    @IsNotEmpty({ message: '请提供pictureUrl' })
    @IsString()
    readonly pictureUrl: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供pictureBigUrl' })
    @IsString()
    readonly pictureBigUrl: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供period' })
    @IsString()
    readonly period: string

    @IsNotEmpty({ message: '请提供year' })
    @Type(() => Number)
    @Min(1980)
    @Max(2100)
    @IsInt()
    readonly year: number

    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString()
    readonly lotteryType: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供title' })
    @IsString()
    readonly title: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供title' })
    @IsString()
    readonly name: string

    @IsNotEmpty({ message: '请提供category' })
    @Type(() => Number)
    @Min(1)
    @Max(2)
    @IsInt({ message: '1：彩图 2：黑白' })
    readonly category: number
}
