import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { CacheModule } from '@nestjs/cache-manager'
import { LotteryVideoController } from './lotteryVideo.controller'
import { LotteryVideoService } from './lotteryVideo.service'
import { LotteryVideo } from './entity/lotteryVideo.entity'

@Module({
    imports: [TypeOrmModule.forFeature([LotteryVideo]), CacheModule.register()],
    controllers: [LotteryVideoController],
    providers: [LotteryVideoService],
})
export class LotteryVideoModule {}
