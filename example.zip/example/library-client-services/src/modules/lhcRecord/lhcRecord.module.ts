import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { CacheModule } from '@nestjs/cache-manager'
import { AmlhcRecord } from './entity/amlhc.entity'
import { TwlhcRecord } from './entity/twlhc.entity'
import { XamlhcRecord } from './entity/xamlhc.entity'
import { XglhcRecord } from './entity/xglhc.entity'
import { XjplhcRecord } from './entity/xjplhc.entity'
import { lhcRecordController } from './lhcRecord.controller'
import { LhcRecordService } from './lhcRecord.service'

@Module({
    imports: [TypeOrmModule.forFeature([AmlhcRecord, TwlhcRecord, XamlhcRecord, XglhcRecord, XjplhcRecord]), CacheModule.register()],
    controllers: [lhcRecordController],
    providers: [LhcRecordService],
})
export class LhcRecordModule {}
