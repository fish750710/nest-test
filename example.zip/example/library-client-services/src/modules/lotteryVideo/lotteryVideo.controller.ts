import { Controller, Get, HttpCode, Query, UseInterceptors, UsePipes } from '@nestjs/common'

import { CacheInterceptor } from '@nestjs/cache-manager'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { LotteryVideoService } from './lotteryVideo.service'
import { GetVideoListDto } from './dto/index.request.dto'

/**
 * 彩票视频
 */
@Controller('lhcvideo')
export class LotteryVideoController {
    constructor(private readonly lotteryVideoService: LotteryVideoService) {}

    @HttpCode(200)
    @UseInterceptors(CacheInterceptor)
    @UsePipes(new ValidationPipe()) // 使用管道验证
    @Get('getList')
    async getList(@Query() query: GetVideoListDto) {
        const { lotteryType, year, pageSize, pageIndex } = query
        return this.lotteryVideoService.getList(lotteryType, year, pageSize || 10, pageIndex || 1)
    }
}
