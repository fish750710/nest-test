import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

@Entity('friend_message')
export class FriendMessage {
    @PrimaryGeneratedColumn()
    id: number

    @Column()
    user_id: number

    @Column()
    friend_id: number

    @Column()
    content: string

    @Column()
    message_type: string

    @Column({ type: 'double', default: new Date().valueOf() })
    time: number
}
