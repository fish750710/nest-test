export enum ResponseCode {
    OK = 0,
    FAIL = 400,
    ERROR = 500,
}
