import { Type } from 'class-transformer'
import { IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, Max, Min } from 'class-validator'

export class GetLhcRecordGetListDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供彩种类型' })
    @IsString()
    readonly lotteryType: string

    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly period?: string | null

    @Type(() => Number)
    @IsOptional()
    @IsInt()
    readonly year?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    @Min(1)
    @Max(50)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly pageIndex?: number | null
}

export class LhcRecordCreateDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供openTime' })
    @IsString()
    readonly openTime: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供openNumber' })
    @IsOptional()
    @IsString()
    readonly openNumber?: string | null

    @Type(() => String)
    @IsNotEmpty({ message: '请提供彩种类型' })
    @IsString()
    readonly lotteryType: string

    @Type(() => Number)
    @IsNotEmpty({ message: '请提供year' })
    @IsInt()
    readonly year: number

    @Type(() => String)
    @IsNotEmpty({ message: '请提供period' })
    @IsString()
    readonly period: string

    @Type(() => Number)
    @IsOptional()
    @IsInt()
    readonly isSend: number | null
}

export class LhcRecordUpdateDto {
    @IsNotEmpty({ message: '请提供id' })
    @Type(() => Number)
    @IsInt()
    readonly id: number

    @Type(() => String)
    @IsNotEmpty({ message: '请提供openTime' })
    @IsString()
    readonly openTime: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供openNumber' })
    @IsOptional()
    @IsString()
    readonly openNumber?: string | null

    @Type(() => String)
    @IsNotEmpty({ message: '请提供彩种类型' })
    @IsString()
    readonly lotteryType: string

    @Type(() => Number)
    @IsNotEmpty({ message: '请提供year' })
    @IsInt()
    readonly year: number

    @Type(() => String)
    @IsNotEmpty({ message: '请提供period' })
    @IsString()
    readonly period: string

    @Type(() => Number)
    @IsOptional()
    @IsInt()
    readonly isSend: number | null
}
