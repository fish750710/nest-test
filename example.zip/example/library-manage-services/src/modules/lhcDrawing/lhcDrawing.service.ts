import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { userDataBaseName } from 'src/config'
import { FindOptionsWhere, Like, Repository } from 'typeorm'
import { LhcDrawing } from './entity/lhcDrawing.entity'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'
import { Pagination } from 'src/common/tool/pagination'
import { ApiResponse, ApiErrorResponse, ApiSuccessResponse } from 'src/common/constant/response.api'
import { ResponseCode } from 'src/common/constant/response.code'

@Injectable()
export class LhcDrawingService {
    constructor(
        @InjectRepository(LhcDrawing, userDataBaseName)
        private readonly lhcDrawingRepository: Repository<LhcDrawing>,
        @InjectRepository(LotteryTypes, userDataBaseName)
        private readonly lotteryTypesRepository: Repository<LotteryTypes>,
    ) {}

    async getList(lotteryType: string, title: string, period: string, name: string, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize
        const where: FindOptionsWhere<LhcDrawing> = {}
        where.lottery_type = lotteryType

        if (title) {
            where.title = Like(`${title}%`)
        }
        if (name) {
            where.name = Like(`${name}%`)
        }
        if (period) {
            where.period = period
        }
        query.where = where

        query.order = {
            period: 'DESC',
            id: 'DESC',
        }

        const [list, count] = await this.lhcDrawingRepository.findAndCount(query)
        return new Pagination({ data: list, count, pageIndex: pageIndex, pageSize: pageSize })
    }

    async create(
        pictureUrl: string,
        pictureBigUrl: string,
        period: string,
        year: number,
        lotteryType: string,
        title: string,
        name: string,
        category: number,
    ): Promise<ApiResponse<LhcDrawing>> {
        const exist = await this.lotteryTypesRepository.findOne({ select: ['type_key'], where: { type_key: lotteryType } })
        if (!exist) {
            return new ApiErrorResponse('提交的彩票类型不存在!', ResponseCode.FAIL)
        }

        const info = new LhcDrawing()
        info.picture_url = pictureUrl
        info.picture_big_url = pictureBigUrl
        info.period = period
        info.year = year
        info.lottery_type = lotteryType
        info.title = title
        info.category = category - 0 === 2 ? 2 : 1
        info.name = name
        const createDate = new Date()
        info.created_at = createDate
        info.update_at = createDate

        const result = await this.lhcDrawingRepository.insert(info)
        if (result.raw.insertId > 0) {
            return new ApiSuccessResponse(info)
        } else {
            return new ApiErrorResponse('创建失败!', ResponseCode.FAIL)
        }
    }

    async update(
        id: number,
        pictureUrl: string,
        pictureBigUrl: string,
        period: string,
        year: number,
        lotteryType: string,
        title: string,
        name: string,
        category: number,
    ): Promise<ApiResponse<number>> {
        const exist = await this.lotteryTypesRepository.findOne({ select: ['type_key'], where: { type_key: lotteryType } })
        if (!exist) {
            return new ApiErrorResponse('提交的彩票类型不存在!', ResponseCode.FAIL)
        }
        const adsInfo = await this.lhcDrawingRepository.findOne({ where: { id: id } })
        if (!adsInfo) {
            return new ApiErrorResponse(`六合彩图纸ID为${id}的信息不存!`, ResponseCode.FAIL)
        }
        const result = await this.lhcDrawingRepository.update(
            { id: id },
            {
                picture_url: pictureUrl,
                picture_big_url: pictureBigUrl,
                period: period,
                year: year,
                category: category - 0 === 2 ? 2 : 1,
                lottery_type: lotteryType,
                title: title,
                name: name,
                update_at: new Date(),
            },
        )
        if (result.affected <= 0) {
            return new ApiErrorResponse('图纸更新失败!', ResponseCode.FAIL)
        }
        return new ApiSuccessResponse(result.affected)
    }
}
