import { BadRequestException, Injectable, UnauthorizedException } from '@nestjs/common'
import { FindOptionsWhere, Repository } from 'typeorm'
import { InjectRepository } from '@nestjs/typeorm'
import { Pagination } from 'src/common/tool/pagination'
import { LhcDrawing } from './entity/lhcDrawing.entity'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { Collect } from '../collect/entity/collect.entity'
import { DrawingLikes } from './entity/likes.entity'
import { DrawingCategoryEnum } from './enum/index.enum'

@Injectable()
export class LhcDrawingService {
    constructor(
        private readonly redisCache: RedisCacheService,
        @InjectRepository(Collect)
        private readonly collectRepository: Repository<Collect>,
        @InjectRepository(DrawingLikes)
        private readonly drawingLikesRepository: Repository<DrawingLikes>,
        @InjectRepository(LhcDrawing)
        private readonly lhcDrawingRepository: Repository<LhcDrawing>,
    ) {}
    async getList(lotteryType: string, year: number, category: DrawingCategoryEnum, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize

        const where: FindOptionsWhere<LhcDrawing> = {}
        where.lottery_type = lotteryType
        where.year = year

        if (category) {
            where.category = category
        }

        query.select = [
            'id',
            'lottery_type',
            'period',
            'year',
            'picture_url',
            'picture_big_url',
            'title',
            'name',
            'category',
            'likes_qty',
            'comment_qty',
            'collect_qty',
            'browse_qty',
        ]

        query.where = where
        query.order = {
            year: 'DESC',
            period: 'DESC',
        }

        const [list, count] = await this.lhcDrawingRepository.findAndCount(query)
        return new Pagination({
            data: list,
            count,
            pageIndex: pageIndex,
            pageSize: pageSize,
        })
    }

    async getPeriodList(category: DrawingCategoryEnum, lotteryType: string, period: string, year: number) {
        const query: any = {}
        const where: FindOptionsWhere<LhcDrawing> = {}
        where.lottery_type = lotteryType
        where.period = period
        where.year = year
        where.category = category

        query.select = ['id', 'lottery_type', 'period', 'year', 'picture_url', 'picture_big_url', 'title', 'name', 'category']

        query.where = where
        query.order = {
            year: 'DESC',
            period: 'DESC',
        }

        return await this.lhcDrawingRepository.find(query)
    }

    async getById(_id: number): Promise<LhcDrawing> {
        const reuslt = await this.lhcDrawingRepository.findOne({
            select: [
                'id',
                'lottery_type',
                'period',
                'year',
                'picture_url',
                'picture_big_url',
                'title',
                'name',
                'category',
                'likes_qty',
                'comment_qty',
                'collect_qty',
                'browse_qty',
                'created_at',
            ],
            cache: true,
            where: [{ id: _id }],
        })
        this.lhcDrawingRepository.update({ id: _id }, { browse_qty: () => `browse_qty + 1` })
        return reuslt
    }

    // 用户是否点赞
    async checkUserIsExistLike(token: string, drawingId: number): Promise<boolean> {
        const userInfo = await this.redisCache.getUserBySession(token)

        const isExists = await this.drawingLikesRepository.findOne({ select: ['id'], where: [{ user_id: userInfo.id, drawing_id: drawingId }] })
        return !!isExists
    }

    // 点赞
    async addDrawingLike(token: string, drawingId: number): Promise<number> {
        const isExists = await this.lhcDrawingRepository.findOne({ select: ['id'], where: [{ id: drawingId }], cache: true })
        if (!isExists) throw new BadRequestException('图纸不存在!')

        const userInfo = await this.redisCache.getUserBySession(token)

        const likeInfo = new DrawingLikes()
        likeInfo.user_id = userInfo.id
        likeInfo.drawing_id = drawingId
        likeInfo.created_at = new Date().valueOf()

        const result = await this.drawingLikesRepository.insert(likeInfo)
        if (result.raw.insertId <= 0) {
            throw new UnauthorizedException('点赞失败，请重试!')
        }
        this.lhcDrawingRepository.update({ id: drawingId }, { likes_qty: () => `likes_qty + 1` })

        return result.raw.insertId
    }

    // 移除点赞
    async RemoveLike(token: string, drawingId: number): Promise<number> {
        const userInfo = await this.redisCache.getUserBySession(token)
        const result = await this.drawingLikesRepository.delete({
            user_id: userInfo.id,
            drawing_id: drawingId,
        })
        if (result.affected <= 0) {
            throw new UnauthorizedException('取消点赞失败，请重试!')
        }
        this.lhcDrawingRepository.update({ id: drawingId }, { likes_qty: () => `likes_qty - 1` })
        return result.affected
    }
}
