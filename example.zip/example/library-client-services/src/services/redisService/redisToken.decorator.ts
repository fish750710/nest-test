import { HttpException, HttpStatus, SetMetadata } from '@nestjs/common'
import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common'
import { Reflector } from '@nestjs/core'
import { RedisCacheService } from './redisCache.service'

/**
 * 验证用户必须登录 构造器方法
 * @returns
 */
export const TokenRequired = () => SetMetadata('tokenRequired', true)
@Injectable()
export class RedisTokenGuard implements CanActivate {
    constructor(
        private reflector: Reflector,
        private readonly redisCache: RedisCacheService,
    ) {}

    async canActivate(context: ExecutionContext): Promise<boolean> {
        const tokenRequired = this.reflector.get<boolean>('tokenRequired', context.getHandler())

        if (!tokenRequired) {
            return true // 不需要 Token 验证，直接通过
        }

        const request = context.switchToHttp().getRequest()
        const token = request.headers['authorization']

        if (!token) {
            throw new HttpException(`用户还未登录`, HttpStatus.FORBIDDEN)
            //throw new HttpException(`用户还未登录`, HttpStatus.OK);
        }

        // 这里添加你的 Token 验证逻辑，例如验证 Token 是否有效
        // 如果验证成功，则返回 true，否则返回 false
        const userInfo = await this.redisCache.getUserBySession(token)
        if (userInfo == null) throw new HttpException('user accessToken error', HttpStatus.FORBIDDEN)

        this.redisCache.renewToken(token)

        return true
    }
}
