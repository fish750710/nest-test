import { Type } from 'class-transformer'
import { IsEnum, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, Max, Min } from 'class-validator'
import { DrawingCategoryEnum } from '../enum/index.enum'

export class GetLhcDrawingListDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供彩种类型' })
    @IsString()
    readonly lotteryType: string

    @IsNotEmpty({ message: '请提供年份' })
    @Type(() => Number)
    @IsNumber({}, { message: '年份必须数字格式' })
    readonly year: number

    @IsOptional()
    @Type(() => Number)
    @IsEnum(DrawingCategoryEnum, { message: 'category分类错误' })
    @IsInt()
    readonly category?: DrawingCategoryEnum

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    @Min(1)
    @Max(50)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly pageIndex?: number | null
}

export class GetLhcDrawingByIdDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供图纸ID' })
    @IsInt()
    readonly drawingId: number
}

export class GetDrawingPeriodListDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供彩种类型' })
    @IsString()
    readonly lotteryType: string

    @IsOptional()
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供图纸分类' })
    @IsEnum(DrawingCategoryEnum, { message: 'category分类错误' })
    @IsInt()
    readonly category: DrawingCategoryEnum

    @Type(() => String)
    @IsNotEmpty({ message: '请提供期号' })
    @IsString()
    readonly period: string

    @Type(() => Number)
    @IsNotEmpty({ message: '请提供year' })
    @IsInt()
    readonly year: number
}

export class checkExistLikeDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供图纸ID' })
    @IsInt()
    readonly drawingId: number
}
export class AddLikeDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供图纸ID' })
    @IsInt()
    readonly drawingId: number
}

export class RemoveLikeDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供图纸ID' })
    @IsInt()
    readonly drawingId: number
}
