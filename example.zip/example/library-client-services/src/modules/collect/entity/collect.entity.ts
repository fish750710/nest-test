import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

// 收藏表
@Entity('users_collect')
export class Collect {
    @PrimaryGeneratedColumn()
    id: number

    // 用户ID
    @Column()
    user_id: number

    // 图纸ID
    @Column()
    drawing_id: number

    // 创建时间
    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    created_at: Date
}
