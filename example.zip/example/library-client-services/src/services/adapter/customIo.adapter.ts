import { IoAdapter } from '@nestjs/platform-socket.io'
import * as socketIo from 'socket.io'

export class CustomIoAdapter extends IoAdapter {
    createIOServer(port: number, options?: socketIo.ServerOptions): any {
        // 在这里可以修改 Socket.IO 的配置参数
        options.maxHttpBufferSize = 500000 // 设置连接上限大小
        return super.createIOServer(port, options)
    }
}

//  main.js
// // 使用自定义的 IoAdapter
// //app.useWebSocketAdapter(new CustomIoAdapter())
