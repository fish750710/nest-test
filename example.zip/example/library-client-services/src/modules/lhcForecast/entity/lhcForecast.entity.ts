import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

// 预测六合表
@Entity('lhc_forecast')
export class LhcForecast {
    @PrimaryGeneratedColumn()
    id: number

    // 彩种类型
    @Column()
    lottery_type: string

    // 基数
    @Column()
    period: string

    // 精选1码
    @Column()
    jx_yima: string

    // 精选5码
    @Column()
    jx_wuma: string

    // 精选10码
    @Column()
    jx_shima: string

    // 推荐1肖
    @Column()
    tj_yixiao: string

    // 推荐3肖
    @Column()
    tj_sanxiao: string

    // 推荐6肖
    @Column()
    tj_liuxiao: string

    // 推荐9肖
    @Column()
    tj_jiuxiao: string

    // 特肖
    @Column({ nullable: true })
    te_xiao: string

    // 特码
    @Column({ nullable: true })
    te_ma: string

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    created_at: Date

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    update_at: Date
}
