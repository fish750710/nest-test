export const mqConfig = {
    MQUrl: 'amqp://localhost',
}
