import { Entity } from 'typeorm'
import { LhcRecordBaseEntity } from './base.entity'

@Entity('xamlhc_record')
export class XamlhcRecord extends LhcRecordBaseEntity {
    // 可以添加特定于的字段和逻辑...
}
