export class redisKeys {
    // 香港六合彩redis key
    static readonly getCronJobsXGLhcKey = 'cronjobs:xglhc_key'

    // 澳门六合彩redis key
    static readonly getCronJobsAMLhcKey = 'cronjobs:amlhc_key'

    // 新澳门六合彩redis key
    static readonly getCronJobsXAMLhcKey = 'cronjobs:xamlhc_key'

    // 新加坡六合彩redis key
    static readonly getCronJobsXJPLhcKey = 'cronjobs:xjplhc_key'

    // 台湾六合彩redis key
    static readonly getCronJobsTWLhcKey = 'cronjobs:twlhc_key'

    // static readonly CronJobsKeys = class {
    //     readonly account: string;
    // }
}
