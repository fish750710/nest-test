import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { Ads } from './entity/ads.entity'
import { AdsController } from './ads.controller'
import { AdsService } from './ads.service'
import { userDataBaseName } from 'src/config'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'

@Module({
    imports: [TypeOrmModule.forFeature([Ads, LotteryTypes], userDataBaseName)],
    controllers: [AdsController],
    providers: [AdsService],
})
export class AdsModule {}
