import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm'
import { EntityManager, Repository } from 'typeorm'
import { MessageBody, SubscribeMessage, WebSocketGateway, WebSocketServer, ConnectedSocket } from '@nestjs/websockets'
import { User } from '../user/entity/user.entity'
import { Group, GroupMap } from '../group/entity/group.entity'
import { GroupMessage } from '../group/entity/groupMessage.entity'
import { UserMap } from '../friend/entity/friend.entity'
import { FriendMessage } from '../friend/entity/friendMessage.entity'
import { Server, Socket } from 'socket.io'
import { ResponseCode } from 'src/common/constant/response.code'
import { nameVerify } from 'src/common/tool'
import { createWriteStream } from 'fs'
import { join } from 'path'

//@WebSocketGateway(3004)
@WebSocketGateway({ path: '/wsUserChat', cors: true })
export class ChatGateway {
    constructor(
        @InjectEntityManager() private readonly entityManager: EntityManager,
        @InjectRepository(User)
        private readonly userRepository: Repository<User>,
        @InjectRepository(Group)
        private readonly groupRepository: Repository<Group>,
        @InjectRepository(GroupMap)
        private readonly groupUserRepository: Repository<GroupMap>,
        @InjectRepository(GroupMessage)
        private readonly groupMessageRepository: Repository<GroupMessage>,
        @InjectRepository(UserMap)
        private readonly friendRepository: Repository<UserMap>,
        @InjectRepository(FriendMessage)
        private readonly friendMessageRepository: Repository<FriendMessage>,
    ) {}

    @WebSocketServer()
    server: Server

    // socket连接钩子
    async handleConnection(_client: Socket): Promise<string> {
        const userRoom = _client.handshake.query.userId
        // 连接默认加入"阿童木聊天室"房间
        // _client.join(this.defaultGroup);

        // 进来统计一下在线人数
        this.getActiveGroupUser()

        // 用户独有消息房间 根据userId
        if (userRoom) {
            _client.join(userRoom)
        }
        return '连接成功'
    }

    // socket断连钩子
    async handleDisconnect(): Promise<any> {
        //this.getActiveGroupUser();
    }

    // 创建群组
    @SubscribeMessage('addGroup')
    async addGroup(@ConnectedSocket() client: Socket, @MessageBody() data: Group): Promise<any> {
        const UserInfo = await this.userRepository.findOne({ where: { id: data.user_id } })
        if (UserInfo) {
            if (!nameVerify(data.group_name)) {
                return
            }
            const isHaveGroup = await this.groupRepository.findOne({ where: { group_name: data.group_name } })
            if (isHaveGroup) {
                this.server.to(data.user_id.toString()).emit('addGroup', { code: ResponseCode.FAIL, message: '该群名字已存在', data: isHaveGroup })
                return
            }
            const result = await this.groupRepository.save(data)
            if (result) {
                this.server.to(result.user_id.toString()).emit('addGroup', { code: ResponseCode.FAIL, message: `创建群失败` })
            }
            client.join(result.group_id.toString())
            const group = await this.groupUserRepository.save(result)
            this.server.to(data.group_id.toString()).emit('addGroup', { code: ResponseCode.OK, message: `成功创建群${data.group_name}`, data: group })
            // this.getActiveGroupUser();
        } else {
            this.server.to(data.user_id.toString()).emit('addGroup', { code: ResponseCode.FAIL, message: `你没资格创建群` })
        }
    }

    // 加入群组
    @SubscribeMessage('joinGroup')
    async joinGroup(@ConnectedSocket() client: Socket, @MessageBody() data: GroupMap): Promise<any> {
        const userInfo = await this.userRepository.findOne({ where: { id: data.user_id } })
        if (userInfo) {
            const group = await this.groupRepository.findOne({ where: { group_id: data.group_id } })
            let userGroup = await this.groupUserRepository.findOne({ where: { group_id: group.group_id, user_id: data.user_id } })
            if (group) {
                if (!userGroup) {
                    data.group_id = group.group_id
                    userGroup = await this.groupUserRepository.save(data)
                }
                client.join(group.group_id.toString())
                const res = { group: group, user: userInfo }
                this.server
                    .to(group.group_id.toString())
                    .emit('joinGroup', { code: ResponseCode.OK, message: `${userInfo.nick_name}加入群${group.group_name}`, data: res })
                //this.getActiveGroupUser();
            } else {
                this.server.to(data.user_id.toString()).emit('joinGroup', { code: ResponseCode.FAIL, message: '进群失败', data: '' })
            }
        } else {
            this.server.to(data.user_id.toString()).emit('joinGroup', { code: ResponseCode.FAIL, message: '你没资格进群' })
        }
    }

    // 加入群组的socket连接
    @SubscribeMessage('joinGroupSocket')
    async joinGroupSocket(@ConnectedSocket() client: Socket, @MessageBody() data: GroupMap): Promise<any> {
        const group = await this.groupRepository.findOne({ where: { group_id: data.group_id } })
        const user = await this.userRepository.findOne({ where: { id: data.user_id } })
        if (group && user) {
            client.join(group.group_id.toString())
            const res = { group: group, user: user }
            this.server.to(group.group_id.toString()).emit('joinGroupSocket', { code: ResponseCode.OK, message: `${user}加入群${group.group_name}`, data: res })
        } else {
            this.server.to(data.user_id.toString()).emit('joinGroupSocket', { code: ResponseCode.FAIL, message: '进群失败', data: '' })
        }
    }

    // 发送群消息
    @SubscribeMessage('groupMessage')
    async sendGroupMessage(@MessageBody() data: GroupMessageDto): Promise<any> {
        const userInfo = await this.userRepository.findOne({ where: { id: data.user_id } })
        if (userInfo) {
            const userGroupMap = await this.groupUserRepository.findOne({ where: { id: data.user_id, group_id: data.group_id } })
            if (!userGroupMap || !data.group_id) {
                this.server.to(data.user_id.toString()).emit('groupMessage', { code: ResponseCode.FAIL, message: '群消息发送错误', data: '' })
                return
            }
            if (data.message_type === 'image') {
                const randomName = `${Date.now()}$${data.user_id}$${data.width}$${data.height}`
                const stream = createWriteStream(join('public/static', randomName))
                stream.write(data.content)
                data.content = randomName
            }
            data.time = new Date().valueOf() // 使用服务端时间
            await this.groupMessageRepository.save(data)
            this.server.to(data.group_id.toString()).emit('groupMessage', { code: ResponseCode.OK, message: '', data: data })
        } else {
            this.server.to(data.user_id.toString()).emit('groupMessage', { code: ResponseCode.FAIL, message: '你没资格发消息' })
        }
    }

    // 添加好友
    @SubscribeMessage('addFriend')
    async addFriend(@ConnectedSocket() client: Socket, @MessageBody() data: UserMap): Promise<any> {
        if (data.user_id === data.friend_id) {
            this.server.to(data.user_id.toString()).emit('addFriend', { code: ResponseCode.FAIL, message: '不能添加自己为好友', data: '' })
            return
        }
        const userInfo = await this.userRepository.findOne({ where: { id: data.user_id } })
        if (userInfo) {
            if (data.friend_id && data.user_id) {
                const checkIsFriend = await this.friendRepository.findOne({
                    where: [
                        { id: data.user_id, friend_id: data.friend_id },
                        { id: data.friend_id, friend_id: data.user_id },
                    ],
                })
                if (checkIsFriend) {
                    this.server.to(data.user_id.toString()).emit('addFriend', { code: ResponseCode.FAIL, message: '已经有该好友', data: data })
                    return
                }
                const roomId = data.user_id > data.friend_id ? `${data.user_id}:${data.friend_id}` : `${data.friend_id}:${data.user_id}`

                const friendInfo = await this.userRepository.findOne({ where: { id: data.friend_id } })
                if (!friendInfo) {
                    this.server.to(data.user_id.toString()).emit('addFriend', { code: ResponseCode.FAIL, message: '该好友不存在', data: '' })
                    return
                }

                // 双方都添加好友 并存入数据库
                await this.friendRepository.save(data)
                const friendData = JSON.parse(JSON.stringify(data))
                const friendId = friendData.friend_id
                friendData.friend_id = friendData.user_id
                friendData.user_id = friendId
                delete friendData.id
                await this.friendRepository.save(friendData)
                client.join(roomId)

                // 如果是删掉的好友重新加, 重新获取一遍私聊消息
                let messages = await this.entityManager
                    .createQueryBuilder(FriendMessage, 'fm')
                    .where('fm.user_id = :userId and fm.friend_id = :friendId', {
                        userId: data.user_id,
                        friendId: data.friend_id,
                    })
                    .orWhere('fm.user_id = :friendId AND fm.friend_id = :userId', {
                        userId: data.user_id,
                        friendId: data.friend_id,
                    })
                    .orderBy('fm.time', 'DESC')
                    .take(30)
                    .getMany()
                messages = messages.reverse()

                if (messages.length) {
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-ignore
                    friendInfo.messages = messages
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-ignore
                    userInfo.messages = messages
                }

                this.server
                    .to(data.user_id.toString())
                    .emit('addFriend', { code: ResponseCode.OK, message: `添加好友${friendInfo.nick_name}成功`, data: friendInfo })
                this.server
                    .to(data.friend_id.toString())
                    .emit('addFriend', { code: ResponseCode.OK, message: `${userInfo.nick_name}添加你为好友`, data: userInfo })
            }
        } else {
            this.server.to(data.user_id.toString()).emit('addFriend', { code: ResponseCode.FAIL, message: '你没资格加好友' })
        }
    }

    // 加入私聊的socket连接
    @SubscribeMessage('joinFriendSocket')
    async joinFriend(@ConnectedSocket() client: Socket, @MessageBody() data: UserMap): Promise<any> {
        if (data.friend_id && data.user_id) {
            const relation = await this.friendRepository.findOne({ where: { user_id: data.user_id, friend_id: data.friend_id } })
            const roomId = data.user_id > data.friend_id ? `${data.user_id}:${data.friend_id}` : `${data.friend_id}:${data.user_id}`
            if (relation) {
                client.join(roomId)
                this.server.to(data.user_id.toString()).emit('joinFriendSocket', { code: ResponseCode.OK, message: '进入私聊socket成功', data: relation })
            }
        }
    }

    // 发送私聊消息
    @SubscribeMessage('friendMessage')
    async friendMessage(@ConnectedSocket() client: Socket, @MessageBody() data: FriendMessageDto): Promise<any> {
        const userInfo = await this.userRepository.findOne({ where: { id: data.user_id } })
        if (userInfo) {
            if (data.user_id && data.friend_id) {
                const friendMessage = new FriendMessage()
                friendMessage.friend_id = data.friend_id
                friendMessage.user_id = data.user_id
                friendMessage.time = new Date().valueOf()
                friendMessage.message_type = data.message_type

                const roomId = data.user_id > data.friend_id ? `${data.user_id}:${data.friend_id}` : `${data.user_id}:${data.friend_id}`
                if (data.message_type === 'image') {
                    const randomName = `${Date.now()}$${roomId}$${data.width}$${data.height}`
                    const stream = createWriteStream(join('public/static', randomName))
                    stream.write(data.content)
                    friendMessage.content = randomName
                } else {
                    friendMessage.content = data.content
                }
                await this.friendMessageRepository.save(friendMessage)
                this.server.to(roomId).emit('friendMessage', { code: ResponseCode.OK, message: '', data })
            }
        } else {
            this.server.to(data.user_id.toString()).emit('friendMessage', { code: ResponseCode.FAIL, message: '你没资格发消息', data })
        }
    }

    // 获取所有群和好友数据
    @SubscribeMessage('chatData')
    async getAllData(@ConnectedSocket() client: Socket, @MessageBody() user: User): Promise<any> {
        const userInfo = await this.userRepository.findOne({ where: { id: user.id } })
        if (userInfo) {
            let groupArr: GroupDto[] = []
            let friendArr: FriendDto[] = []
            const userGather: { [key: string]: User } = {}
            let userArr: FriendDto[] = []

            const groupMap: GroupMap[] = await this.groupUserRepository.find({ where: { user_id: user.id } })
            const friendMap: UserMap[] = await this.friendRepository.find({ where: { user_id: user.id } })

            const groupPromise = groupMap.map(async (item) => {
                return await this.groupRepository.findOne({ where: { group_id: item.group_id } })
            })
            const groupMessagePromise = groupMap.map(async (item) => {
                let groupMessage = await this.entityManager
                    .createQueryBuilder(GroupMessage, 'gm')
                    .orderBy('groupMessage.time', 'DESC')
                    .where('groupMessage.groupId = :id', { id: item.group_id })
                    .take(30)
                    .getMany()

                groupMessage = groupMessage.reverse()
                // 这里获取一下发消息的用户的用户信息
                for (const message of groupMessage) {
                    if (!userGather[message.user_id]) {
                        userGather[message.user_id] = await this.userRepository.findOne({ where: { id: message.user_id } })
                    }
                }
                return groupMessage
            })

            const friendPromise = friendMap.map(async (item) => {
                return await this.userRepository.findOne({ where: { id: item.friend_id } })
            })
            const friendMessagePromise = friendMap.map(async (item) => {
                const messages = await this.entityManager
                    .createQueryBuilder(FriendMessage, 'fm')
                    .orderBy('fm.time', 'DESC')
                    .where('fm.user_id = :userId and fm.friend_id = :friendId', { userId: item.user_id, friendId: item.friend_id })
                    .orWhere('fm.user_id = :friendId and fm.friend_id = :userId', { userId: item.user_id, friendId: item.friend_id })
                    .take(30)
                    .getMany()
                return messages.reverse()
            })

            const groups: GroupDto[] = await Promise.all(groupPromise)
            const groupsMessage: Array<GroupMessageDto[]> = await Promise.all(groupMessagePromise)
            groups.map((group, index) => {
                if (groupsMessage[index] && groupsMessage[index].length) {
                    group.messages = groupsMessage[index]
                }
            })
            groupArr = groups

            const friends: FriendDto[] = await Promise.all(friendPromise)
            const friendsMessage: Array<FriendMessageDto[]> = await Promise.all(friendMessagePromise)
            friends.map((friend, index) => {
                if (friendsMessage[index] && friendsMessage[index].length) {
                    friend.messages = friendsMessage[index]
                }
            })
            friendArr = friends
            userArr = [...Object.values(userGather), ...friendArr]

            this.server.to(user.id.toString()).emit('chatData', {
                code: ResponseCode.OK,
                message: '获取聊天数据成功',
                data: { groupData: groupArr, friendData: friendArr, userData: userArr },
            })
        }
    }

    // 退群
    @SubscribeMessage('exitGroup')
    async exitGroup(@ConnectedSocket() client: Socket, @MessageBody() groupMap: GroupMap): Promise<any> {
        const user = await this.userRepository.findOne({ where: { id: groupMap.user_id } })
        const group = await this.groupRepository.findOne({ where: { group_id: groupMap.group_id } })
        const map = await this.groupUserRepository.findOne({ where: { user_id: groupMap.user_id, group_id: groupMap.group_id } })
        if (user && group && map) {
            await this.groupUserRepository.remove(map)
            this.server.to(groupMap.user_id.toString()).emit('exitGroup', { code: ResponseCode.OK, message: '退群成功', data: groupMap })
            //return this.getActiveGroupUser();
        }
        this.server.to(groupMap.user_id.toString()).emit('exitGroup', { code: ResponseCode.FAIL, message: '退群失败' })
    }

    // 删好友
    @SubscribeMessage('exitFriend')
    async exitFriend(@ConnectedSocket() client: Socket, @MessageBody() userMap: UserMap): Promise<any> {
        const user = await this.userRepository.findOne({ where: { id: userMap.user_id } })
        const friend = await this.userRepository.findOne({ where: { id: userMap.friend_id } })
        const map1 = await this.friendRepository.findOne({ where: { user_id: userMap.user_id, friend_id: userMap.friend_id } })
        const map2 = await this.friendRepository.findOne({ where: { user_id: userMap.friend_id, friend_id: userMap.user_id } })
        if (user && friend && map1 && map2) {
            await this.friendRepository.remove(map1)
            await this.friendRepository.remove(map2)
            return this.server.to(userMap.user_id.toString()).emit('exitFriend', { code: ResponseCode.OK, message: '删好友成功', data: userMap })
        }
        this.server.to(userMap.user_id.toString()).emit('exitFriend', { code: ResponseCode.FAIL, message: '删好友失败' })
    }

    // 获取在线用户
    async getActiveGroupUser() {
        // 从socket中找到连接人数
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore;
        let userIdArr = Object.values(this.server.engine.clients).map((item) => {
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore;
            return item.request._query.user_id
        })
        // 数组去重
        userIdArr = Array.from(new Set(userIdArr))

        const activeGroupUserGather = {}
        for (const userId of userIdArr) {
            const userGroupArr = await this.groupUserRepository.find({ where: { user_id: userId } })
            const user = await this.userRepository.findOne({ where: { id: userId } })
            if (user && userGroupArr.length) {
                userGroupArr.map((item) => {
                    if (!activeGroupUserGather[item.group_id]) {
                        activeGroupUserGather[item.group_id] = {}
                    }
                    activeGroupUserGather[item.group_id][userId] = user
                })
            }
        }

        // this.server.to(this.defaultGroup).emit('activeGroupUser', {
        //     msg: 'activeGroupUser',
        //     data: activeGroupUserGather,
        // })
    }
}
