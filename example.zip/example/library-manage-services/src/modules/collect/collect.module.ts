import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { CollectController } from './collect.controller'
import { CollectService } from './collect.service'
import { User } from '../user/entity/user.entity'
import { LhcDrawing } from '../lhcDrawing/entity/lhcDrawing.entity'
import { Collect } from './entity/collect.entity'
import { userDataBaseName } from 'src/config'

@Module({
    imports: [TypeOrmModule.forFeature([Collect, User, LhcDrawing], userDataBaseName)],
    controllers: [CollectController],
    providers: [CollectService],
})
export class CollectModule {}
