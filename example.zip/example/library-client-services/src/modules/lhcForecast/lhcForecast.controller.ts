import { Controller, Get, HttpCode, Query, UseInterceptors, UsePipes } from '@nestjs/common'
import { LhcForecastService } from './lhcForecast.service'
import { GetListDto } from './dto/index.request.dto'
import { CacheInterceptor } from '@nestjs/cache-manager'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'

/**
 * 预测六合
 */
@Controller('lhcforecast')
export class LhcForecastController {
    constructor(private readonly lhcForecastService: LhcForecastService) {}

    @HttpCode(200)
    @UseInterceptors(CacheInterceptor)
    @UsePipes(new ValidationPipe()) // 使用管道验证
    @Get('getList')
    async getList(@Query() query: GetListDto) {
        const { lotteryType, pageSize } = query
        return this.lhcForecastService.getList(lotteryType, pageSize || 50, 1)
    }
}
