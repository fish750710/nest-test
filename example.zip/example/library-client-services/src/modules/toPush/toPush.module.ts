import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { AmlhcRecord } from '../lhcRecord/entity/amlhc.entity'
import { TwlhcRecord } from '../lhcRecord/entity/twlhc.entity'
import { XamlhcRecord } from '../lhcRecord/entity/xamlhc.entity'
import { XglhcRecord } from '../lhcRecord/entity/xglhc.entity'
import { XjplhcRecord } from '../lhcRecord/entity/xjplhc.entity'
import { PushServiceGateway } from './toPush.gateway'
import { CryptoService } from '../cryptoService/crypto.service'

@Module({
    imports: [TypeOrmModule.forFeature([AmlhcRecord, TwlhcRecord, XamlhcRecord, XglhcRecord, XjplhcRecord])],
    providers: [PushServiceGateway, CryptoService],
})
export class ToPushModule {}
