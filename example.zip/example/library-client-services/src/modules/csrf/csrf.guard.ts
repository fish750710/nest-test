import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common'
import { Reflector } from '@nestjs/core'
import * as csurf from 'csurf'

@Injectable()
export class CsrfGuard implements CanActivate {
    private csrfProtection = csurf({ cookie: true })

    constructor(private readonly reflector: Reflector) {}

    async canActivate(context: ExecutionContext): Promise<boolean> {
        const request = context.switchToHttp().getRequest()
        const httpMethod = request.method.toLowerCase()

        if (httpMethod === 'get') {
            // Allow GET requests
            return true
        }

        // Apply Csrf protection for other HTTP methods
        return new Promise<boolean>((resolve, reject) => {
            this.csrfProtection(request, null, (err: any) => {
                if (err) {
                    reject(false) // Csrf validation failed
                } else {
                    resolve(true)
                }
            })
        })
    }
}
