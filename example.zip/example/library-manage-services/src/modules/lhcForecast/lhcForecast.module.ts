import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { LhcForecastController } from './lhcForecast.controller'
import { LhcForecast } from './entity/lhcForecast.entity'
import { LhcForecastService } from './lhcForecast.service'
import { userDataBaseName } from 'src/config'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'

@Module({
    imports: [TypeOrmModule.forFeature([LhcForecast, LotteryTypes], userDataBaseName)],
    controllers: [LhcForecastController],
    providers: [LhcForecastService],
})
export class LhcForecastModule {}
