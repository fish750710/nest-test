import { Controller, UseGuards, HttpCode, Get, Query, Post, Body, UsePipes } from '@nestjs/common'
import { JwtAuthGuard } from '../auth/jwt.guard'
import { LhcDrawingGetListDto, LhcDrawingCreateDto, LhcDrawingUpdateDto } from './dto/request.dto'
import { LhcDrawingService } from './lhcDrawing.service'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'

@Controller('lhcDrawing')
export class lhcDrawingController {
    constructor(private readonly lhcDrawingService: LhcDrawingService) {}

    @HttpCode(200)
    @Get('getList')
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async getList(@Query() query: LhcDrawingGetListDto) {
        const { lotteryType, title, period, name, pageSize, pageIndex } = query

        return this.lhcDrawingService.getList(lotteryType, title, period, name, pageSize || 20, pageIndex || 1)
    }

    // 添加六合彩图纸
    @Post('create')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async create(@Body() body: LhcDrawingCreateDto) {
        const { pictureUrl, pictureBigUrl, period, year, lotteryType, title, name, category } = body

        return this.lhcDrawingService.create(pictureUrl, pictureBigUrl, period, year, lotteryType, title, name, category)
    }

    // 更新信息
    @Post('edit')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async update(@Body() body: LhcDrawingUpdateDto) {
        const { id, pictureUrl, pictureBigUrl, period, year, lotteryType, title, name, category } = body

        return this.lhcDrawingService.update(id, pictureUrl, pictureBigUrl, period, year, lotteryType, title, name, category)
    }
}
