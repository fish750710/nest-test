import {
    Entity,
    Column,
    PrimaryGeneratedColumn,
    //BeforeInsert,
} from 'typeorm'
//import * as bcrypt from 'bcrypt';
//import { Exclude } from 'class-transformer';

// 用户表
@Entity('users')
export class User {
    @PrimaryGeneratedColumn()
    id: number

    // 帐号
    @Column()
    phone_number: string

    // 密码
    @Column()
    user_pwd: string

    // 昵称
    @Column()
    nick_name: string

    // 登录IP
    @Column()
    login_ip: string

    // 注册IP
    @Column()
    register_ip: string

    // 创建时间
    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    created_at: Date

    // 更新时间
    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    update_at: Date

    // 最后登录时间
    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    last_login_time: Date

    // 登录次数
    @Column()
    login_frequency: number

    // VIP等级
    @Column()
    vip_level: number

    // 用户状态
    @Column()
    status: number

    // 头像
    @Column({ default: '/avatar/logo_default.png' })
    avatar_icon: string

    // @BeforeInsert()
    // async hashPassword() {
    //     this.user_pwd = await bcrypt.hash(this.user_pwd, 10);
    // 验证 (await bcrypt.compare(password.toLowerCase(), userInfo.user_pwd))
    // }
}
