import { Transform, Type } from 'class-transformer'
import { IsNotEmpty, IsString, MaxLength, MinLength, Validate } from 'class-validator'
import { PasswordMatchValidator } from 'src/common/pipe/passwordMatch.validator'

export class UpdateNickNameDto {
    @Type(() => String)
    @IsNotEmpty({ message: '昵称不能为空' })
    @MinLength(2)
    @MaxLength(10)
    @IsString({ message: '请填提供昵称' })
    readonly nickName: string
}

export class UpdatePasswordDto {
    @Type(() => String)
    @IsNotEmpty({ message: '旧密码不能为空' })
    @MinLength(32)
    @MaxLength(32)
    @IsString()
    readonly oldPassword: string

    @Type(() => String)
    @IsNotEmpty({ message: '密码不能为空' })
    @MinLength(32)
    @MaxLength(32)
    @IsString()
    readonly password: string

    @Type(() => String)
    @IsNotEmpty()
    @IsString()
    @Transform(({ value }) => value.toString())
    @Validate(PasswordMatchValidator, ['password'])
    readonly confirmPassword: string
}

export class RegisterUserDto {
    @Type(() => String)
    @IsNotEmpty({ message: '手机账号不能为空' })
    @MinLength(11)
    @IsString()
    readonly phoneNumber: string

    @Type(() => String)
    @IsNotEmpty({ message: '验证码不能为空' })
    @MinLength(1)
    @MaxLength(6)
    @IsString()
    readonly validateCode: string

    @Type(() => String)
    @IsNotEmpty({ message: '昵称不能为空' })
    @MinLength(2)
    @MaxLength(20)
    @IsString({ message: '请填提供昵称' })
    readonly nickName: string

    @Type(() => String)
    @IsNotEmpty({ message: '密码不能为空' })
    @MinLength(32)
    @MaxLength(32)
    @IsString()
    readonly password: string

    @Type(() => String)
    @IsNotEmpty()
    @IsString()
    @Transform(({ value }) => value.toString())
    @Validate(PasswordMatchValidator, ['password'])
    readonly confirmPassword: string
}

export class LoginUserDto {
    @Type(() => String)
    @IsNotEmpty({ message: '手机账号不能为空' })
    @MinLength(11)
    @IsString()
    readonly phoneNumber: string

    @Type(() => String)
    @IsNotEmpty({ message: '密码不能为空' })
    @MinLength(32)
    @MaxLength(32)
    @IsString()
    readonly password: string
}

export enum UserStautsEnum {
    normal = 0, // 正常
    disabled = 1, // 禁用
}
