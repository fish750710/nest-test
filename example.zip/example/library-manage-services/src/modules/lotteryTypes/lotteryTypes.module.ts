import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { userDataBaseName } from 'src/config'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'
import { LotteryTypesController } from './lotteryTypes.controller'
import { LotteryTypesService } from './lotteryTypes.service'

@Module({
    imports: [TypeOrmModule.forFeature([LotteryTypes], userDataBaseName)],
    controllers: [LotteryTypesController],
    providers: [LotteryTypesService],
})
export class LotteryTypesModule {}
