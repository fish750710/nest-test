import { Body, Controller, HttpCode, Post, UsePipes } from '@nestjs/common'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { AuthService } from './auth.service'
import { AdminLoginDto } from './dto/request.dto'

@Controller('auth')
export class AuthController {
    constructor(private readonly authService: AuthService) {}

    // 登录
    @Post('login')
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    async adminUserLogin(@Body() body: AdminLoginDto) {
        return this.authService.login(body.userName, body.passWord)
    }
}
