import { Injectable } from '@nestjs/common'
import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm'
import { EntityManager, Repository, SelectQueryBuilder } from 'typeorm'
import { SysGroup } from './entity/sysGroup.entity'
import { SysGroupMessage } from './entity/sysGroupMessage.entity'
import { User } from '../user/entity/user.entity'

@Injectable()
export class SysGroupService {
    constructor(
        @InjectEntityManager()
        private readonly entityManager: EntityManager,
        @InjectRepository(SysGroup)
        private readonly sysGroupRepository: Repository<SysGroup>,
        @InjectRepository(SysGroupMessage)
        private readonly sysGroupMessage: Repository<SysGroupMessage>,
    ) {}

    /**
     * 获取系统 全部群聊室
     * @returns
     */
    async getAllSysGroups() {
        return await this.sysGroupRepository.find({ cache: true })
    }

    /**
     * 获取指定聊天室消息
     * @param groupId 群ID
     * @param pageIndex 第几页
     */
    async getSysGroupMessages(groupId: string, pageIndex: number) {
        const queryBuilder: SelectQueryBuilder<any> = this.entityManager
            .createQueryBuilder(SysGroupMessage, 'sgm')
            .leftJoinAndSelect(User, 'u', 'sgm.user_id = u.id')

        queryBuilder.where('sgm.sys_group_id = :groupId', { groupId }).select(`sgm.*,u.nick_name,u.avatar_icon,u.vip_level`)

        return await queryBuilder
            .orderBy('sgm.time', 'DESC')
            //.orderBy({ 'sgm.id': 'ASC', 'sgm.time': 'DESC' })
            .limit(30)
            .offset(30 * (pageIndex - 1))
            .getRawMany()
    }
}
