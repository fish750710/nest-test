import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { userDataBaseName } from 'src/config'
import { Repository } from 'typeorm'
import { LotteryTypes } from './entity/lotteryTypes.entity'

@Injectable()
export class LotteryTypesService {
    constructor(
        @InjectRepository(LotteryTypes, userDataBaseName)
        private readonly lotteryTypesRepository: Repository<LotteryTypes>,
    ) {}

    async getList(): Promise<LotteryTypes[]> {
        return await this.lotteryTypesRepository.find({ select: ['type_key', 'type_alias', 'type_name', 'official_website', 'number_qty', 'deadline_time'] })
    }
}
