import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { FindOptionsWhere, Repository } from 'typeorm'
import { AdminUser } from '../admin/entity/adminUser.entity'
import { ApiResponse, ApiSuccessResponse, ApiErrorResponse } from 'src/common/constant/response.api'
import { ResponseCode } from 'src/common/constant/response.code'
import { Pagination } from 'src/common/tool/pagination'
import { adminDataBaseName } from 'src/config'

@Injectable()
export class AdminUserService {
    constructor(
        @InjectRepository(AdminUser, adminDataBaseName)
        private readonly adminUserRepository: Repository<AdminUser>,
    ) {}

    async getList(name: string, id: number, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize
        const where: FindOptionsWhere<AdminUser> = {}

        if (id) {
            where.id = id
        }

        if (name) {
            where.name = name
        }
        query.where = where
        const [list, count] = await this.adminUserRepository.findAndCount(query)
        return new Pagination({
            data: list,
            count,
            pageIndex: pageIndex,
            pageSize: pageSize,
        })
    }

    async createUser(userName: string, passWord: string, status: number, ip: string, bindIP: string): Promise<ApiResponse<AdminUser>> {
        const user = await this.adminUserRepository.findOne({
            where: { name: userName },
        })
        if (user) {
            return new ApiErrorResponse('用户名已存在', ResponseCode.FAIL)
        }

        const userInfo = new AdminUser()
        userInfo.name = userName
        userInfo.pwd = passWord
        userInfo.status = status - 0 === 0 ? 0 : 1
        userInfo.created_at = new Date()
        userInfo.update_at = new Date()
        userInfo.created_at_ip = ip
        userInfo.bind_ip = bindIP

        const result = await this.adminUserRepository.insert(userInfo)
        if (result.raw.insertId > 0) {
            return new ApiSuccessResponse(userInfo)
        } else {
            return new ApiErrorResponse('用户创建失败!', ResponseCode.FAIL)
        }
    }

    async updateUser(id: number, passWord: string, status: number, bindIP: string): Promise<ApiResponse<number>> {
        const user = await this.adminUserRepository.findOne({ where: { id: id } })
        if (!user) {
            return new ApiErrorResponse('用户不存在', ResponseCode.FAIL)
        }
        let result = null
        if (passWord != null) {
            result = await this.adminUserRepository.update(
                { id: id },
                {
                    pwd: passWord,
                    status: status,
                    update_at: new Date(),
                    bind_ip: bindIP,
                },
            )
        } else {
            result = await this.adminUserRepository.update({ id: id }, { status: status, bind_ip: bindIP, update_at: new Date() })
        }
        if (result.affected <= 0) {
            return new ApiErrorResponse('用户信息更新失败!', ResponseCode.FAIL)
        }
        return new ApiSuccessResponse(result.affected)
    }
}
