import { Body, Controller, Get, HttpCode, Post, Query, UseGuards, UsePipes } from '@nestjs/common'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { AdsService } from './ads.service'
import { AdsCreateDto, AdsUpdateDto, GetAdsListDto } from './dto/index.request.dto'
import { JwtAuthGuard } from '../auth/jwt.guard'

/**
 * 广告
 */
@Controller('ads')
export class AdsController {
    constructor(private readonly adsService: AdsService) {}

    @Get('getList')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe()) // 使用管道验证
    async getList(@Query() query: GetAdsListDto) {
        const { lotteryType, title, pageSize, pageIndex } = query

        return this.adsService.getList(lotteryType, title, pageSize || 20, pageIndex || 1)
    }

    @Post('create')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async increase(@Body() body: AdsCreateDto) {
        const { iconUrl, title, link, lotteryType, status } = body

        return this.adsService.create(iconUrl, title, link, lotteryType, status)
    }

    @Post('edit')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async update(@Body() body: AdsUpdateDto) {
        const { id, iconUrl, title, link, lotteryType, status } = body

        return this.adsService.update(id, iconUrl, title, link, lotteryType, status)
    }
}
