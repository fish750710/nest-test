import * as crypto from 'crypto'
import { Injectable } from '@nestjs/common'

@Injectable()
export class CryptoService {
    private readonly algorithm: string = 'aes-256-cbc' // You can use other algorithms like aes-128-cbc, aes-192-cbc, etc.
    private readonly secretKey: string = '61C328717622DB48A3825B1C19394945' // Replace with your secret key (should be 32 bytes for aes-256)

    /**
     * 加密
     * @param data
     * @returns
     */
    encrypt(data: string): string {
        const iv = crypto.randomBytes(16)
        const cipher = crypto.createCipheriv(this.algorithm, this.secretKey, iv)
        let encrypted = cipher.update(data, 'utf8', 'hex')
        encrypted += cipher.final('hex')
        return iv.toString('hex') + encrypted
    }

    /**
     * 解密
     * @param encryptedData
     * @returns
     */
    decrypt(encryptedData: string): string {
        const iv = Buffer.from(encryptedData.slice(0, 32), 'hex')
        const encryptedText = encryptedData.slice(32)
        const decipher = crypto.createDecipheriv(this.algorithm, this.secretKey, iv)
        let decrypted = decipher.update(encryptedText, 'hex', 'utf8')
        decrypted += decipher.final('utf8')
        return decrypted
    }
}
