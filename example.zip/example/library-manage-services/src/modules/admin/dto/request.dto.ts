import { Type } from 'class-transformer'
import { IsNotEmpty, MinLength, MaxLength, IsString, IsNumber, IsOptional, Max, Min, IsInt } from 'class-validator'

export class AdminUserCreateDto {
    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly bindIp?: string | null

    @Type(() => String)
    @IsNotEmpty({ message: '账号不能为空' })
    @MinLength(5)
    @MaxLength(16)
    @IsString({ message: '账号不能为空' })
    readonly userName: string

    @Type(() => String)
    @IsNotEmpty({ message: '密码不能为空' })
    @MinLength(32)
    @MaxLength(32)
    @IsString({ message: '密码不能为空' })
    readonly passWord: string

    @IsNotEmpty({ message: '请提供status' })
    @Type(() => Number)
    @Min(0)
    @Max(1)
    @IsInt({ message: 'status只能为0或1' })
    readonly status: number
}

export class AdminUserUpdateDto {
    @IsNotEmpty({ message: '请提供id' })
    @Type(() => Number)
    @IsInt({ message: 'id必须为数字格式' })
    readonly id: number

    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly bindIp?: string | null

    @Type(() => String)
    @IsOptional()
    @MinLength(32)
    @MaxLength(32)
    @IsString({ message: '密码格式为md5小写32位' })
    readonly passWord?: string | null

    @IsNotEmpty({ message: '请提供status' })
    @Type(() => Number)
    @Min(0)
    @Max(1)
    @IsInt({ message: 'status只能为0或1' })
    readonly status: number
}

export class GetAdminUserListDto {
    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly name?: string | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber({}, { message: 'id必须数字格式' })
    readonly id?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsInt()
    @Min(1)
    @Max(50)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsInt()
    readonly pageIndex?: number | null
}
