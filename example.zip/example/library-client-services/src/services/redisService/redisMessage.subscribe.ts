// // redis.service.ts
// import { Injectable } from '@nestjs/common';
// import { Redis } from 'ioredis';

// @Injectable()
// export class RedisService {
//   private readonly redisSubscriber: Redis;

//   constructor() {
//     // 创建 Redis 订阅者，用于监听消息
//     this.redisSubscriber = new Redis({
//       host: 'localhost', // Redis 服务器地址
//       port: 6379, // Redis 服务器端口
//     });
//   }

//   subscribeToChannel(channel: string, callback: (message: any) => void) {
//     this.redisSubscriber.subscribe(channel, () => {
//       console.log(`Subscribed to Redis channel: ${channel}`);
//     });

//     this.redisSubscriber.on('message', (ch, message) => {
//       if (ch === channel) {
//         // 处理接收到的消息，可以调用回调函数将消息传递给其他地方
//         callback(JSON.parse(message));
//       }
//     });
//   }
// }

// constructor(private readonly redisService: RedisService) {
//     // 在 WebSocketGateway 初始化后，开始监听 Redis 频道
//     this.redisService.subscribeToChannel('example_channel', (message) => {
//       // 当从 Redis 收到消息时，将消息发送给所有 WebSocket 客户端
//       this.server.emit('message', message);
//     });
//   }

// import { Injectable } from '@nestjs/common'
// import { RedisService } from 'nestjs-redis'

// @Injectable()
// export class RedisMessagePublishService {
//     constructor(private readonly redisService: RedisService) {}

//     async publishMessage(channel: string, message: string) {
//         const client = this.redisService.getClient()
//         await client.publish(channel, message)
//     }
// }
