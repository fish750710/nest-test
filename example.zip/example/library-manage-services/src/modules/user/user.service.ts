import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { MD5 } from 'crypto-js'
import { address } from 'ip'
import { Pagination } from 'src/common/tool/pagination'
import { userDataBaseName } from 'src/config'
import { Repository, FindOptionsWhere } from 'typeorm'
import { UserStautsEnum } from './dto/request.dto'
import { User } from './entity/user.entity'
import { ApiResponse, ApiErrorResponse, ApiSuccessResponse } from 'src/common/constant/response.api'
import { ResponseCode } from 'src/common/constant/response.code'

@Injectable()
export class UserService {
    constructor(
        @InjectRepository(User, userDataBaseName)
        private readonly userRepository: Repository<User>,
    ) {}
    async getList(phoneNumber: string, id: number, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize
        const where: FindOptionsWhere<User> = {}

        if (id) {
            where.id = id
        }

        if (phoneNumber) {
            where.phone_number = phoneNumber
        }
        query.where = where
        const [list, count] = await this.userRepository.findAndCount(query)
        return new Pagination({ data: list, count, pageIndex: pageIndex, pageSize: pageSize })
    }

    async createUser(phoneNumber: string, passWord: string, nickName: string, status: number): Promise<ApiResponse<User>> {
        const isExists = await this.userRepository.findOne({ where: { phone_number: phoneNumber }, cache: true })
        if (isExists) {
            return new ApiErrorResponse('用户已存在!', ResponseCode.FAIL)
        }

        const ip = address()
        const userInfo = new User()
        userInfo.phone_number = phoneNumber
        userInfo.nick_name = nickName || ''
        userInfo.user_pwd = MD5(passWord).toString()
        userInfo.login_ip = ip
        userInfo.register_ip = ip
        userInfo.status = UserStautsEnum.disabled == status ? UserStautsEnum.disabled : UserStautsEnum.normal

        const result = await this.userRepository.insert(userInfo)

        if (result.raw.insertId > 0) {
            return new ApiSuccessResponse(userInfo)
        } else {
            return new ApiErrorResponse('创建失败!', ResponseCode.FAIL)
        }
    }

    async updateUser(id: number, passWord: string, status: number, nickName: string): Promise<ApiResponse<number>> {
        const isExists = await this.userRepository.findOne({ where: { id: id } })
        if (!isExists) {
            return new ApiErrorResponse('用户不存在!', ResponseCode.FAIL)
        }
        let result = null
        if (passWord != null) {
            result = await this.userRepository.update(
                { id: id },
                {
                    user_pwd: MD5(passWord).toString(),
                    status: UserStautsEnum.disabled == status ? UserStautsEnum.disabled : UserStautsEnum.normal,
                    update_at: new Date(),
                    nick_name: nickName,
                },
            )
        } else {
            result = await this.userRepository.update(
                { id: id },
                {
                    nick_name: nickName,
                    update_at: new Date(),
                    status: UserStautsEnum.disabled == status ? UserStautsEnum.disabled : UserStautsEnum.normal,
                },
            )
        }
        if (result.affected <= 0) {
            return new ApiErrorResponse('更新失败!', ResponseCode.FAIL)
        }
        return new ApiSuccessResponse(result.affected)
    }
}
