import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { FindOptionsWhere, Repository } from 'typeorm'
import { LotteryVideo } from './entity/lotteryVideo.entity'

@Injectable()
export class LotteryVideoService {
    constructor(
        @InjectRepository(LotteryVideo)
        private readonly lotteryVideoRepository: Repository<LotteryVideo>,
    ) {}

    async getList(lotteryType: string, year: number, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize

        const where: FindOptionsWhere<LotteryVideo> = {}
        where.lottery_type = lotteryType
        where.year = year
        query.select = ['lottery_type', 'video_picture_url', 'video_url', 'video_title', 'period', 'year']

        query.where = where
        return await this.lotteryVideoRepository.find(query)
    }
}
