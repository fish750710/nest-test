import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { CacheModule } from '@nestjs/cache-manager'
import { User } from './entity/user.entity'
import { UserController } from './user.controller'
import { UserService } from './user.service'
import { PasswordMatchValidator } from 'src/common/pipe/passwordMatch.validator'
import { APP_GUARD } from '@nestjs/core'
import { RedisTokenGuard } from '../../services/redisService/redisToken.decorator'
import { RedisCacheService } from '../../services/redisService/redisCache.service'

@Module({
    imports: [TypeOrmModule.forFeature([User]), CacheModule.register()],
    controllers: [UserController],
    providers: [
        RedisCacheService,
        {
            provide: APP_GUARD,
            useClass: RedisTokenGuard,
        },
        UserService,
        PasswordMatchValidator, // 验证输入两次密码
    ],
    exports: [
        PasswordMatchValidator, // 验证输入两次密码
    ],
})
export class UserModule {}
