// country-block.middleware.ts
import { Injectable, NestMiddleware } from '@nestjs/common'
import { Request, Response } from 'express'
import * as requestIp from 'request-ip'
import * as geoip from 'geoip-lite'

/**
 * 限制除中国外的国家请求
 */
@Injectable()
export class CountryBlockMiddleware implements NestMiddleware {
    async use(req: Request, res: Response, next: () => void) {
        const clientIp = requestIp.getClientIp(req)
        const geo = geoip.lookup(clientIp)

        if (geo && geo.country !== 'CN') {
            return res.status(403).send('Access Forbidden')
        }

        next()
    }
}

/**
// app.module.ts
import { Module, NestModule, MiddlewareConsumer } from '@nestjs/common';
import { CountryBlockMiddleware } from './middlewares/country-block.middleware';
import { AppController } from './app.controller';

@Module({
  controllers: [AppController],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(CountryBlockMiddleware)
      .forRoutes('*'); // 可以根据需要指定特定的路由路径
  }
}
 */
