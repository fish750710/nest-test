import { Type } from 'class-transformer'
import { IsNotEmpty, IsInt, IsOptional, MaxLength, IsString } from 'class-validator'

export class GetGroupsDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供groupIds' })
    @IsInt({ message: 'groupIds为数组' })
    readonly groupIds: number[]
}

export class GetGroupUserDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供groupId' })
    @IsInt({ message: 'groupId为整数' })
    readonly groupId: number
}

export class GetGroupsByNameDto {
    @Type(() => String)
    @IsNotEmpty({ message: '群名称不能为空' })
    @IsString()
    readonly groupName: string
}

export class GetGroupMessagesDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供groupId' })
    @IsInt({ message: 'groupId为整数' })
    readonly groupId: number

    @Type(() => Number)
    @IsOptional()
    @IsInt()
    readonly pageIndex?: number | null
}

export class GetSysGroupMessagesDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供groupId' })
    @IsString({ message: 'groupId不能为空' })
    readonly groupId: string

    @Type(() => Number)
    @IsOptional()
    @IsInt()
    readonly pageIndex?: number | null
}
