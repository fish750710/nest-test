/**
 * 时间转换
 * @param time 可是时间格式，可以是时间戳
 * @param cFormat "{y}-{m}-{d} {h}:{i}:{s}" | 不传返回正式时间格式
 * @returns 返回格式化strings
 */
export function parseTime(time: any, cFormat?: string) {
    if (arguments.length === 0) {
        return null
    }

    if ((time + '').length === 10) {
        time = +time * 1000
    }
    const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
    let date: any
    if (typeof time === 'object') {
        date = time
    } else {
        date = new Date(parseInt(time, 10))
    }
    const formatObj = {
        y: date.getFullYear(),
        m: date.getMonth() + 1,
        d: date.getDate(),
        h: date.getHours(),
        i: date.getMinutes(),
        s: date.getSeconds(),
        a: date.getDay(),
    }
    const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
        let value = formatObj[key]
        if (key === 'a') {
            return ['日', '一', '二', '三', '四', '五', '六'][value]
        }
        if (result.length > 0 && value < 10) {
            value = '0' + value
        }
        return value || 0
    })
    return time_str
}

/**
 * 台湾六合彩 获取下一期开奖时间
 * @param lastDrawTime 最后一期开奖时间
 * @returns
 */
export function isTuesdayOrThursday(lastDrawTime: Date) {
    const weekday = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    let flag = true
    const day = 1
    let resultNextTime: Date
    while (flag) {
        const nextOpenTime = new Date(lastDrawTime.setDate(lastDrawTime.getDate() + day))
        const weekStr = weekday[nextOpenTime.getDay()]
        if (weekStr == '星期二' || weekStr == '星期五') {
            resultNextTime = nextOpenTime
            flag = false
        }
        continue
    }
    return resultNextTime
}
