import { Body, Controller, Get, HttpCode, Post, Query, UseGuards, UsePipes } from '@nestjs/common'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { LotteryVideoService } from './lotteryVideo.service'
import { LotteryVideoCreateDto, LotteryVideoGetListDto, LotteryVideoUpdateDto } from './dto/request.dto'
import { JwtAuthGuard } from '../auth/jwt.guard'

/**
 * 彩票视频
 */
@Controller('lotteryVideo')
export class LotteryVideoController {
    constructor(private readonly lotteryVideoService: LotteryVideoService) {}

    // 获取彩票视频列表
    @Get('getList')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async getVideoList(@Query() query: LotteryVideoGetListDto) {
        const { lotteryType, year, period, title, pageSize, pageIndex } = query

        return this.lotteryVideoService.getList(lotteryType, year, period, title, pageSize || 20, pageIndex || 1)
    }

    // 添加视频
    @Post('create')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async create(@Body() body: LotteryVideoCreateDto) {
        const { pictureUrl, videoUrl, lotteryType, videoTitle, period, year } = body

        return this.lotteryVideoService.create(pictureUrl, videoUrl, lotteryType, videoTitle, period, year)
    }

    // 更新视频信息

    @Post('edit')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async update(@Body() body: LotteryVideoUpdateDto) {
        const { id, pictureUrl, videoUrl, lotteryType, videoTitle, period, year } = body

        return this.lotteryVideoService.update(id, pictureUrl, videoUrl, lotteryType, videoTitle, period, year)
    }
}
