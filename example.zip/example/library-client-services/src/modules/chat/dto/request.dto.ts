// 群组
interface GroupDto {
    group_id: number
    user_id: number // 群主id
    group_name: string
    notice: string
    messages?: GroupMessageDto[]
    time: number
}

// 群消息
interface GroupMessageDto {
    user_id: number
    group_id: number
    content: string
    width?: number
    height?: number
    message_type: string
    time: number
}

// 好友
interface FriendDto {
    id: number
    nick_name: string
    avatar_icon: string
    role?: string
    tag?: string
    messages?: FriendMessageDto[]
    created_at: Date
}

// 好友消息
interface FriendMessageDto {
    user_id: number
    friend_id: number
    content: string
    width?: number
    height?: number
    message_type: string
    time: number
}
