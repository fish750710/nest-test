import { Type } from 'class-transformer'
import { IsInt, IsNotEmpty, IsOptional } from 'class-validator'

export class GetCollectListDto {
    @IsOptional()
    @Type(() => Number)
    @IsInt()
    readonly pageIndex?: number | null

    @IsOptional()
    @Type(() => Number)
    @IsInt()
    readonly maxId?: number | null
}

export class RemoveCollectByIdDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供图纸ID' })
    @IsInt()
    readonly drawingId: number
}

export class AddCollectDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供图纸ID' })
    @IsInt()
    readonly drawingId: number
}

export class checkExistCollectDto {
    @Type(() => Number)
    @IsNotEmpty({ message: '请提供图纸ID' })
    @IsInt()
    readonly drawingId: number
}
