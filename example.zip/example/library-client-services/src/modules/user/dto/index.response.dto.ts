export class LoginAndRegisterResponseDto {
    userId: number
    phone: string
    vipLevel: number
    nickName: string
    loginFrequency: number
    loginIp: string
    lastLoginTime: string
    token: string
    avatarIcon: string
}
