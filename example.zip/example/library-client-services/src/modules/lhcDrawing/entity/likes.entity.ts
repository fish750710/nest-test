import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

// 六合彩图纸
@Entity('likes')
export class DrawingLikes {
    @PrimaryGeneratedColumn()
    id: number

    @Column()
    user_id: number

    @Column()
    drawing_id: number

    @Column({ type: 'double', default: new Date().valueOf() })
    created_at: number
}
