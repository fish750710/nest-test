import * as _ from 'lodash'

/**
 * 时间转换
 * @param time 可是时间格式，可以是时间戳
 * @param cFormat "{y}-{m}-{d} {h}:{i}:{s}" | 不传返回正式时间格式
 * @returns 返回格式化strings
 */
export function parseTime(time: any, cFormat?: string) {
    if (arguments.length === 0) {
        return null
    }

    if ((time + '').length === 10) {
        time = +time * 1000
    }
    const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
    let date
    if (typeof time === 'object') {
        date = time
    } else {
        date = new Date(parseInt(time, 10))
    }
    const formatObj = {
        y: date.getFullYear(),
        m: date.getMonth() + 1,
        d: date.getDate(),
        h: date.getHours(),
        i: date.getMinutes(),
        s: date.getSeconds(),
        a: date.getDay(),
    }
    const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
        let value = formatObj[key]
        if (key === 'a') {
            return ['日', '一', '二', '三', '四', '五', '六'][value]
        }
        if (result.length > 0 && value < 10) {
            value = '0' + value
        }
        return value || 0
    })
    return time_str
}

/**
 * 获取当前时间目录 年 月 日
 */
export function getTimeDirectoryString() {
    const currentDate = new Date()

    const year = currentDate.getFullYear()
    const month = currentDate.getMonth() + 1
    const day = currentDate.getDate()

    return `${year}${month >= 10 ? month : `0${month}`}${day >= 10 ? day : `0${day}`}`
}

/**
 * 群名/用户名校验
 * @param name
 */
export function nameVerify(name: string): boolean {
    const nameReg = /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/
    if (name.length === 0) {
        return false
    }
    if (!nameReg.test(name)) {
        return false
    }
    if (name.length > 9) {
        return false
    }
    return true
}

/**
 * 二进制数据转换类型
 * @param data
 * @returns
 */
export function decodeArrayBuffer<T>(data: ArrayBuffer, defaultObject = true): T {
    try {
        const textDecoder = new TextDecoder('utf-8')
        // 将 ArrayBuffer 解码为字符串
        const decodedMessage = textDecoder.decode(data)
        if (defaultObject) return JSON.parse(decodedMessage) as T
        return decodedMessage as T
    } catch (error) {
        return null
    }
}

/**
 * 数据转换二进制类型
 * @param data
 * @returns
 */
export function encodeArrayBuffer(data: any): ArrayBuffer {
    const textEncoder = new TextEncoder()
    // 转换为ArrayBuffer
    const message = textEncoder.encode(JSON.stringify(data))
    return message
}
