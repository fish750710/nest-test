import { v4 as uuidv4 } from 'uuid'

export const jseSsionIdConfig = {
    secretKey: 'ACW8pYmohZnoUUtshW6LdmjZPUtVbITQ',
    resave: false, // 设置为 false
    saveUninitialized: true, // 设置为 true 或根据需求进行配置
    genid: (req) => {
        return uuidv4()
    },
    cookie: {
        //secure: true, // 设置为 true，仅在 HTTPS 下生效
        //sameSite: 'none', // 要求浏览器在跨站点请求时携带 cookies
        // 设置 Cookie 的过期时间，单位为毫秒
        maxAge: 0.3 * 60 * 60 * 1000, // 30分钟
    },
}
