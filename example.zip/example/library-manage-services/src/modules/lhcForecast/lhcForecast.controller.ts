import { Body, Controller, Get, HttpCode, Post, Query, UseGuards, UsePipes } from '@nestjs/common'
import { LhcForecastService } from './lhcForecast.service'
import { LhcForecastGetListDto, LhcForecastCreateDto, LhcForecastUpdateDto } from './dto/index.dto'
import { JwtAuthGuard } from '../auth/jwt.guard'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'

/**
 * 预测六合
 */
@Controller('lhcForecast')
export class LhcForecastController {
    constructor(private readonly lhcForecastService: LhcForecastService) {}

    @Get('getList')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async getList(@Query() query: LhcForecastGetListDto) {
        const { period, lotteryType, pageSize, pageIndex } = query

        return this.lhcForecastService.getList(lotteryType, period, pageSize || 20, pageIndex || 1)
    }

    // 添加六合彩图纸
    @Post('create')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async incrementLhcDrawing(@Body() body: LhcForecastCreateDto) {
        const { period, jxYima, jxWuma, jxShima, tjYixiao, tjSanxiao, tjLiuxiao, tjJiuxiao, teXiao, teMa, lotteryType } = body

        return this.lhcForecastService.create(period, jxYima, jxWuma, jxShima, tjYixiao, tjSanxiao, tjLiuxiao, tjJiuxiao, teXiao, teMa, lotteryType)
    }

    // 更新信息
    @Post('edit')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async update(@Body() body: LhcForecastUpdateDto) {
        const { id, period, jxYima, jxWuma, jxShima, tjYixiao, tjSanxiao, tjLiuxiao, tjJiuxiao, teXiao, teMa, lotteryType } = body

        return this.lhcForecastService.update(id, period, jxYima, jxWuma, jxShima, tjYixiao, tjSanxiao, tjLiuxiao, tjJiuxiao, teXiao, teMa, lotteryType)
    }
}
