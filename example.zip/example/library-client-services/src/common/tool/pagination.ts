export class Pagination {
    public rows: any
    public totalCount: number
    public currPageSize: number
    public currIndex: number
    public isNextPage: boolean
    constructor({ data = null, count = 0, pageSize = 20, pageIndex = 1 }) {
        this.rows = data
        this.totalCount = count
        this.currIndex = pageIndex - 0
        this.currPageSize = pageSize
    }
}
