import { Injectable, NestMiddleware } from '@nestjs/common'
import { Request, Response, NextFunction } from 'express'
import * as csurf from 'csurf'
import { RequestHandler, ParamsDictionary } from 'express-serve-static-core'
import { ParsedQs } from 'qs'

@Injectable()
export class CsrfMiddleware implements NestMiddleware {
    private csrfProtection: RequestHandler<ParamsDictionary, any, any, ParsedQs, Record<string, any>>
    constructor() {
        this.csrfProtection = csurf({ cookie: true })
    }

    use(req: Request, res: Response, next: NextFunction) {
        this.csrfProtection(req, res, next)
    }
}

// // app.module.ts
// import { Module, NestModule, MiddlewareConsumer } from '@nestjs/common';
// import { CsrfMiddleware } from './csrf.middleware';

// @Module({})
// export class AppModule implements NestModule {
//   configure(consumer: MiddlewareConsumer) {
//     consumer
//       .apply(CsrfMiddleware)
//       .forRoutes('*'); // Apply the middleware to all routes, you can specify specific routes as needed
//   }
// }
