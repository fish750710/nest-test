import { BadRequestException, Injectable, Logger, UnauthorizedException } from '@nestjs/common'
import { EntityManager, Repository, SelectQueryBuilder } from 'typeorm'
import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm'
import { Collect } from './entity/collect.entity'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { LhcDrawing } from '../lhcDrawing/entity/lhcDrawing.entity'
import { ResponseCode } from 'src/common/constant/response.code'

@Injectable()
export class CollectService {
    constructor(
        @InjectEntityManager() private readonly entityManager: EntityManager,
        private readonly redisCache: RedisCacheService,
        @InjectRepository(Collect)
        private readonly collectRepository: Repository<Collect>,
        @InjectRepository(LhcDrawing)
        private readonly lhcDrawingRepository: Repository<LhcDrawing>,
    ) {}
    private readonly logger = new Logger(CollectService.name)

    async getUserCollectList(userId: number, maxId: number, pageIndex: number) {
        try {
            const queryBuilder: SelectQueryBuilder<any> = this.entityManager.createQueryBuilder(Collect, 'c')

            queryBuilder
                .leftJoinAndSelect(LhcDrawing, 'draw', 'draw.id = c.drawing_id ')
                .select(`c.id,c.drawing_id,c.created_at,draw.name,draw.picture_url`)
                .orderBy({ 'c.id': 'ASC', 'c.created_at': 'DESC' })
                .where('c.user_id = :userId', { userId: userId })

            if (maxId > 0) {
                queryBuilder.andWhere('c.id > :id', { id: maxId })
            }

            return await queryBuilder
                .limit(10)
                .offset(10 * (pageIndex - 1))
                .getRawMany()
        } catch (e) {
            this.logger.error(e)
            return {
                code: ResponseCode.ERROR,
                message: '获取收藏列表失败',
                data: [],
            }
        }
    }

    /**
     * 用户移除收藏
     * @param token
     * @param drawingId
     * @returns
     */
    async RemoveUserCollect(token: string, drawingId: number) {
        const userInfo = await this.redisCache.getUserBySession(token)
        const result = await this.collectRepository.delete({
            user_id: userInfo.id,
            drawing_id: drawingId,
        })
        if (result.affected <= 0) {
            throw new UnauthorizedException('取消收藏失败，请重试!')
        }
        this.lhcDrawingRepository.update({ id: drawingId }, { collect_qty: () => `collect_qty - 1` })

        return result.affected
    }

    async checkUserIsExistCollect(token: string, drawingId: number): Promise<boolean> {
        const userInfo = await this.redisCache.getUserBySession(token)

        const isExists = await this.collectRepository.findOne({ select: ['id'], where: [{ user_id: userInfo.id, drawing_id: drawingId }] })
        return !!isExists
    }

    async addDrawingCollect(token: string, drawingId: number) {
        const isExists = await this.lhcDrawingRepository.findOne({ select: ['id'], where: [{ id: drawingId }], cache: true })

        if (!isExists) {
            throw new BadRequestException('图纸不存在!')
        }
        // 收藏
        const userInfo = await this.redisCache.getUserBySession(token)
        const collectInfo = new Collect()
        collectInfo.user_id = userInfo.id
        collectInfo.drawing_id = drawingId
        collectInfo.created_at = new Date()

        const result = await this.collectRepository.insert(collectInfo)
        if (result.raw.insertId <= 0) {
            throw new UnauthorizedException('添加收藏失败，请重试!')
        }
        const result1 = await this.lhcDrawingRepository.update({ id: drawingId }, { collect_qty: () => `collect_qty + 1` })
        if (result1.affected <= 0) {
            throw new UnauthorizedException('更新失败!')
        }
        return result1.affected
    }
}
