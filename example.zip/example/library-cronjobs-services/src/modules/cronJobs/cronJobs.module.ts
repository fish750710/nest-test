import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { RedisCacheService } from '../redisService/redisCache.service'
import { AmlhcRecord } from './entity/amlhc.entity'
import { TwlhcRecord } from './entity/twlhc.entity'
import { XglhcRecord } from './entity/xglhc.entity'
import { XjplhcRecord } from './entity/xjplhc.entity'
import { XamlhcRecord } from './entity/xamlhc.entity'
import { ScheduleModule } from '@nestjs/schedule'
import { PuppeteerModule } from 'nest-puppeteer'
import { HttpModule } from '@nestjs/axios'
import { CronjobsService } from './cronJobs.service'

@Module({
    imports: [
        TypeOrmModule.forFeature([AmlhcRecord, TwlhcRecord, XglhcRecord, XjplhcRecord, XamlhcRecord]),
        HttpModule.register({
            timeout: 15000,
            maxRedirects: 5,
        }),
        PuppeteerModule.forRoot(),
        ScheduleModule.forRoot(),
    ],
    providers: [RedisCacheService, CronjobsService],
})
export class CronJobsModule {}
