import { Controller, Get, HttpCode, UseGuards } from '@nestjs/common'
import { LotteryTypesService } from './lotteryTypes.service'
import { JwtAuthGuard } from '../auth/jwt.guard'

@Controller('lotteryTypes')
export class LotteryTypesController {
    constructor(private readonly lotteryTypesService: LotteryTypesService) {}

    // 获取彩票类型列表
    @Get('getList')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    async getLotteryTypeList() {
        return this.lotteryTypesService.getList()
    }
}
