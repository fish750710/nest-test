import { Type } from 'class-transformer'
import { IsEnum, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, Max, MaxLength, Min, MinLength } from 'class-validator'

export enum UserStautsEnum {
    normal = 0, // 正常
    disabled = 1, // 禁用
}

export enum CreateAccountTypeEnum {
    username = 1, // 使用帐号
    phone = 2, // 使用手机号
}

export class GetUserListDto {
    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly phoneNumber?: string | null

    @Type(() => Number)
    @IsOptional()
    @IsInt()
    readonly id?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    @Min(1)
    @Max(100)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly pageIndex?: number | null
}

export class UpdateUserDto {
    @Type(() => Number)
    @IsNotEmpty({ message: 'id不能为空' })
    @IsNumber()
    readonly id: number

    @IsOptional()
    @Type(() => String)
    @MinLength(6)
    @MaxLength(16)
    @IsString()
    readonly userPwd?: string

    @IsOptional()
    @Type(() => String)
    @MaxLength(20)
    @IsString()
    readonly nickName?: string

    @IsNotEmpty({ message: '请提供status' })
    @Type(() => Number)
    @IsEnum(UserStautsEnum, { message: 'status错误' })
    @IsNumber()
    readonly status: UserStautsEnum
}
export class CreateUserDto {
    @Type(() => String)
    @IsNotEmpty({ message: '手机账号不能为空' })
    @MinLength(11)
    @IsString()
    readonly phoneNumber: string

    @Type(() => String)
    @IsNotEmpty({ message: '密码不能为空' })
    @MinLength(6)
    @MaxLength(16)
    @IsString()
    readonly userPwd: string

    @IsOptional()
    @Type(() => String)
    @MaxLength(20)
    @IsString()
    readonly nickName?: string

    @IsNotEmpty({ message: '请提供status' })
    @Type(() => Number)
    @IsEnum(UserStautsEnum, { message: 'status错误' })
    @IsNumber()
    readonly status: UserStautsEnum
}
