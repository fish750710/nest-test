import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { FindOptionsWhere, Repository } from 'typeorm'
import { XjplhcRecord } from './entity/xjplhc.entity'
import { XglhcRecord } from './entity/xglhc.entity'
import { XamlhcRecord } from './entity/xamlhc.entity'
import { TwlhcRecord } from './entity/twlhc.entity'
import { AmlhcRecord } from './entity/amlhc.entity'
import { LhcTypeEnum } from './enum/index.enum'
import { Pagination } from 'src/common/tool/pagination'

@Injectable()
export class LhcRecordService {
    constructor(
        @InjectRepository(AmlhcRecord)
        private readonly amlhcRecordRepository: Repository<AmlhcRecord>,
        @InjectRepository(TwlhcRecord)
        private readonly twlhcRecordRepository: Repository<TwlhcRecord>,
        @InjectRepository(XamlhcRecord)
        private readonly xamlhcRecordRepository: Repository<XamlhcRecord>,
        @InjectRepository(XglhcRecord)
        private readonly xglhcRecordRepository: Repository<XglhcRecord>,
        @InjectRepository(XjplhcRecord)
        private readonly xjplhcRecordRepository: Repository<XjplhcRecord>,
    ) {}

    async getList(lotteryType: string, year: number, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize

        const where: FindOptionsWhere<any> = {}
        where.year = year
        query.select = ['period', 'year', 'open_time', 'open_number']

        query.where = where
        query.order = {
            draw_time: 'DESC',
            period: 'DESC',
        }
        let list: any, count: number
        if (LhcTypeEnum.xglhc == lotteryType) {
            ;[list, count] = await this.xglhcRecordRepository.findAndCount(query)
        } else if (LhcTypeEnum.amlhc == lotteryType) {
            ;[list, count] = await this.amlhcRecordRepository.findAndCount(query)
        } else if (LhcTypeEnum.xamlhc == lotteryType) {
            ;[list, count] = await this.xamlhcRecordRepository.findAndCount(query)
        } else if (LhcTypeEnum.twlhc == lotteryType) {
            ;[list, count] = await this.twlhcRecordRepository.findAndCount(query)
        } else {
            ;[list, count] = await this.xjplhcRecordRepository.findAndCount(query)
        }
        return new Pagination({
            data: list,
            count,
            pageIndex: pageIndex,
            pageSize: pageSize,
        })
    }
}
