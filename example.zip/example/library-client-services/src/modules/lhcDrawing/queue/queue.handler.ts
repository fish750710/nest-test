// import { Injectable } from '@nestjs/common';
// import { Process, Processor } from '@nestjs/bull';
// import { InjectRepository } from '@nestjs/typeorm';
// import { LhcDrawing } from 'src/modules/lhcDrawing/entity/lhcDrawing.entity';
// import { Comment } from '../entity/comment.entity';
// import { Repository } from 'typeorm';

// @Injectable()
// @Processor('comment_queue') // 指定队列名称为 "comment_queue"
// export class CommentQueueHandler {
//   constructor(
//     @InjectRepository(LhcDrawing)
//     private readonly lhcDrawingRepository: Repository<LhcDrawing>,
//     @InjectRepository(Comment)
//     private readonly commentRepository: Repository<Comment>,
//   ) {}

//   @Process()
//   async handleQueueJob(job: any) {
//     // 处理列队中的任务
//     const { parentId, drawingId, commentCount } = job.data;
//     if (commentCount != null) {
//       await this.commentRepository.update(
//         { id: parentId },
//         { comment_count: commentCount },
//       );
//     }
//     await this.lhcDrawingRepository.update(
//       { id: drawingId },
//       { comment_qty: () => `comment_qty + 1` },
//     );
//   }
// }
