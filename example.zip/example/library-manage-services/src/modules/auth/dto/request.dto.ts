import { Type } from 'class-transformer'
import { IsNotEmpty, MinLength, MaxLength, IsString } from 'class-validator'

export class AdminLoginDto {
    @Type(() => String)
    @IsNotEmpty({ message: '账号不能为空' })
    @MinLength(5)
    @MaxLength(16)
    @IsString({ message: '账号不能为空' })
    readonly userName: string

    @Type(() => String)
    @IsNotEmpty({ message: '密码不能为空' })
    @MinLength(32)
    @MaxLength(32)
    @IsString({ message: '密码不能为空' })
    readonly passWord: string
}
