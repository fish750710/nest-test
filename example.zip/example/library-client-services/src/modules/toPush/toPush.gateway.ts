import { InjectRepository } from '@nestjs/typeorm'
import { ConnectedSocket, MessageBody, OnGatewayConnection, OnGatewayDisconnect, SubscribeMessage, WebSocketGateway, WebSocketServer } from '@nestjs/websockets'
import { Repository } from 'typeorm'
import { Server, Socket } from 'socket.io'
import { AmlhcRecord } from '../lhcRecord/entity/amlhc.entity'
import { TwlhcRecord } from '../lhcRecord/entity/twlhc.entity'
import { XamlhcRecord } from '../lhcRecord/entity/xamlhc.entity'
import { XglhcRecord } from '../lhcRecord/entity/xglhc.entity'
import { XjplhcRecord } from '../lhcRecord/entity/xjplhc.entity'
import { LhcTypeEnum } from '../lhcRecord/enum/index.enum'
import { CryptoService } from '../cryptoService/crypto.service'
import * as _ from 'lodash'
import { decodeArrayBuffer, encodeArrayBuffer } from 'src/common/tool'

//@WebSocketGateway(3003)
@WebSocketGateway({ path: '/wsToPush', cors: true })
export class PushServiceGateway implements OnGatewayConnection, OnGatewayDisconnect {
    constructor(
        @InjectRepository(AmlhcRecord)
        private readonly amlhcRecordRepository: Repository<AmlhcRecord>,
        @InjectRepository(TwlhcRecord)
        private readonly twlhcRecordRepository: Repository<TwlhcRecord>,
        @InjectRepository(XamlhcRecord)
        private readonly xamlhcRecordRepository: Repository<XamlhcRecord>,
        @InjectRepository(XglhcRecord)
        private readonly xglhcRecordRepository: Repository<XglhcRecord>,
        @InjectRepository(XjplhcRecord)
        private readonly xjplhcRecordRepository: Repository<XjplhcRecord>,
        private readonly cryptoService: CryptoService,
    ) {}

    @WebSocketServer()
    server: Server

    // socket 新连接钩子
    async handleConnection(_client: Socket): Promise<string> {
        return `连接成功:${_client.id}`
    }

    async handleDisconnect(_client: Socket): Promise<any> {
        // 处理断开连接
        //console.log('Client disconnected:', _client.id);
    }

    @SubscribeMessage('getRecord')
    async getLotteryResultHandle(@ConnectedSocket() client: Socket, @MessageBody() message: ArrayBuffer): Promise<any> {
        const data = decodeArrayBuffer<GetRecordDto>(message)
        if (data && data.lotteryType) {
            const info = await this.getLastPeriod(data.lotteryType)
            if (info && info != null) {
                // 推送当前请求者客户端推送信息
                this.server.to(client.id).emit('getRecord', encodeArrayBuffer(info))
            }
        }
    }

    @SubscribeMessage('pushClient')
    async pushClientHandle(@ConnectedSocket() client: Socket, @MessageBody() message: ArrayBuffer): Promise<any> {
        try {
            const data = decodeArrayBuffer<string>(message, false)
            if (data == null) {
                return
            }
            const pushData = JSON.parse(this.cryptoService.decrypt(data))
            if (pushData && pushData.lotteryType) {
                const info = await this.getLastPeriod(pushData.lotteryType)
                if (info && info != null) {
                    // 推送客户端
                    this.server.emit('getRecord', encodeArrayBuffer(info))
                }
            }
        } catch (e) {}
    }

    async getLastPeriod(lotteryType: string) {
        let result: any
        const condition: any = {
            select: ['period', 'year', 'draw_time', 'open_number'],
            order: {
                year: 'DESC',
                period: 'DESC',
            },
            skip: 0,
            take: 2,
            //cache: true, // 默认缓存1000ms=1s
        }
        if (LhcTypeEnum.xglhc == lotteryType) {
            result = await this.xglhcRecordRepository.find(condition)
        } else if (LhcTypeEnum.amlhc == lotteryType) {
            result = await this.amlhcRecordRepository.find(condition)
        } else if (LhcTypeEnum.xamlhc == lotteryType) {
            result = await this.xamlhcRecordRepository.find(condition)
        } else if (LhcTypeEnum.twlhc == lotteryType) {
            result = await this.twlhcRecordRepository.find(condition)
        } else {
            result = await this.xjplhcRecordRepository.find(condition)
        }
        if (result && result.length > 1) {
            const n = result[0]
            const c = result[1]
            return {
                event: 'getRecord',
                type: lotteryType,
                openNumber: c.open_number,
                currPeriod: c.period,
                currOpenTime: c.draw_time,
                nextPeriod: n.period,
                nextOpenTime: n.draw_time,
            }
        }
        return null
    }
}
