import { Injectable, OnModuleDestroy } from '@nestjs/common'
import { RedisService } from 'nestjs-redis'
import { Redis } from 'ioredis'
//import { v4 as uuidv4 } from 'uuid'
import { User } from '../../modules/user/entity/user.entity'
import * as svgCaptcha from 'svg-captcha'

@Injectable()
export class RedisCacheService implements OnModuleDestroy {
    public redisClient: Redis
    constructor(private redisService: RedisService) {
        this.getClient()
    }
    async getClient() {
        this.redisClient = this.redisService.getClient()
    }

    /**
     * token 有效期 1800 秒 = 30 分钟
     */
    get userTokenExp() {
        return 1800
    }

    /**
     * 用户登录注册创建SessionId
     * @param userInfo 用户信息
     * @returns SessionId
     */
    async createUserSession(sessionId: string, userInfo: User): Promise<string> {
        if (!this.redisClient) {
            await this.getClient()
        }
        const key = sessionId
        //|| uuidv4();
        const jsonString = JSON.stringify(userInfo)
        const dataBuffer = Buffer.from(jsonString)
        await this.redisClient.set(`loginId:${key}`, dataBuffer, 'EX', this.userTokenExp)
        return key
    }

    /**
     * 读取用户信息
     * @param sessionId
     * @returns
     */
    async getUserBySession(sessionId: string): Promise<User | null> {
        if (!this.redisClient) {
            await this.getClient()
        }
        const userInfo = await this.redisClient.get(`loginId:${sessionId}`)
        if (!userInfo) return null
        const jsonString = userInfo.toString()
        return JSON.parse(jsonString) as User
    }

    /**
     * 自动续期用户 Token，将 Token 的有效期延长一定时间
     * @param sessionId
     */
    async renewToken(sessionId: string) {
        if (!this.redisClient) {
            await this.getClient()
        }
        this.redisService.getClient().expire(`loginId:${sessionId}`, this.userTokenExp)
    }

    // /**
    //  * 获取所有登录在线用户
    //  * @returns
    //  */
    // async getOnlineUsersCount(): Promise<number> {
    //     const client = this.redisService.getClient()
    //     const keys = await client.keys('loginId:*')
    //     return keys.length
    // }

    /**
     * 删除session
     * @param sessionId
     */
    async deleteSession(sessionId: string): Promise<number> {
        if (!this.redisClient) {
            await this.getClient()
        }
        return await this.redisClient.del(`loginId:${sessionId}`)
    }

    /**
     * 设置redis值
     * @param key 唯一KEY
     * @param value 值
     * @param seconds 选填 有效期 1s
     */
    async set(key: string, value: any, seconds?: number) {
        value = JSON.stringify(value)
        if (!this.redisClient) {
            await this.getClient()
        }
        if (!seconds) {
            await this.redisClient.set(key, value)
        } else {
            await this.redisClient.set(key, value, 'EX', seconds)
        }
    }

    /**
     * 获取redis值
     * @param key 唯一KEY
     * @returns
     */
    async get(key: string) {
        if (!this.redisClient) {
            await this.getClient()
        }
        const data = await this.redisClient.get(key)
        if (!data) return
        return JSON.parse(data)
    }

    /**
     * 删除redis Key
     * @param key
     * @returns
     */
    async del(key: string) {
        if (!this.redisClient) {
            await this.getClient()
        }
        return await this.redisClient.del(key)
    }

    /**
     * 设置分布锁
     * @param resourceKey 唯一KEY
     * @param expiration 有效期 1000ms = 1s
     * @returns 分布式redis锁
     */
    async acquireLock(resourceKey: string, expiration: number): Promise<boolean> {
        if (!this.redisClient) {
            await this.getClient()
        }
        const lockKey = `lock:${resourceKey}`
        const result = await this.redisClient.set(lockKey, 'locked', 'PX', expiration, 'NX')
        return result === 'OK'
    }

    /**
     * 释放分布锁
     * @param resourceKey 唯一KEY
     * @returns
     */
    async releaseLock(resourceKey: string): Promise<boolean> {
        if (!this.redisClient) {
            await this.getClient()
        }
        const lockKey = `lock:${resourceKey}`
        const result = await this.redisClient.del(lockKey)
        return result === 1
    }

    /**
     * 生成svg验证码
     * @param sessionId
     * @returns
     */
    async generateCaptcha(sessionId: string): Promise<{ data: string; text: string }> {
        if (!this.redisClient) {
            await this.getClient()
        }
        const randomValue = Math.floor(Math.random() * 10)
        let captcha = null
        if (randomValue % 2 === 0) {
            captcha = svgCaptcha.createMathExpr({ noise: 15, color: false, ignoreChars: '0o1i' })
        } else {
            //captcha = svgCaptcha.create({ size: Math.floor(Math.random() * 3) + 4, noise: 15, color: true, ignoreChars: '0o1i' }) // 默认生成四位验证码 background: '#023b95',
            captcha = svgCaptcha.create({ size: 4, noise: 10, color: false, ignoreChars: '0o1i' })
        }
        const captchaText = captcha.text
        const key = `captcha:${sessionId}`
        // 存储验证码到 Redis，有效期为 30 秒
        await this.redisClient.set(key, captchaText, 'EX', 30)
        return captcha
    }

    /**
     * 校验 验证码
     * @param sessionId
     * @param code 用户输入的验证码值
     */
    async checkStoredCaptcha(sessionId: string, code: string): Promise<boolean> {
        const key = `captcha:${sessionId}`
        if (!this.redisClient) {
            await this.getClient()
        }
        const codeValue = await this.redisClient.get(key)
        console.log(codeValue, code, '验证码', sessionId)
        return codeValue == code
    }

    // 在应用程序关闭时自动调用该方法
    async onModuleDestroy() {
        //console.log('释放 Redis 连接')
        await this.redisClient.quit() // 释放 Redis 连接
    }

    /**
     * await this.set('username','李四');
        await this.get('username')
     * 
     * 分布式锁使用
    // async processResource(resourceKey: string): Promise<void> {
    //     const lockAcquired = await this.acquireLock(resourceKey, 5000); // 获取锁，过期时间为5秒
    //     if (lockAcquired) {
    //         try {
    //             // 执行需要独占资源的逻辑
    //             console.log('Resource locked. Performing exclusive operation...');
    //             // ...
    //         } finally {
    //             await this.releaseLock(resourceKey); // 释放锁
    //             console.log('Resource lock released.');
    //         }
    //     } else {
    //         console.log('Failed to acquire lock for the resource.');
    //     }
    // }
    */
}
