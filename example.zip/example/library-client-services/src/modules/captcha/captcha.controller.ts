import { Controller, Get, Res, Req, UsePipes } from '@nestjs/common'
import { Response, Request } from 'express'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { RedisCacheService } from 'src/services/redisService/redisCache.service'

@Controller('captcha')
export class CaptchaController {
    constructor(private readonly redisCache: RedisCacheService) {}
    @Get()
    @UsePipes(new ValidationPipe())
    async generateCaptcha(@Req() _req: Request, @Res() res: Response) {
        const sessionId = _req.session.id // 获取 JSESSIONID
        const captcha = await this.redisCache.generateCaptcha(sessionId)

        console.log(sessionId, 'sessionId')
        res.type('image/svg+xml')
        //res.header('vToken', sessionId)
        res.status(200).send(captcha.data)
    }
}
