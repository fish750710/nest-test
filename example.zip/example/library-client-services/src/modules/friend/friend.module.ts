import { Module } from '@nestjs/common'
import { FriendController } from './friend.controller'
import { FriendService } from './friend.service'
import { TypeOrmModule } from '@nestjs/typeorm'
import { UserMap } from './entity/friend.entity'
import { FriendMessage } from './entity/friendMessage.entity'
import { APP_GUARD } from '@nestjs/core'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { RedisTokenGuard } from '../../services/redisService/redisToken.decorator'

@Module({
    imports: [TypeOrmModule.forFeature([UserMap, FriendMessage])],
    controllers: [FriendController],
    providers: [
        RedisCacheService,
        {
            provide: APP_GUARD,
            useClass: RedisTokenGuard,
        },
        FriendService,
    ],
})
export class FriendModule {}
