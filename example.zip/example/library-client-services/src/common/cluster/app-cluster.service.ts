import { Injectable } from '@nestjs/common'

import cluster from 'cluster'
import * as os from 'node:os'
import * as process from 'node:process'

const numCPUs = os.cpus().length
//parseInt(process.argv[2] || "1");

@Injectable()
export class AppClusterService {
    // eslint-disable-next-line @typescript-eslint/ban-types
    static clusterize(callback: Function): void {
        // cluster.isMaster
        if (cluster.isPrimary) {
            console.log(`MASTER SERVER (${process.pid}) IS RUNNING `)

            for (let i = 0; i < numCPUs; i++) {
                cluster.fork()
            }

            cluster.on('exit', (worker, code, signal) => {
                console.log(`worker ${worker.process.pid} died`)
            })
        } else {
            callback()
        }
    }
}

/**
 * 

// node/worker_thread.js

const { parentPort } = require('worker_threads')

const hardWork = () => {
  // 100亿次毫无意义的计算
  for (let i = 0; i < 10000000000; i++) {}
}

parentPort.on('message', (message) => {
  if (message === 'START') {
    hardWork()
    parentPort.postMessage()
  }
})


// node/master_thread.js

const { Worker } = require('worker_threads')
const http = require('http')
const url = require('url')

const server = http.createServer((req, resp) => {
  const urlParsed = url.parse(req.url, true)

  if (urlParsed.pathname === '/hard_work') {
    // 对于每一个hard_work接口，我们都启动一个子线程来处理
    const worker = new Worker('./child_process')
    // 告诉子线程开始任务
    worker.postMessage('START')
    
    worker.on('message', () => {
      // 在收到子线程回复后返回结果给客户端
      resp.write('hard work')
      resp.end()
    })
  } else if (urlParsed.pathname === '/easy_work') {
    // 其它简单操作都在主线程执行
    resp.write('easy work')
    resp.end()
  } else {
    resp.end()
  }
})

server.listen(8080, () => {
  console.log('server is up...')
})
*/
