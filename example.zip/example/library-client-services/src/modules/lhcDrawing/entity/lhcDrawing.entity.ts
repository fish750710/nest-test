import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

// 六合彩图纸
@Entity('lhc_drawing')
export class LhcDrawing {
    @PrimaryGeneratedColumn()
    id: number

    // 彩种类型
    @Column()
    lottery_type: string

    // 图纸期号
    @Column()
    period: string

    // 年份
    @Column()
    year: number

    // 图纸url
    @Column()
    picture_url: string

    // 图纸大图url
    @Column()
    picture_big_url: string

    // 图纸标题
    @Column()
    title: string

    // 图纸名称
    @Column()
    name: string

    // 图纸分类 1：彩图 2：黑白
    @Column()
    category: number

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    created_at: Date

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    update_at: Date

    // 点赞次数
    @Column()
    likes_qty: number

    // 评论次数
    @Column()
    comment_qty: number

    // 收藏次数
    @Column()
    collect_qty: number

    // 分享次数
    @Column()
    share_qty: number

    // 浏览次数
    @Column()
    browse_qty: number
}
