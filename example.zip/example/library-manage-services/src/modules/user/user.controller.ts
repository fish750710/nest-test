import { Body, Controller, Get, HttpCode, Post, Query, UseGuards, UsePipes } from '@nestjs/common'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { CreateUserDto, GetUserListDto, UpdateUserDto } from './dto/request.dto'
import { UserService } from './user.service'
import { JwtAuthGuard } from '../auth/jwt.guard'

@Controller('user')
export class UserController {
    constructor(private readonly userService: UserService) {}

    // 获取用户列表
    @Get('getList')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async getUser(@Query() query: GetUserListDto) {
        const { phoneNumber, id, pageSize, pageIndex } = query

        return this.userService.getList(phoneNumber, id, pageSize || 20, pageIndex || 1)
    }

    // 创建用户
    @Post('create')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async createUser(@Body() body: CreateUserDto) {
        const { phoneNumber, nickName, userPwd, status } = body

        return this.userService.createUser(phoneNumber, userPwd, nickName, status)
    }

    // 更新用户信息
    @Post('edit')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async updateUser(@Body() body: UpdateUserDto) {
        const { id, nickName, status, userPwd } = body

        return this.userService.updateUser(id, userPwd || null, status, nickName)
    }
}
