import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

// 用户评论表
@Entity('users_comment')
export class Comment {
    @PrimaryGeneratedColumn()
    id: number

    // 图纸ID
    @Column()
    drawing_id: number

    // 父级ID
    @Column()
    parent_id: number

    // 用户ID
    @Column()
    user_id: number

    // 回复上一级用户ID
    @Column()
    to_user_id: number

    // 评论内容
    @Column()
    content: string

    // 评论者IP
    @Column()
    comment_ip: string

    // 点赞数
    @Column()
    likes_qty: number

    // 评级层级 默认0
    @Column()
    level: number

    // 评论总数
    @Column()
    comment_count: number

    // 状态 默认0  0：评论正常 1：评论无效
    @Column()
    status: number

    // 创建时间
    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            //from: value => { return getDateDiff(value.dateTimeStamp()) },
            to: (value) => {
                return value
            },
        },
    })
    created_at: Date

    // 排序值
    @Column()
    to_sort: number

    // 是否推荐
    @Column()
    is_recommend: number

    // 是否热门
    @Column()
    is_hot: number
}
