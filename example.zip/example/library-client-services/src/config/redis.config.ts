import { RedisOptions } from 'ioredis'
import { RedisModuleOptions } from 'nestjs-redis'

// RedisModule.forRoot({
//     cluster: [
//       {
//         host: '127.0.0.1',
//         port: 7000,
//       },
//       // Add other nodes here
//     ],
//   }),

export const redisConfig: RedisModuleOptions = {
    port: 6379,
    host: '127.0.0.1',
    password: '',
    db: 0,
}

export const bullConfig: RedisOptions = {
    host: '127.0.0.1',
    port: 6379,
}
