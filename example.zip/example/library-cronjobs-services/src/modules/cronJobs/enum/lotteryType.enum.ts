/**
 * 彩种类型
 */
export enum LhcTypeEnum {
    xglhc = 'xglhc',
    twlhc = 'twlhc',
    xjplhc = 'xjplhc',
    xamlhc = 'xamlhc',
    amlhc = 'amlhc',
}
