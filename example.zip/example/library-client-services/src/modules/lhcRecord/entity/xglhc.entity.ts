import { Entity } from 'typeorm'
import { LhcRecordBaseEntity } from './base.entity'

@Entity('xglhc_record')
export class XglhcRecord extends LhcRecordBaseEntity {
    // 可以添加特定于的字段和逻辑...
}
