import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { AmlhcRecord } from './entity/amlhc.entity'
import { TwlhcRecord } from './entity/twlhc.entity'
import { XamlhcRecord } from './entity/xamlhc.entity'
import { XglhcRecord } from './entity/xglhc.entity'
import { XjplhcRecord } from './entity/xjplhc.entity'
import { userDataBaseName } from 'src/config'
import { LhcRecordService } from './lhcRecord.service'
import { LhcRecordController } from './lhcRecord.controller'
import { LotteryTypes } from '../lotteryTypes/entity/lotteryTypes.entity'
import { CryptoService } from '../cryptoService/crypto.service'

@Module({
    imports: [TypeOrmModule.forFeature([AmlhcRecord, TwlhcRecord, XamlhcRecord, XglhcRecord, XjplhcRecord, LotteryTypes], userDataBaseName)],
    controllers: [LhcRecordController],
    providers: [LhcRecordService, CryptoService],
})
export class LhcRecordModule {}
