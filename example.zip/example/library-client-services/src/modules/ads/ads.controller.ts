import { Controller, Get, HttpCode, Query, UseInterceptors, UsePipes } from '@nestjs/common'

import { CacheInterceptor } from '@nestjs/cache-manager'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { AdsService } from './ads.service'
import { GetAdsListDto } from './dto/index.request.dto'

/**
 * 广告
 */
@Controller('ads')
export class AdsController {
    constructor(private readonly adsService: AdsService) {}

    @HttpCode(200)
    @UseInterceptors(CacheInterceptor)
    @UsePipes(new ValidationPipe()) // 使用管道验证
    @Get('getList')
    async getList(@Query() query: GetAdsListDto) {
        const { lotteryType, pageSize, pageIndex } = query
        return this.adsService.getList(lotteryType, pageSize || 100, pageIndex || 1)
    }
}
