import { TypeOrmModuleOptions } from '@nestjs/typeorm'

export const userDataBaseName = 'mysqlUser'
export const adminDataBaseName = 'mysqlAdmin'

export const libraryDataBase: TypeOrmModuleOptions = {
    name: userDataBaseName,
    type: 'mysql',
    port: 3306,
    host: 'localhost',
    username: 'root',
    password: '123456',
    database: 'library',
    logging: true,
    synchronize: false,
    charset: 'utf8mb4', // 设置chatset编码为utf8mb4
    autoLoadEntities: true,
}

export const libraryAdminDataBase: TypeOrmModuleOptions = {
    name: adminDataBaseName,
    type: 'mysql',
    port: 3306,
    host: 'localhost',
    username: 'root',
    password: '123456',
    database: 'library_admin',
    logging: true,
    autoLoadEntities: true,
    synchronize: false,
}
