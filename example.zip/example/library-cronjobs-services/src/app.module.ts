import { Module } from '@nestjs/common'
import { RedisModule } from 'nestjs-redis'
import { libraryDataBase, redisConfig } from './config'
import { TypeOrmModule } from '@nestjs/typeorm'
import { CronJobsModule } from './modules/cronJobs/cronJobs.module'

@Module({
    imports: [
        RedisModule.register(redisConfig), // redis配置
        TypeOrmModule.forRoot(libraryDataBase), // 数据库配置
        CronJobsModule,
    ],
})
export class AppModule {}
