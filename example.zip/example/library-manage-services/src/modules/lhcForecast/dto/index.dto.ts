import { Type } from 'class-transformer'
import { IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, Max, Min } from 'class-validator'

export class LhcForecastGetListDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString({ message: 'lotteryType必须为字符串' })
    readonly lotteryType: string

    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly period?: string | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    @Min(1)
    @Max(100)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly pageIndex?: number | null
}

export class LhcForecastCreateDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供period' })
    @IsString()
    readonly period: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供jxYima' })
    @IsString()
    readonly jxYima: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供jxWuma' })
    @IsString()
    readonly jxWuma: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供jxShima' })
    @IsString()
    readonly jxShima: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供tjYixiao' })
    @IsString()
    readonly tjYixiao: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供tjSanxiao' })
    @IsString()
    readonly tjSanxiao: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供tjLiuxiao' })
    @IsString()
    readonly tjLiuxiao: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供tjJiuxiao' })
    @IsString()
    readonly tjJiuxiao: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供teXiao' })
    @IsString()
    readonly teXiao: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供teMa' })
    @IsString()
    readonly teMa: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString()
    readonly lotteryType: string
}

export class LhcForecastUpdateDto {
    @IsNotEmpty({ message: '请提供id' })
    @Type(() => Number)
    @IsInt()
    readonly id: number

    @Type(() => String)
    @IsNotEmpty({ message: '请提供period' })
    @IsString()
    readonly period: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供jxYima' })
    @IsString()
    readonly jxYima: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供jxWuma' })
    @IsString()
    readonly jxWuma: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供jxShima' })
    @IsString()
    readonly jxShima: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供tjYixiao' })
    @IsString()
    readonly tjYixiao: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供tjSanxiao' })
    @IsString()
    readonly tjSanxiao: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供tjLiuxiao' })
    @IsString()
    readonly tjLiuxiao: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供tjJiuxiao' })
    @IsString()
    readonly tjJiuxiao: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供teXiao' })
    @IsString()
    readonly teXiao: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供teMa' })
    @IsString()
    readonly teMa: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString()
    readonly lotteryType: string
}
