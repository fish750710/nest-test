import { Repository } from 'typeorm'
import { User } from './entity/user.entity'
import { InjectRepository } from '@nestjs/typeorm'
import { Injectable, UnauthorizedException } from '@nestjs/common'
import { address } from 'ip'
import { UserStautsEnum } from './dto/index.request.dto'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { LoginAndRegisterResponseDto } from './dto/index.response.dto'
import { getTimeDirectoryString, parseTime } from 'src/common/tool'
import { createWriteStream } from 'fs'
import * as fse from 'fs-extra'
import { join } from 'path'
import { v4 as uuidv4 } from 'uuid'

@Injectable()
export class UserService {
    constructor(
        private readonly redisCache: RedisCacheService,
        @InjectRepository(User)
        private readonly userRepository: Repository<User>,
    ) {}

    async getUserInfo(userId: number, token: string): Promise<LoginAndRegisterResponseDto> {
        const userInfo = await this.userRepository.findOne({ where: { id: userId } })
        if (!userInfo) {
            throw new UnauthorizedException('登录帐号或密码错误!')
        }

        const resultDto = new LoginAndRegisterResponseDto()
        resultDto.token = token
        resultDto.lastLoginTime = parseTime(new Date(userInfo.last_login_time))
        resultDto.loginFrequency = userInfo.login_frequency
        resultDto.loginIp = userInfo.login_ip
        resultDto.nickName = userInfo.nick_name
        resultDto.phone = userInfo.phone_number
        resultDto.userId = userInfo.id
        resultDto.vipLevel = userInfo.vip_level
        resultDto.avatarIcon = userInfo.avatar_icon

        return resultDto
    }

    async registerUser(sessionId: string, phoneNumber: string, validateCode: string, password: string, nickName: string): Promise<LoginAndRegisterResponseDto> {
        const checkValidateCodeSuccess = await this.redisCache.checkStoredCaptcha(sessionId, validateCode)
        if (!checkValidateCodeSuccess) {
            throw new UnauthorizedException('验证码错误!')
        }
        const isExists = await this.userRepository.findOne({
            where: { phone_number: phoneNumber },
            cache: true,
        })
        if (isExists) {
            throw new UnauthorizedException('用户已存在!')
        }

        const ip = address()

        const userInfo = new User()
        userInfo.phone_number = phoneNumber
        userInfo.user_pwd = password.toLocaleLowerCase()
        userInfo.nick_name = nickName
        userInfo.login_ip = ip
        userInfo.register_ip = ip
        userInfo.login_frequency = 0
        userInfo.vip_level = 0
        userInfo.status = UserStautsEnum.normal
        userInfo.created_at = new Date()
        userInfo.update_at = new Date()
        userInfo.last_login_time = new Date()
        userInfo.avatar_icon = '/avatar/logo_default.png'

        const result = await this.userRepository.insert(userInfo)
        if (result.raw.insertId <= 0) {
            throw new UnauthorizedException('注册用户失败，请重试!')
        }
        sessionId = await this.redisCache.createUserSession(sessionId, userInfo)

        const resultDto = new LoginAndRegisterResponseDto()
        resultDto.token = sessionId
        resultDto.lastLoginTime = parseTime(userInfo.last_login_time)
        resultDto.loginFrequency = 0
        resultDto.loginIp = ip
        resultDto.nickName = nickName
        resultDto.phone = phoneNumber
        resultDto.userId = userInfo.id
        resultDto.vipLevel = 0
        resultDto.avatarIcon = userInfo.avatar_icon

        return resultDto
    }

    async loginUser(sessionId: string, phoneNumber: string, password: string): Promise<LoginAndRegisterResponseDto> {
        const userInfo = await this.userRepository.findOne({
            where: { phone_number: phoneNumber, user_pwd: password.toLowerCase() },
        })
        if (!userInfo) {
            throw new UnauthorizedException('登录帐号或密码错误!')
        }

        const currDate = new Date()
        const ip = address()
        const result = await this.userRepository.update(
            { id: userInfo.id },
            {
                update_at: currDate,
                last_login_time: currDate,
                login_frequency: userInfo.login_frequency + 1,
                login_ip: ip,
            },
        )

        if (result.affected <= 0) {
            throw new UnauthorizedException('更新失败!')
        }
        sessionId = await this.redisCache.createUserSession(sessionId, userInfo)
        const resultDto = new LoginAndRegisterResponseDto()
        resultDto.token = sessionId
        resultDto.lastLoginTime = parseTime(currDate)
        resultDto.loginFrequency = userInfo.login_frequency + 1
        resultDto.loginIp = ip
        resultDto.nickName = userInfo.nick_name
        resultDto.phone = userInfo.phone_number
        resultDto.userId = userInfo.id
        resultDto.vipLevel = userInfo.vip_level
        resultDto.avatarIcon = userInfo.avatar_icon

        return resultDto
    }

    async updateNickName(nickName: string, userId: number) {
        const userInfo = await this.userRepository.findOne({ where: { id: userId } })
        if (!userInfo) {
            throw new UnauthorizedException('昵称更新失败!')
        }
        const result = await this.userRepository.update(
            { id: userId },
            {
                update_at: new Date(),
                nick_name: nickName,
            },
        )
        if (result.affected <= 0) {
            throw new UnauthorizedException('昵称更新失败!')
        }
        return result.affected
    }

    async updatePassword(oldPassword: string, password: string, userId: number) {
        const userInfo = await this.userRepository.findOne({ where: { id: userId } })
        if (!userInfo) {
            throw new UnauthorizedException('密码更新失败!')
        }
        if (userInfo.user_pwd !== oldPassword) {
            throw new UnauthorizedException('旧密码不匹配!')
        }
        const result = await this.userRepository.update(
            { id: userId },
            {
                update_at: new Date(),
                user_pwd: password.toLocaleLowerCase(),
            },
        )
        if (result.affected <= 0) {
            throw new UnauthorizedException('密码更新失败!')
        }
        return result.affected
    }

    async setUserAvatar(userId: number, file: any) {
        const userInfo = await this.userRepository.findOne({ where: { id: userId } })
        if (!userInfo) {
            throw new UnauthorizedException('修改头像失败')
        }
        const directory = getTimeDirectoryString()
        // 目标文件夹路径
        const targetFolderPath = join(`public/avatar/`, directory)
        await fse.ensureDir(targetFolderPath)

        const uid = uuidv4()
        const fileName = `${uid}.${file.originalname.split('.').pop()}`
        const stream = createWriteStream(join(targetFolderPath, fileName))
        stream.write(file.buffer)
        const result = await this.userRepository.update(
            { id: userInfo.id },
            {
                update_at: new Date(),
                avatar_icon: `/avatar/${directory}/${fileName}`,
            },
        )
        if (result.affected <= 0) {
            throw new UnauthorizedException('修改头像失败!')
        }
        return result.affected
    }
}
