import { Type } from 'class-transformer'
import { IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, Max, Min } from 'class-validator'

export class LotteryVideoGetListDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString()
    readonly lotteryType: string

    @Type(() => Number)
    @IsOptional()
    @IsInt()
    readonly year?: number | null

    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly period?: string | null

    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly title?: string | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    @Min(1)
    @Max(100)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly pageIndex?: number | null
}

export class LotteryVideoCreateDto {
    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly pictureUrl?: string | null

    @Type(() => String)
    @IsNotEmpty({ message: '请提供videoUrl' })
    @IsString()
    readonly videoUrl: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString()
    readonly lotteryType: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供videoTitle' })
    @IsString()
    readonly videoTitle: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供period' })
    @IsString()
    readonly period: string

    @Type(() => Number)
    @IsNotEmpty({ message: '请提供year' })
    @IsInt()
    readonly year: number
}

export class LotteryVideoUpdateDto {
    @IsNotEmpty({ message: '请提供id' })
    @Type(() => Number)
    @IsInt()
    readonly id: number

    @Type(() => String)
    @IsOptional()
    @IsString()
    readonly pictureUrl?: string | null

    @Type(() => String)
    @IsNotEmpty({ message: '请提供videoUrl' })
    @IsString()
    readonly videoUrl: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供lotteryType' })
    @IsString()
    readonly lotteryType: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供videoTitle' })
    @IsString()
    readonly videoTitle: string

    @Type(() => String)
    @IsNotEmpty({ message: '请提供period' })
    @IsString()
    readonly period: string

    @Type(() => Number)
    @IsNotEmpty({ message: '请提供year' })
    @IsInt()
    readonly year: number
}
