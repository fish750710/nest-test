import { Module } from '@nestjs/common'
import { AuthModule } from './modules/auth/auth.module'
import { AdminModule } from './modules/admin/admin.module'
import { AdsModule } from './modules/ads/ads.module'
import { libraryAdminDataBase, libraryDataBase, redisConfig } from './config'
import { TypeOrmModule } from '@nestjs/typeorm'
import { LotteryTypesModule } from './modules/lotteryTypes/lotteryTypes.module'
import { LhcDrawingModule } from './modules/lhcDrawing/lhcDrawing.module'
import { LhcForecastModule } from './modules/lhcForecast/lhcForecast.module'
import { UserModule } from './modules/user/user.module'
import { CollectModule } from './modules/collect/collect.module'
import { CommentModule } from './modules/comment/comment.module'
import { LotteryVideoModule } from './modules/lotteryVideo/lotteryVideo.module'
import { LhcRecordModule } from './modules/lhcRecord/lhcRecord.module'
import { RedisModule } from 'nestjs-redis'

@Module({
    imports: [
        RedisModule.register(redisConfig), // redis配置
        TypeOrmModule.forRoot(libraryAdminDataBase), // 数据库配置
        TypeOrmModule.forRoot(libraryDataBase), // 数据库配置
        AuthModule,
        AdminModule,
        AdsModule,
        LotteryTypesModule,
        LhcDrawingModule,
        LhcForecastModule,
        LhcRecordModule,
        UserModule,
        CollectModule,
        CommentModule,
        LotteryVideoModule,
    ],
})
export class AppModule {}
