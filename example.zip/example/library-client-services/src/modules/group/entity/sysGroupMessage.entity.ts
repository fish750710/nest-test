import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

@Entity('sys_group_message')
export class SysGroupMessage {
    @PrimaryGeneratedColumn()
    id: number

    @Column()
    user_id: number

    @Column()
    sys_group_id: string

    @Column()
    content: string

    @Column()
    message_type: string

    @Column('double')
    time: number
}
