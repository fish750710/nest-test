import { Injectable } from '@nestjs/common'
import { JwtService } from '@nestjs/jwt'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { AdminUser } from '../admin/entity/adminUser.entity'
import { ApiResponse, ApiSuccessResponse, ApiErrorResponse } from 'src/common/constant/response.api'
import { ResponseCode } from 'src/common/constant/response.code'
import { adminDataBaseName } from 'src/config'

@Injectable()
export class AuthService {
    constructor(
        @InjectRepository(AdminUser, adminDataBaseName)
        private readonly adminUserRepository: Repository<AdminUser>,
        private readonly jwtService: JwtService,
    ) {}

    async login(userName: string, password: string): Promise<ApiResponse<any>> {
        const where = { name: userName, pwd: password }
        const user = await this.adminUserRepository.findOne({ where })
        if (!user) {
            return new ApiErrorResponse('用户名或密码错误', ResponseCode.FAIL)
        }

        if (user.status === 1) {
            return new ApiErrorResponse('用户已被锁定,请联系管理员!', ResponseCode.FAIL)
        }

        const payload = { id: user.id, name: user.name }
        const accessToken = await this.jwtService.signAsync(payload)
        return new ApiSuccessResponse({
            ...payload,
            access_token: accessToken,
            //expires: jwtConstants.expiresIn
        })
    }

    async checkUserExist(userId: number): Promise<boolean> {
        const exist = await this.adminUserRepository.findOne({
            where: { id: userId },
        })

        return !!exist
    }
}
