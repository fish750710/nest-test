import { CacheInterceptor } from '@nestjs/cache-manager'
import { AddLikeDto, GetDrawingPeriodListDto, GetLhcDrawingByIdDto, GetLhcDrawingListDto, RemoveLikeDto, checkExistLikeDto } from './dto/index.request.dto'
import { Body, Controller, Headers, Get, HttpCode, Post, Query, UseInterceptors, UsePipes } from '@nestjs/common'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { LhcDrawingService } from './lhcDrawing.service'
import { TokenRequired } from '../../services/redisService/redisToken.decorator'

/**
 * 图纸
 */
@Controller('lhcDrawing')
export class LhcDrawingController {
    constructor(private readonly lhcDrawingService: LhcDrawingService) {}

    /**
     * 获取图纸List
     * @param query
     * @returns
     */
    @HttpCode(200)
    @UseInterceptors(CacheInterceptor)
    @UsePipes(new ValidationPipe())
    @Get('getList')
    async getDrawingList(@Query() query: GetLhcDrawingListDto) {
        const { lotteryType, year, pageSize, pageIndex, category } = query

        return this.lhcDrawingService.getList(lotteryType, year, category || null, pageSize || 10, pageIndex || 1)
    }

    /**
     * 根据图纸ID 获取一条信息
     * @param query
     * @returns
     */
    @HttpCode(200)
    @UseInterceptors(CacheInterceptor)
    @UsePipes(new ValidationPipe())
    @Get('getById')
    async getDrawingById(@Query() query: GetLhcDrawingByIdDto) {
        const { drawingId } = query
        return this.lhcDrawingService.getById(drawingId)
    }

    /**
     * 根据图纸期号 查询图纸List
     * @param query
     * @returns
     */
    @HttpCode(200)
    @UseInterceptors(CacheInterceptor)
    @UsePipes(new ValidationPipe())
    @Get('getDrawingPeriodList')
    async getDrawingPeriodList(@Query() query: GetDrawingPeriodListDto) {
        const { lotteryType, period, year, category } = query
        return this.lhcDrawingService.getPeriodList(category, lotteryType, period, year)
    }

    /**
     * 移除点赞
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Post('removeLike')
    async removeCollectById(@Body() Body: RemoveLikeDto, @Headers('Authorization') token: string) {
        const { drawingId } = Body

        return this.lhcDrawingService.RemoveLike(token, drawingId)
    }

    /**
     * 检查是否点赞
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Get('checkIsExistLike')
    async checkIsExistCollect(@Query() query: checkExistLikeDto, @Headers('Authorization') token: string) {
        const { drawingId } = query

        return this.lhcDrawingService.checkUserIsExistLike(token, drawingId)
    }

    /**
     * 添加点赞
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Post('addLike')
    async addDrawingCollect(@Body() body: AddLikeDto, @Headers('Authorization') token: string) {
        const { drawingId } = body

        return this.lhcDrawingService.addDrawingLike(token, drawingId)
    }
}
