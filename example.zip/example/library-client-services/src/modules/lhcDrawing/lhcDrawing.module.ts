import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { CacheModule } from '@nestjs/cache-manager'
import { LhcDrawing } from './entity/lhcDrawing.entity'
import { LhcDrawingController } from './lhcDrawing.controller'
import { LhcDrawingService } from './lhcDrawing.service'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { APP_GUARD } from '@nestjs/core'
import { RedisTokenGuard } from '../../services/redisService/redisToken.decorator'
import { Collect } from '../collect/entity/collect.entity'
import { DrawingLikes } from './entity/likes.entity'

@Module({
    imports: [TypeOrmModule.forFeature([LhcDrawing, Collect, DrawingLikes]), CacheModule.register()],
    controllers: [LhcDrawingController],
    providers: [
        RedisCacheService,
        {
            provide: APP_GUARD,
            useClass: RedisTokenGuard,
        },
        LhcDrawingService,
    ],
})
export class LhcDrawingModule {}
