import { Body, Controller, Get, HttpCode, Post, Query, UseGuards, UsePipes } from '@nestjs/common'
import { LhcRecordService } from './lhcRecord.service'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { GetLhcRecordGetListDto, LhcRecordCreateDto, LhcRecordUpdateDto } from './dto/request.dto'
import { JwtAuthGuard } from '../auth/jwt.guard'
import { CryptoService } from '../cryptoService/crypto.service'

@Controller('lhcRecord')
export class LhcRecordController {
    constructor(
        private readonly lhcRecordService: LhcRecordService,
        private readonly cryptoService: CryptoService,
    ) {}

    // 获取开奖记录列表
    @Get('getList')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async getPrizeOpenList(@Query() query: GetLhcRecordGetListDto) {
        const { year, period, lotteryType, pageSize, pageIndex } = query

        return this.lhcRecordService.getList(year, period, lotteryType, pageSize || 20, pageIndex || 1)
    }

    // 添加开奖记录
    @Post('create')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async create(@Body() body: LhcRecordCreateDto) {
        const { openTime, openNumber, lotteryType, period, year } = body

        return this.lhcRecordService.create(openTime, year, period, lotteryType, openNumber)
    }

    // 更新开奖记录
    @Post('edit')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async update(@Body() body: LhcRecordUpdateDto) {
        const { id, openTime, openNumber, lotteryType, period, year, isSend } = body
        const result = await this.lhcRecordService.update(id, openTime, year, period, lotteryType, openNumber)

        if (result.code == 0 && isSend === 1) {
            result.data = this.cryptoService.encrypt(JSON.stringify({ time: new Date().valueOf(), lotteryType: lotteryType }))
        }

        return result
    }
}
