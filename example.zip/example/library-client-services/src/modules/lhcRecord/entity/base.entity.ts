import { Column, PrimaryGeneratedColumn } from 'typeorm'

// 六合彩彩票开奖实体
export class LhcRecordBaseEntity {
    @PrimaryGeneratedColumn()
    id: number

    // 彩票期号
    @Column()
    period: string

    // 彩票年份
    @Column()
    year: number

    // 开彩月日 0606
    @Column()
    open_time: string

    // 开彩号码
    @Column()
    open_number: string

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
                //.replace(/T/g, ' ').replace(/Z/g, '')
            },
            to: (value) => {
                return value
            },
        },
    })
    draw_time: Date

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    created_at: Date

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    update_at: Date
}
