// eslint-disable-next-line @typescript-eslint/no-unused-vars
import { Headers, Body, Controller, HttpCode, Post, UsePipes, Query, Get } from '@nestjs/common'
import { TokenRequired } from '../../services/redisService/redisToken.decorator'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { AddCollectDto, GetCollectListDto, RemoveCollectByIdDto, checkExistCollectDto } from './dto/index.request.dto'
import { CollectService } from './collect.service'
import { RedisCacheService } from '../../services/redisService/redisCache.service'

@Controller('collect')
export class CollectController {
    constructor(
        private readonly collectService: CollectService,
        private readonly redisCache: RedisCacheService,
    ) {}

    @HttpCode(200)
    @TokenRequired()
    @UsePipes(new ValidationPipe())
    @Get('getList')
    async getList(@Query() query: GetCollectListDto, @Headers('Authorization') token: string) {
        const { pageIndex, maxId } = query
        const userInfo = await this.redisCache.getUserBySession(token)
        return this.collectService.getUserCollectList(userInfo.id, maxId || 0, pageIndex || 1)
    }

    /**
     * 移除收藏
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Post('removeById')
    async removeCollectById(@Body() Body: RemoveCollectByIdDto, @Headers('Authorization') token: string) {
        const { drawingId } = Body

        return this.collectService.RemoveUserCollect(token, drawingId)
    }

    /**
     * 检查是否收藏
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Get('checkByDrawingId')
    async checkIsExistCollect(@Query() query: checkExistCollectDto, @Headers('Authorization') token: string) {
        const { drawingId } = query

        return this.collectService.checkUserIsExistCollect(token, drawingId)
    }

    /**
     * 添加收藏
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Post('addByDrawingId')
    async addDrawingCollect(@Body() body: AddCollectDto, @Headers('Authorization') token: string) {
        const { drawingId } = body

        return this.collectService.addDrawingCollect(token, drawingId)
    }
}
