import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { LhcForecastController } from './lhcForecast.controller'
import { LhcForecast } from './entity/lhcForecast.entity'
import { LhcForecastService } from './lhcForecast.service'
import { CacheModule } from '@nestjs/cache-manager'

@Module({
    imports: [
        TypeOrmModule.forFeature([LhcForecast]),
        CacheModule.register(), // {ttl: 30, // seconds max: 100, // maximum number of items in cache}
    ],
    controllers: [LhcForecastController],
    providers: [LhcForecastService],
})
export class LhcForecastModule {}
