import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

@Entity('group_message')
export class GroupMessage {
    @PrimaryGeneratedColumn()
    id: number

    @Column()
    user_id: number

    @Column()
    group_id: number

    @Column()
    content: string

    @Column()
    message_type: string

    @Column('double')
    time: number
}
