import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { SysGroup } from '../group/entity/sysGroup.entity'
import { ChatRoomGateway } from './chatroom.gateway'
import { RedisCacheService } from 'src/services/redisService/redisCache.service'
import { SysGroupMessage } from '../group/entity/sysGroupMessage.entity'
import { User } from '../user/entity/user.entity'

@Module({
    imports: [TypeOrmModule.forFeature([User, SysGroup, SysGroupMessage])],
    providers: [RedisCacheService, ChatRoomGateway],
})
export class ChatRoomModule {}
