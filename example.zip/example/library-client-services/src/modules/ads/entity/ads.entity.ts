import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

@Entity('ads')
export class Ads {
    @PrimaryGeneratedColumn()
    id: number

    // 广告ICON地址URL
    @Column()
    ad_icon_url: string

    // 广告标题
    @Column()
    ad_title: string

    // 广告链接域名
    @Column()
    ad_link: string

    // 创建时间
    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    ad_created_at: Date

    // 彩种类型
    @Column()
    ad_lottery_type: string

    // 状态 0：正常
    @Column()
    ad_status: number

    // 更新时间
    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    ad_update_at: Date

    // @Column()
    // @Generated("uuid")
    // uuid: string;
}
