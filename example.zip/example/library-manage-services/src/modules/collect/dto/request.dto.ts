import { Type } from 'class-transformer'
import { IsOptional, IsNumber, Min, Max } from 'class-validator'

export class GetCollectListDto {
    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly userId?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    @Min(1)
    @Max(100)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly pageIndex?: number | null
}
