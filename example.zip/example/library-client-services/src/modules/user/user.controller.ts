import {
    Body,
    Controller,
    HttpCode,
    Post,
    UsePipes,
    Headers,
    UseInterceptors,
    UploadedFile,
    Get,
    BadRequestException,
    Req,
    UnauthorizedException,
} from '@nestjs/common'
import { Request } from 'express'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { LoginUserDto, RegisterUserDto, UpdateNickNameDto, UpdatePasswordDto } from './dto/index.request.dto'
import { UserService } from './user.service'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { FileInterceptor } from '@nestjs/platform-express'
import { TokenRequired } from '../../services/redisService/redisToken.decorator'
import * as _ from 'lodash'
// import { diskstorage } from 'multer'
// import path from 'path'

/**
 * 用户
 */
@Controller('user')
export class UserController {
    constructor(
        private readonly redisCache: RedisCacheService,
        private readonly userService: UserService,
    ) {}

    @HttpCode(200)
    @Post('checkLogin')
    async checkLoginStatus(@Headers('Authorization') token: string) {
        const userInfo = await this.redisCache.getUserBySession(token)
        return userInfo == null ? 0 : 1
    }

    /**
     * 获取当前登录用户信息
     * @param token
     * @returns
     */
    @TokenRequired()
    @HttpCode(200)
    @Get('getUserInfo')
    async getUserInfo(@Headers('Authorization') token: string) {
        const userInfo = await this.redisCache.getUserBySession(token)

        return this.userService.getUserInfo(userInfo.id, token)
    }

    /**
     * 用户登出
     * @param token
     * @returns
     */
    @TokenRequired()
    @HttpCode(200)
    @Post('signOutUser')
    async signOutUser(@Headers('Authorization') token: string) {
        return await this.redisCache.deleteSession(token)
    }

    /**
     * 创建用户
     * @param body
     * @returns
     */
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Post('registerUser')
    async registerUser(@Body() body: RegisterUserDto, @Req() _req: Request) {
        const sessionId = _req.session.id // 获取 JSESSIONID
        if (!sessionId || !_.isString(sessionId)) {
            throw new UnauthorizedException('违规请求!')
        }
        const { phoneNumber, validateCode, password, nickName } = body

        return this.userService.registerUser(sessionId, phoneNumber, validateCode, password, nickName)
    }

    /**
     * 用户登录
     * @param body
     * @returns
     */
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Post('loginUser')
    async loginUser(@Body() body: LoginUserDto, @Req() _req: Request) {
        const sessionId = _req.session.id // 获取 JSESSIONID
        if (!sessionId || !_.isString(sessionId)) {
            throw new UnauthorizedException('违规请求!')
        }
        const { phoneNumber, password } = body

        return this.userService.loginUser(sessionId, phoneNumber, password)
    }

    /**
     * 修改昵称
     * @param body
     * @param token
     * @returns
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Post('editNickName')
    async updateNickName(@Body() body: UpdateNickNameDto, @Headers('Authorization') token: string) {
        const { nickName } = body

        const userInfo = await this.redisCache.getUserBySession(token)
        return this.userService.updateNickName(nickName, userInfo.id)
    }

    /**
     * 修改密码
     * @param body
     * @param token
     * @returns
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Post('editPassword')
    async updatePassword(@Body() body: UpdatePasswordDto, @Headers('Authorization') token: string) {
        const { oldPassword, password } = body

        const userInfo = await this.redisCache.getUserBySession(token)

        return this.userService.updatePassword(oldPassword, password, userInfo.id)
    }

    /**
     * 修改头像
     * @param file
     * @param token
     * @returns
     */
    @TokenRequired()
    @HttpCode(200)
    @Post('/editAvatar')
    @UseInterceptors(
        FileInterceptor('avatar', {
            // storage: diskStorage({
            //     //destination: './uploads', // 上传文件保存的目录
            //     filename: (req, file, cb) => {
            //         const fileExtension = file.mimetype
            //         console.log(fileExtension)
            //         const allowedExtensions = ['.jpeg', '.jpg', '.bmp', '.png', '.gif']
            //         if (!allowedExtensions.includes(fileExtension)) {
            //             return cb(new BadRequestException('文件格式只允许：.jpeg、.jpg、.bmp、.png、.gif'), null)
            //         }

            //         cb(null, file.originalname)
            //     },
            // }),
            fileFilter: (_req, file, cb) => {
                if (!['image/jpeg', 'image/png', 'image/jpg', 'image/bmp', 'image/gif'].includes(file.mimetype)) {
                    return cb(new BadRequestException('文件格式只允许：.jpeg、.jpg、.bmp、.png、.gif'), false)
                }
                cb(null, true)
            },
            limits: {
                fileSize: 1024 * 100, // 限制文件大小为100240 = 100kb
            },
        }),
    )
    async setUserAvatar(@UploadedFile() file: any, @Headers('Authorization') token: string) {
        const userInfo = await this.redisCache.getUserBySession(token)

        return this.userService.setUserAvatar(userInfo.id, file)
    }
}
