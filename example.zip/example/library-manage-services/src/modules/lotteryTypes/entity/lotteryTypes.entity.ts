import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

// 彩票类型
@Entity('lottery_types')
export class LotteryTypes {
    @PrimaryGeneratedColumn()
    id: number

    // 彩种类型唯一KEY
    @Column()
    type_key: string

    // 类型别名
    @Column()
    type_alias: string

    // 类型名称
    @Column()
    type_name: string

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    created_at: Date

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    update_at: Date

    // 官网
    @Column()
    official_website: string

    // 开奖号码个数
    @Column()
    number_qty: number

    // 截止時間
    @Column()
    deadline_time: string
}
