import { Injectable, OnModuleDestroy } from '@nestjs/common'
import { RedisService } from 'nestjs-redis'
import { Redis } from 'ioredis'

@Injectable()
export class RedisCacheService implements OnModuleDestroy {
    public redisClient: Redis
    constructor(private redisService: RedisService) {
        this.getClient()
    }
    async getClient() {
        this.redisClient = this.redisService.getClient()
    }

    /**
     * token 有效期 1800 秒 = 30 分钟
     */
    get userTokenExp() {
        return 1800
    }

    /**
     * 删除session
     * @param sessionId
     */
    async deleteSession(sessionId: string): Promise<void> {
        if (!this.redisClient) {
            await this.getClient()
        }
        const redisClient = this.redisService.getClient()
        await redisClient.del(sessionId)
    }

    /**
     * 设置redis值
     * @param key 唯一KEY
     * @param value 值
     * @param seconds 选填 有效期 1s
     */
    async set(key: string, value: any, seconds?: number) {
        value = JSON.stringify(value)
        if (!this.redisClient) {
            await this.getClient()
        }
        if (!seconds) {
            await this.redisClient.set(key, value)
        } else {
            await this.redisClient.set(key, value, 'EX', seconds)
        }
    }

    /**
     * 获取redis值
     * @param key 唯一KEY
     * @returns
     */
    async get(key: string) {
        if (!this.redisClient) {
            await this.getClient()
        }
        const data = await this.redisClient.get(key)
        if (!data) return
        return JSON.parse(data)
    }

    /**
     * 设置分布锁
     * @param resourceKey 唯一KEY
     * @param expiration 有效期 1000ms = 1s
     * @returns 分布式redis锁
     */
    async acquireLock(resourceKey: string, expiration: number): Promise<boolean> {
        if (!this.redisClient) {
            await this.getClient()
        }
        const lockKey = `lock:${resourceKey}`
        const result = await this.redisClient.set(lockKey, 'locked', 'PX', expiration, 'NX')
        return result === 'OK'
    }

    /**
     * 释放分布锁
     * @param resourceKey 唯一KEY
     * @returns
     */
    async releaseLock(resourceKey: string): Promise<boolean> {
        if (!this.redisClient) {
            await this.getClient()
        }
        const lockKey = `lock:${resourceKey}`
        const result = await this.redisClient.del(lockKey)
        return result === 1
    }

    // 在应用程序关闭时自动调用该方法
    async onModuleDestroy() {
        if (!this.redisClient) {
            await this.getClient()
        }
        console.log('释放 Redis 连接')
        await this.redisClient.quit() // 释放 Redis 连接
    }

    /**
     * await this.set('username','李四');
        await this.get('username')
     * 
     * 分布式锁使用
    // async processResource(resourceKey: string): Promise<void> {
    //     const lockAcquired = await this.acquireLock(resourceKey, 5000); // 获取锁，过期时间为5秒
    //     if (lockAcquired) {
    //         try {
    //             // 执行需要独占资源的逻辑
    //             console.log('Resource locked. Performing exclusive operation...');
    //             // ...
    //         } finally {
    //             await this.releaseLock(resourceKey); // 释放锁
    //             console.log('Resource lock released.');
    //         }
    //     } else {
    //         console.log('Failed to acquire lock for the resource.');
    //     }
    // }
    */
}
