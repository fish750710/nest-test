import { NestFactory } from '@nestjs/core'
import { AppModule } from './app.module'
import { createLogger, transports, format } from 'winston'
import 'winston-daily-rotate-file'

async function bootstrap() {
    const app = await NestFactory.create(AppModule, {
        abortOnError: true,
        logger: createLogger({
            transports: [
                new transports.DailyRotateFile({
                    level: 'info',
                    format: format.combine(format.timestamp(), format.json()),
                    filename: 'logs/log-%DATE%.log',
                    datePattern: 'YYYY-MM-DD',
                    zippedArchive: true,
                    maxSize: '100m',
                    maxFiles: '30d',
                }),
                new transports.Console({
                    format: format.combine(
                        format.cli(),
                        format.splat(),
                        format.timestamp(),
                        format.printf((info) => {
                            return `${info.timestamp} ${info.level}: ${info.message}`
                        }),
                    ),
                }),
            ],
        }),
    })
    await app.listen(9090)
}
bootstrap()
