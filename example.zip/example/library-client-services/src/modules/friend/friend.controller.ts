import { Controller, Get, Query, Headers, HttpCode, UsePipes, ValidationPipe } from '@nestjs/common'
import { FriendService } from './friend.service'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { TokenRequired } from '../../services/redisService/redisToken.decorator'
import { GetFriendMessagesDto } from './dto/request.dto'

@Controller('friend')
export class FriendController {
    constructor(
        private readonly redisCache: RedisCacheService,
        private readonly friendService: FriendService,
    ) {}

    /**
     * 获取好友
     * @param token
     * @returns
     */
    @TokenRequired()
    @HttpCode(200)
    @Get('getFriends')
    async getFriends(@Headers('Authorization') token: string) {
        const userInfo = await this.redisCache.getUserBySession(token)

        return this.friendService.getFriends(userInfo.id)
    }

    /**
     * 获取好友信息
     * @param query
     * @returns
     */
    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Get('/friendMessages')
    async getFriendMessage(@Query() query: GetFriendMessagesDto, @Headers('Authorization') token: string) {
        const { friendId, pageSize, pageIndex } = query
        const userInfo = await this.redisCache.getUserBySession(token)

        return this.friendService.getFriendMessages(userInfo.id, friendId, pageIndex || 1, pageSize || 20)
    }
}
