import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { CacheModule } from '@nestjs/cache-manager'
import { APP_GUARD } from '@nestjs/core'
import { RedisTokenGuard } from '../../services/redisService/redisToken.decorator'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { User } from '../user/entity/user.entity'
import { LhcDrawing } from '../lhcDrawing/entity/lhcDrawing.entity'
import { CommentController } from './comment.controller'
import { Comment } from './entity/comment.entity'
import { CommentService } from './comment.service'
import { BullModule } from '@nestjs/bull'
import { bullConfig } from 'src/config'
import { CommentQueueHandler } from './queue/queue.handler'

@Module({
    imports: [
        TypeOrmModule.forFeature([Comment, User, LhcDrawing]),
        CacheModule.register(),
        BullModule.forRoot({
            redis: bullConfig,
            defaultJobOptions: {
                // 设置默认的 Redis 缓存过期时间，单位为毫秒
                // 这里设置为 20000 毫秒，即 20 秒
                // 根据需要进行调整
                lifo: true,
                timeout: 20000,
            },
        }),
        // 注册队列名称为 "comment_queue"
        BullModule.registerQueue({
            name: 'comment_queue',
            limiter: {
                max: 3, // 最大重试次数
                duration: 5000, // 重试间隔时间（毫秒）
            },
        }),
    ],
    controllers: [CommentController],
    providers: [
        RedisCacheService,
        {
            provide: APP_GUARD,
            useClass: RedisTokenGuard,
        },
        CommentService,
        CommentQueueHandler,
    ],
})
export class CommentModule {}
