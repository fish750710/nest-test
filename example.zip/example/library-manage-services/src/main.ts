import { NestFactory } from '@nestjs/core'
import { AppModule } from './app.module'
import { NestExpressApplication } from '@nestjs/platform-express'
import { HttpExceptionFilter } from './common/filters/http-exception.filter'
import { ResponseInterceptor } from './common/interceptor/response.interceptor'
import { join } from 'path'
import { createLogger, transports, format } from 'winston'
import 'winston-daily-rotate-file'
//import { AppClusterService } from './common/cluster/app-cluster.service';

async function bootstrap() {
    //const app = await NestFactory.create(AppModule);
    const app = await NestFactory.create<NestExpressApplication>(AppModule, {
        abortOnError: true,
        logger: createLogger({
            transports: [
                new transports.DailyRotateFile({
                    level: 'info',
                    format: format.combine(format.timestamp(), format.json()),
                    filename: 'logs/log-%DATE%.log',
                    datePattern: 'YYYY-MM-DD',
                    zippedArchive: true,
                    maxSize: '100m',
                    maxFiles: '30d',
                }),
                new transports.Console({
                    format: format.combine(
                        format.cli(),
                        format.splat(),
                        format.timestamp(),
                        format.printf((info) => {
                            return `${info.timestamp} ${info.level}: ${info.message}`
                        }),
                    ),
                }),
            ],
        }),
    })

    app.enableCors()
    app.use((req, res, next) => {
        res.header('Access-Control-Allow-Origin', '*')
        res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
        res.header('Access-Control-Allow-Headers', 'Content-Type, Accept')
        next()
    })

    // 全局过滤器
    app.useGlobalFilters(new HttpExceptionFilter())

    // 配置全局拦截器
    app.useGlobalInterceptors(new ResponseInterceptor())

    // 配置静态资源
    app.useStaticAssets(join(__dirname, '../public', '/'), {
        prefix: '/',
        setHeaders: (res) => {
            res.set('Cache-Control', 'max-age=2592000')
        },
    })

    await app.listen(2020)
}

// Call app-cluster.service.ts here.
// AppClusterService.clusterize(bootstrap);
bootstrap()
