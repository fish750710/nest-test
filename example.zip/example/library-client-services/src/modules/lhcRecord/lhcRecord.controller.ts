import { Controller, Get, HttpCode, Query, UseInterceptors, UsePipes } from '@nestjs/common'
import { LhcRecordService } from './lhcRecord.service'
import { CacheInterceptor } from '@nestjs/cache-manager'
import { GetLhcRecordListDto } from './dto/index.dto'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'

/**
 * 六合彩记录
 */
@Controller('lhcRecord')
export class lhcRecordController {
    constructor(private readonly lhcRecordService: LhcRecordService) {}

    @HttpCode(200)
    @UseInterceptors(CacheInterceptor)
    @UsePipes(new ValidationPipe()) // 使用管道验证
    @Get('getList')
    async getList(@Query() query: GetLhcRecordListDto) {
        const { lotteryType, year, pageSize, pageIndex } = query
        return this.lhcRecordService.getList(lotteryType, year, pageSize || 10, pageIndex || 1)
    }
}
