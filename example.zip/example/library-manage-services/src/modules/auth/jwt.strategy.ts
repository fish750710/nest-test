import { Strategy, ExtractJwt } from 'passport-jwt'
import { HttpException, HttpStatus, Injectable } from '@nestjs/common'
import { PassportStrategy } from '@nestjs/passport'
import { jwtConstants } from './constants'
import { AuthService } from './auth.service'
@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
    constructor(private readonly authService: AuthService) {
        super({
            //jwtFromRequest: ExtractJwt.fromHeader('token'),
            jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: jwtConstants.secret,
        })
    }

    async validate(payload: any) {
        if (payload.id <= 0 || payload.name === '') {
            throw new HttpException('AccessToken error', HttpStatus.FORBIDDEN)
        }
        const isExist = this.authService.checkUserExist(payload.id)
        if (!isExist) {
            throw new HttpException('用户不存在', HttpStatus.FORBIDDEN)
        }

        return payload
    }
}
