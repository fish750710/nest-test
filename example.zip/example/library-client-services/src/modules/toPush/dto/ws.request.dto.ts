// 获取ws开奖记录
interface GetRecordDto {
    lotteryType: string
}
