import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { CacheModule } from '@nestjs/cache-manager'
import { Ads } from './entity/ads.entity'
import { AdsController } from './ads.controller'
import { AdsService } from './ads.service'

@Module({
    imports: [TypeOrmModule.forFeature([Ads]), CacheModule.register()],
    controllers: [AdsController],
    providers: [AdsService],
})
export class AdsModule {}
