import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

// 管理员表
@Entity('admin_users')
export class AdminUser {
    @PrimaryGeneratedColumn()
    id: number

    // 用户名
    @Column()
    name: string

    // 密码
    @Column()
    pwd: string

    // 状态 0：正常 1：锁定
    @Column()
    status: number

    // 创建时间
    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    created_at: Date

    // 创建者ip
    @Column()
    created_at_ip: string

    // 更新时间
    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    update_at: Date

    // 绑定ip
    @Column()
    bind_ip: string
}
