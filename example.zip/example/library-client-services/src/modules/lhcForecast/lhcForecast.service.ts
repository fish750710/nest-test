import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { FindOptionsWhere, Repository } from 'typeorm'
import { LhcForecast } from './entity/lhcForecast.entity'

@Injectable()
export class LhcForecastService {
    constructor(
        @InjectRepository(LhcForecast)
        private readonly lhcForecastRepository: Repository<LhcForecast>,
    ) {}

    async getList(lotteryType: string, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize
        const where: FindOptionsWhere<LhcForecast> = {}
        where.lottery_type = lotteryType
        query.select = ['lottery_type', 'period', 'jx_yima', 'jx_wuma', 'jx_shima', 'tj_yixiao', 'tj_sanxiao', 'tj_liuxiao', 'tj_jiuxiao', 'te_xiao', 'te_ma']

        query.where = where

        query.order = {
            period: 'DESC',
            id: 'DESC',
        }
        return await this.lhcForecastRepository.find(query)
    }
}
