import { Injectable } from '@nestjs/common'
import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm'
import { Repository, In, Like, EntityManager, SelectQueryBuilder } from 'typeorm'
import { Group, GroupMap } from './entity/group.entity'
import { GroupMessage } from './entity/groupMessage.entity'
import { User } from '../user/entity/user.entity'

@Injectable()
export class GroupService {
    constructor(
        @InjectEntityManager()
        private readonly entityManager: EntityManager,
        @InjectRepository(Group)
        private readonly groupRepository: Repository<Group>,
        @InjectRepository(GroupMap)
        private readonly groupUserRepository: Repository<GroupMap>,
        @InjectRepository(GroupMessage)
        private readonly groupMessageRepository: Repository<GroupMessage>,
    ) {}

    /**
     * 获取群信息
     * @param groupIds 群id[]
     * @returns
     */
    async getGroups(groupIds: number[]) {
        return await this.groupRepository.find({ where: { group_id: In(groupIds) } })
    }

    /**
     * 获取用户所在群组
     * @param userId 用户ID
     * @returns
     */
    async getUserGroups(userId: number) {
        return await this.groupUserRepository.find({ where: { user_id: userId } })
    }

    /**
     * 获取群所有用户
     * @param groupId 群ID
     * @returns
     */
    async getGroupUsers(groupId: number) {
        return await this.groupUserRepository.find({ where: { group_id: groupId } })
    }

    /**
     * 获取群消息
     * @param groupId 群ID
     * @param pageIndex 第几页
     */
    async getGroupMessages(groupId: number, pageIndex: number) {
        const queryBuilder: SelectQueryBuilder<any> = this.entityManager
            .createQueryBuilder(GroupMessage, 'gm')
            .leftJoinAndSelect(User, 'u', 'gm.user_id = u.id')

        queryBuilder.where('gm.group_id = :groupId', { groupId }).select(`gm.*,u.nick_name`)

        return await queryBuilder
            .orderBy({ 'gm.id': 'ASC', 'gm.time': 'DESC' })
            .limit(20)
            .offset(20 * (pageIndex - 1))
            .getRawMany()
    }

    /**
     * 群名搜索
     * @param groupName
     * @returns
     */
    async getGroupsByName(groupName: string) {
        return await this.groupRepository.find({ where: { group_name: Like(`%${groupName}%`) } })
    }
}
