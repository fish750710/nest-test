import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger, UnauthorizedException } from '@nestjs/common'
import { address } from 'ip'
import { SystemException } from './system.exception'

@Catch(HttpException)
export class HttpExceptionFilter implements ExceptionFilter<Error> {
    private readonly dailyLogger = new Logger()

    catch(exception: Error, host: ArgumentsHost) {
        const ctx = host.switchToHttp()
        const response = ctx.getResponse()
        const request = ctx.getRequest()
        const status = exception instanceof HttpException ? exception.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR

        if (status === HttpStatus.INTERNAL_SERVER_ERROR) {
            this.dailyLogger.error(`${request.url},${exception}`)
        } else if (status === HttpStatus.NOT_FOUND) {
        } else if (status !== HttpStatus.OK) {
            this.dailyLogger.warn(`${request.url},${exception}`)
        }

        if (exception instanceof SystemException) {
            response.status(status).json({
                code: exception.getErrorCode(),
                message: exception.getErrorMessage(),
                data: {
                    time: new Date().valueOf(),
                    path: request.url,
                    ip: address(),
                },
            })
        } else if (exception instanceof UnauthorizedException) {
            response.status(status).json({
                code: exception.getStatus(),
                message: exception.message,
                data: {
                    time: new Date().valueOf(),
                    path: request.url,
                    ip: address(),
                },
            })
        } else {
            response.status(status).json({
                code: status,
                message: exception.message,
                data: {
                    time: new Date().valueOf(),
                    path: request.url,
                    ip: address(),
                },
            })
        }
    }
}
