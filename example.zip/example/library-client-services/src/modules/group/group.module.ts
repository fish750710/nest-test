import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { GroupService } from './group.service'
import { GroupController } from './group.controller'
import { Group, GroupMap } from './entity/group.entity'
import { GroupMessage } from './entity/groupMessage.entity'
import { SysGroup } from './entity/sysGroup.entity'
import { User } from '../user/entity/user.entity'
import { SysGroupService } from './sysGroup.service'
import { RedisTokenGuard } from '../../services/redisService/redisToken.decorator'
import { APP_GUARD } from '@nestjs/core'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { SysGroupMessage } from './entity/sysGroupMessage.entity'
import { CacheModule } from '@nestjs/cache-manager'

@Module({
    imports: [TypeOrmModule.forFeature([User, SysGroup, Group, GroupMap, GroupMessage, SysGroupMessage]), CacheModule.register()],
    controllers: [GroupController],
    providers: [
        RedisCacheService,
        {
            provide: APP_GUARD,
            useClass: RedisTokenGuard,
        },
        GroupService,
        SysGroupService,
    ],
})
export class GroupModule {}
