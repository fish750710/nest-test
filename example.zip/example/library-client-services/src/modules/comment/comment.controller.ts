import { Body, Controller, HttpCode, Post, Headers, UsePipes, Query, Get, UseInterceptors } from '@nestjs/common'
import { CommentService } from './comment.service'
import { TokenRequired } from '../../services/redisService/redisToken.decorator'
import { AddCommentDto, GetDrawingCommentDto, GetUserCommentDto } from './dto/index.request.dto'
import { RedisCacheService } from '../../services/redisService/redisCache.service'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { CacheInterceptor } from '@nestjs/cache-manager'

@Controller('comment')
export class CommentController {
    constructor(
        private readonly redisCache: RedisCacheService,
        private readonly commentService: CommentService,
    ) {}

    @HttpCode(200)
    @UseInterceptors(CacheInterceptor)
    @UsePipes(new ValidationPipe())
    @Get('getDrawingCommentList')
    async getDrawingCommentList(@Query() query: GetDrawingCommentDto) {
        const { pageIndex, maxId, drawingId, parentId } = query
        return this.commentService.getByDrawingIdList(drawingId, parentId || 0, maxId || 0, pageIndex || 1)
    }

    @TokenRequired()
    @UseInterceptors(CacheInterceptor)
    @UsePipes(new ValidationPipe())
    @HttpCode(200)
    @Get('getCommentByUid')
    async getCommentByUserId(@Query() query: GetUserCommentDto, @Headers('Authorization') token: string) {
        const { pageIndex, maxId, lotteryType } = query

        const userInfo = await this.redisCache.getUserBySession(token)

        return this.commentService.getCommentByUserId(userInfo.id, maxId || 0, pageIndex || 1, lotteryType)
    }

    @TokenRequired()
    @HttpCode(200)
    @UsePipes(new ValidationPipe())
    @Post('addComment')
    async addUserComment(@Body() body: AddCommentDto, @Headers('Authorization') token: string) {
        const { drawingId, parentId, content } = body
        const userInfo = await this.redisCache.getUserBySession(token)

        return this.commentService.addComment(drawingId, userInfo.id, parentId || 0, content)
    }
}
