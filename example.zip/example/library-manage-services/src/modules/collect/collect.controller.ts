import { Controller, HttpCode, UsePipes, Query, Get, UseGuards } from '@nestjs/common'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { CollectService } from './collect.service'
import { JwtAuthGuard } from '../auth/jwt.guard'
import { GetCollectListDto } from './dto/request.dto'

@Controller('collect')
export class CollectController {
    constructor(private readonly collectService: CollectService) {}

    // 收藏列表
    @Get('getList')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async getUser(@Query() query: GetCollectListDto) {
        const { userId, pageSize, pageIndex } = query

        return this.collectService.getList(userId || 0, pageSize || 20, pageIndex || 1)
    }
}
