import { AuthGuard } from '@nestjs/passport'
import { Injectable, ExecutionContext, HttpException, HttpStatus } from '@nestjs/common'

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
    canActivate(context: ExecutionContext) {
        return super.canActivate(context)
    }

    handleRequest(err, user, info) {
        if (err || !user) {
            throw err || new HttpException('AccessToken error', HttpStatus.FORBIDDEN)
        }
        return user
    }
}
