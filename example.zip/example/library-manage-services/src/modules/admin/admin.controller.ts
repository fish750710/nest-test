import { Body, Controller, Get, HttpCode, Post, Query, UseGuards, UsePipes } from '@nestjs/common'
import { ValidationPipe } from 'src/common/pipe/validation.pipe'
import { JwtAuthGuard } from '../auth/jwt.guard'
import { AdminUserService } from './admin.service'
import { AdminUserCreateDto, AdminUserUpdateDto, GetAdminUserListDto } from './dto/request.dto'
import { address } from 'ip'
import { MD5 } from 'crypto-js'

@Controller('adminuser')
export class AdminUserController {
    constructor(private readonly adminUserService: AdminUserService) {}

    // 后台菜单列表
    @Get('menuList')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    async getMenuList() {
        return [
            {
                id: 1,
                menuName: '后台管理',
                children: [{ id: 11, menuName: '管理员列表' }],
            },
            {
                id: 2,
                menuName: '彩种管理',
                children: [
                    { id: 21, menuName: '彩票类型列表' },
                    { id: 22, menuName: '开奖列表' },
                    { id: 23, menuName: '开奖视频列表' },
                ],
            },
            {
                id: 3,
                menuName: '业务管理',
                children: [
                    { id: 31, menuName: '六合彩图纸列表' },
                    { id: 32, menuName: '六合预测列表' },
                    { id: 33, menuName: '广告位列表' },
                ],
            },
            {
                id: 4,
                menuName: '会员管理',
                children: [
                    { id: 41, menuName: '会员列表' },
                    { id: 42, menuName: '评论列表' },
                    { id: 43, menuName: '收藏列表' },
                ],
            },
        ]
    }

    // 获取用户列表
    @Get('getList')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async getList(@Query() query: GetAdminUserListDto) {
        const { name, id, pageSize, pageIndex } = query

        return this.adminUserService.getList(name, id, pageSize || 20, pageIndex || 1)
    }

    // 创建用户
    @Post('create')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async createUser(@Body() body: AdminUserCreateDto) {
        const { bindIp, userName, passWord, status } = body
        const ipAddress = address()
        return this.adminUserService.createUser(userName, MD5(passWord).toString(), status, ipAddress, bindIp || '')
    }

    // 更新用户信息
    @Post('edit')
    @HttpCode(200)
    @UseGuards(JwtAuthGuard)
    @UsePipes(new ValidationPipe())
    async updateUser(@Body() body: AdminUserUpdateDto) {
        const { bindIp, id, status, passWord } = body

        const newPwd = passWord ? MD5(passWord).toString() : null

        return this.adminUserService.updateUser(id, newPwd, status, bindIp || '')
    }
}
