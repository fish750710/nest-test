import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm'
import { EntityManager, Repository, SelectQueryBuilder } from 'typeorm'
import { Injectable } from '@nestjs/common'
import { userDataBaseName } from 'src/config'
import { Comment } from './entity/comment.entity'
import { User } from '../user/entity/user.entity'
import { LhcDrawing } from '../lhcDrawing/entity/lhcDrawing.entity'
import { ResponseCode } from 'src/common/constant/response.code'
import { ApiErrorResponse, ApiResponse, ApiSuccessResponse } from 'src/common/constant/response.api'

@Injectable()
export class CommentService {
    constructor(
        @InjectEntityManager(userDataBaseName)
        private readonly entityManager: EntityManager,
        @InjectRepository(Comment, userDataBaseName)
        private readonly commentRepository: Repository<Comment>,
    ) {}

    async getList(drawingId: number, parentId: number, pageSize: number, pageIndex: number) {
        const queryBuilder: SelectQueryBuilder<any> = this.entityManager.createQueryBuilder(Comment, 'uc').leftJoinAndSelect(User, 'u', 'uc.user_id = u.id')

        if (parentId === 0) {
            queryBuilder.leftJoinAndSelect(LhcDrawing, 'draw', 'uc.drawing_id = draw.id')
        }
        queryBuilder.where('1 = 1')

        // if (maxId > 0) {
        //     queryBuilder.andWhere('uc.id > :id', { id: maxId });
        // }
        if (drawingId > 0) {
            queryBuilder.andWhere('uc.drawing_id = :drawingId', { drawingId })
        }

        if (parentId > 0) {
            queryBuilder.andWhere('uc.parent_id = :parentId and uc.level = :level', { parentId: parentId, level: 2 }).select(`uc.*,u.nick_name`)
        } else {
            queryBuilder.andWhere('uc.level = :level', { level: 1 }).select(`uc.*,u.nick_name,draw.name,draw.picture_url`)
        }

        return await queryBuilder
            .orderBy({ 'uc.id': 'ASC', 'uc.created_at': 'DESC' })
            .limit(pageSize)
            .offset(pageSize * (pageIndex - 1))
            .getRawMany()
    }

    async deleteComment(commentId: number): Promise<ApiResponse<number>> {
        const result = await this.commentRepository.delete({ id: commentId })

        if (result.affected <= 0) {
            return new ApiErrorResponse('删除失败!', ResponseCode.FAIL)
        }
        this.commentRepository.delete({ parent_id: commentId })

        return new ApiSuccessResponse(result.affected)
    }
}
