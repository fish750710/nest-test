import { ResponseCode } from './response.code'

export class ApiResponse<T> {
    constructor(
        public data: T,
        public message: string,
        public code: number,
    ) {}
}

export class ApiSuccessResponse<T> extends ApiResponse<T> {
    constructor(data: T, message = 'success') {
        super(data, message, Number(ResponseCode.OK))
    }
}

export class ApiErrorResponse<T> extends ApiResponse<T> {
    constructor(message: string, code: ResponseCode = ResponseCode.ERROR, data: any = '') {
        super(data, message, code)
    }
}
