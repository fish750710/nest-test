// // recaptcha.guard.ts
// import { Injectable, CanActivate, ExecutionContext, HttpServer, ForbiddenException } from '@nestjs/common'

// @Injectable()
// export class RecaptchaGuard implements CanActivate {
//     constructor(private readonly httpService: HttpServer) {}

//     async canActivate(context: ExecutionContext): Promise<boolean> {
//         const { body } = context.switchToHttp().getRequest()

//         const { data } = await this.httpService
//             .post('https://www.google.com/recaptcha/api/siteverify?response=${body.recaptchaValue}&secret=${process.env.RECAPTCHA_SECRET}')
//             .toPromise()

//         if (!data.success) {
//             throw new ForbiddenException()
//         }

//         return true
//     }
// }

// 我通过创建一个单独的 RecaptchaGuard 解决了这个问题。

// // recaptcha.guard.ts
// import {
//   Injectable,
//   CanActivate,
//   ExecutionContext,
//   HttpService,
//   ForbiddenException,
// } from "@nestjs/common";

// @Injectable()
// export class RecaptchaGuard implements CanActivate {
//   constructor(private readonly httpService: HttpService) {}

//   async canActivate(context: ExecutionContext): Promise<boolean> {
//     const { body } = context.switchToHttp().getRequest();

//     const { data } = await this.httpService
//       .post(
//         `https://www.google.com/recaptcha/api/siteverify?response=${body.recaptchaValue}&secret=${process.env.RECAPTCHA_SECRET}`
//       )
//       .toPromise();

//     if (!data.success) {
//       throw new ForbiddenException();
//     }

//     return true;
//   }
// }

// // app.controller.ts
// import { Controller, Post, UseGuard } from '@nestjs/common';
// import { RecaptchaGuard } from './recaptcha.guard.ts'

// @Controller()
// export class AppController {

//  @Post()
//  @UseGuard(RecaptchaGuard)
//  async postForm(){
//   //
//  }
// }

// $ npm i @nestlab/google-recaptcha https://github.com/chvarkov/google-recaptcha
