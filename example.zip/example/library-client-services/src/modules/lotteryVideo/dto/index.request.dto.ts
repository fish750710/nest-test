import { Type } from 'class-transformer'
import { IsNotEmpty, IsNumber, IsOptional, Max } from 'class-validator'

export class GetVideoListDto {
    @Type(() => String)
    @IsNotEmpty({ message: '请提供彩种类型' })
    readonly lotteryType: string

    @Type(() => Number)
    @IsNotEmpty({ message: '请提供年份' })
    @IsNumber({}, { message: '年份必须数字格式' })
    readonly year: number

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    @Max(30)
    readonly pageSize?: number | null

    @Type(() => Number)
    @IsOptional()
    @IsNumber()
    readonly pageIndex?: number | null
}
