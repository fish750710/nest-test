import { Injectable } from '@nestjs/common'
import { FindOptionsWhere, Repository } from 'typeorm'
import { Ads } from './entity/ads.entity'
import { InjectRepository } from '@nestjs/typeorm'
import { Pagination } from 'src/common/tool/pagination'

@Injectable()
export class AdsService {
    constructor(
        @InjectRepository(Ads)
        private readonly adsRepository: Repository<Ads>,
    ) {}
    async getList(lotteryType: string, pageSize: number, pageIndex: number) {
        const query: any = {}
        query.skip = pageSize * (pageIndex - 1)
        query.take = pageSize

        const where: FindOptionsWhere<Ads> = {}
        where.ad_lottery_type = lotteryType

        query.select = ['ad_icon_url', 'ad_title', 'ad_link', 'ad_lottery_type']

        query.where = where

        query.order = {
            ad_update_at: 'DESC',
        }

        const [list, count] = await this.adsRepository.findAndCount(query)
        return new Pagination({
            data: list,
            count,
            pageIndex: pageIndex,
            pageSize: pageSize,
        })
    }
}
