import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common'
import { CaptchaController } from './captcha.controller'
import { RedisCacheService } from 'src/services/redisService/redisCache.service'
import { RateLimitMiddleware } from 'src/services/rateLimit/rateLimit.service'

@Module({
    imports: [],
    controllers: [CaptchaController],
    providers: [RedisCacheService],
})
//export class CaptchaModule { }
export class CaptchaModule implements NestModule {
    configure(consumer: MiddlewareConsumer) {
        consumer.apply(RateLimitMiddleware).forRoutes('*') // 应用到所有路由，你可以根据需要进行修改  不使用改方法 就使用@UseMiddleware(RateLimitMiddleware)
        //.forRoutes('your-route'); // 将 'your-route' 替换为您的目标路由路径
    }
}
