import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

@Entity('group')
export class Group {
    @PrimaryGeneratedColumn()
    group_id: number

    @Column()
    user_id: number

    @Column()
    group_name: string

    @Column()
    notice: string

    @Column({ type: 'double', default: new Date().valueOf() })
    time: number
}

@Entity('group_map')
export class GroupMap {
    @PrimaryGeneratedColumn()
    id: number

    @Column()
    group_id: number

    @Column()
    user_id: number

    @Column({ type: 'double', default: new Date().valueOf() })
    time: number
}
