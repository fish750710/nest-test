import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm'

// 彩票视频表
@Entity('lottery_video')
export class LotteryVideo {
    @PrimaryGeneratedColumn()
    id: number

    // 彩种类型
    @Column()
    lottery_type: string

    // 封面图URL
    @Column()
    video_picture_url: string

    // 视频URL
    @Column()
    video_url: string

    // 视频标题
    @Column()
    video_title: string

    // 期号
    @Column()
    period: string

    // 年
    @Column()
    year: number

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    created_at: Date

    @Column({
        type: 'datetime',
        transformer: {
            from: (value) => {
                return value.toLocaleString().replace(/\//g, '-')
            },
            to: (value) => {
                return value
            },
        },
    })
    update_at: Date
}
