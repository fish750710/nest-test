import { Entity } from 'typeorm'
import { LhcRecordBaseEntity } from './base.entity'

@Entity('amlhc_record')
export class AmlhcRecord extends LhcRecordBaseEntity {
    // 可以添加特定于的字段和逻辑...
}
